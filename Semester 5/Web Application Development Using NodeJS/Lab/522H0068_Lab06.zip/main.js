const express = require('express')
const AccountRouter = require('./routers/AccountRouter')
const session = require('express-session');
const app = express()
const fs = require("fs")



app.set('view engine', 'ejs')

app.use(session({
    secret: '123',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

app.set('view engine', 'ejs');

function checkAuthentication(req, res, next) {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/account/login');
    }
}

app.get('/', checkAuthentication, (req, res) => {
    let userId = 1
    3
    let filesOrDirs = fs.readdirSync(`${USER_FILES_DIR}/${userId}`)
    console.log(filesOrDirs)
    let filesOrDirsMap = filesOrDirs.map(fileName => {
        let filePath = `${USER_FILES_DIR}/${userId}/${fileName}`
        let fileInfo = fs.statSync(filePath)
        return {
            name: fileName,
            path: filePath,
            isDirectory: fileInfo.isDirectory(),
            size: fileInfo.size,
            lastModified: fileInfo.mtime
        }
    })
    console.log(filesOrDirsMap)
    res.render('index', { files: filesOrDirsMap });
});
app.use('/account', AccountRouter);

app.get('/', (req, res) => res.render('index'))
app.use('/account', AccountRouter)
app.listen(12346, () => console.log('http://localhost:12346'))