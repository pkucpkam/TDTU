const express = require('express');
const passport = require('../config/auth');
const router = express.Router();

// Route chuyển hướng tới Google để đăng nhập
router.get('/auth/google', passport.authenticate('google', {
  scope: ['profile', 'email']
}));

// Callback từ Google
router.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/login' }),
  (req, res) => {
    res.redirect('/'); // Chuyển hướng đến trang chủ sau khi đăng nhập thành công
  });

// Đăng xuất
router.get('/logout', (req, res) => {
  req.logout(() => {
    res.redirect('/login');
  });
});

module.exports = router;
