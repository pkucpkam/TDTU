const express = require('express');
const passport = require('../config/auth');
const router = express.Router();

// Trang chính
router.get('/', (req, res) => {
  if (req.isAuthenticated()) {
    res.render('index', { user: req.user }); // Truyền thông tin user vào view
  } else {
    res.redirect('/login');
  }
});

// Trang login
router.get('/login', (req, res) => {
  res.render('login');
});

// Google OAuth
router.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

router.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/login' }),
  (req, res) => {
    res.redirect('/');
  }
);

// Logout
router.get('/logout', (req, res) => {
  req.logout(() => {
    res.redirect('/login');
  });
});

module.exports = router;
