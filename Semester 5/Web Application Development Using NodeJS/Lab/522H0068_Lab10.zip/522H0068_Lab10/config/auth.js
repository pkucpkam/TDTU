const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
require('dotenv').config();

// Cấu hình Passport với Google OAuth 2.0
passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID,
  clientSecret: process.env.GOOGLE_CLIENT_SECRET,
  callbackURL: '/auth/google/callback', // URL sẽ gọi về sau khi xác thực thành công
},
(accessToken, refreshToken, profile, done) => {
  // Lưu thông tin người dùng (profile) vào session
  // Profile có thể chứa các thông tin như tên, email từ tài khoản Google
  return done(null, profile);
}));

// Lưu trữ thông tin người dùng vào session
passport.serializeUser((user, done) => {
  done(null, user);
});

// Khôi phục thông tin người dùng từ session
passport.deserializeUser((obj, done) => {
  done(null, obj);
});

module.exports = passport;
