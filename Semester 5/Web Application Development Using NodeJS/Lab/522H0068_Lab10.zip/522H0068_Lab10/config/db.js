const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    await mongoose.connect('mongodb+srv://phuc:123456@cluster0.jbsmq.mongodb.net/myDatabase?retryWrites=true&w=majority&appName=Cluster0', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('Đã kết nối đến MongoDB Atlas');
  } catch (error) {
    console.error('Lỗi kết nối MongoDB:', error);
    process.exit(1); // Dừng ứng dụng nếu kết nối thất bại
  }
};

module.exports = connectDB;
