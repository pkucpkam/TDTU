require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const session = require('express-session');
const passport = require('./config/auth');
const routes = require('./routes/index');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Cấu hình view engine
app.set('view engine', 'ejs');
app.set('views', './views');

// Middleware
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'your_secret_key',
  resave: false,
  saveUninitialized: false,
}));
app.use(passport.initialize());
app.use(passport.session());
app.use('/', routes);

// Danh sách người dùng online
let onlineUsers = [];

// Socket.IO
io.on('connection', (socket) => {
  console.log('A user connected');

  socket.on('user-login', (user) => {
    const loginTime = new Date().toLocaleTimeString(); // Lấy thời gian đăng nhập
    onlineUsers.push({ id: socket.id, name: user.name, status: `Truy cập lúc: ${loginTime}` });
    io.emit('update-users', onlineUsers); // Phát danh sách người dùng tới tất cả client
  });

  socket.on('user-logout', () => {
    onlineUsers = onlineUsers.filter(user => user.id !== socket.id);
    io.emit('update-users', onlineUsers);
  });

  socket.on('send-message', (message) => {
    const sender = onlineUsers.find((user) => user.id === socket.id)?.name || 'Anonymous';
    io.emit('new-message', { sender, text: message.text, time: message.time });
  });

  socket.on('disconnect', () => {
    onlineUsers = onlineUsers.filter(user => user.id !== socket.id);
    io.emit('update-users', onlineUsers);
    console.log('A user disconnected');
  });
});


// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server is running on http://localhost:${PORT}`));
