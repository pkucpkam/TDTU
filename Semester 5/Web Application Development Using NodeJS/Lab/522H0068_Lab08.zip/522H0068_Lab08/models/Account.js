const { Schema, model } = require('mongoose')
const uuid = require('uuid')

const UserSchema = new Schema({
    _id: { type: String, default: uuid.v4 },
    email: {
        type: String,
        unique: true
    },

    password: String,
    fullname: String,
})

module.exports = model('User', UserSchema)

