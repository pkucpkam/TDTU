const express = require('express');
const bcrypt = require('bcrypt');
const Account = require('../model/Account'); 
const router = express.Router();

router.use(express.urlencoded({ extended: true }));
const bodyParser = require('body-parser');

// Login route
router.get('/login', (req, res) => res.render('login'));

router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    console.log("Login attempt with email:", email);
    
    try {
        const user = await Account.findOne({ where: { email: email } });

        if (!user) {
            console.log("Invalid username");
            return res.status(401).send("Invalid username");
        }

        const matched = await bcrypt.compare(password, user.userpassword);
        console.log("Password match result:", matched);

        if (!matched) {
            console.log("Invalid password");
            return res.status(401).send("Invalid password");
        }

        req.session.user = {
            id: user.id,
            email: user.email,
            name: user.name
        };

        return res.redirect('/');
    } catch (error) {
        console.error("Error during login query:", error);
        return res.status(500).send("Login failed");
    }
});

// Register route
router.get('/register', (req, res) => res.render('register'));

router.post('/register', async (req, res) => {
    const { name, email, password } = req.body;
    console.log(name, email, password);

    try {
        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = await Account.create({
            name: name,
            email: email,
            userpassword: hashedPassword
        });

        console.log('User created:', newUser);
        res.redirect('/account/login');  
    } catch (error) {
        console.error("Error during registration:", error);
        res.status(500).send("Registration failed");
    }
});

module.exports = router;
