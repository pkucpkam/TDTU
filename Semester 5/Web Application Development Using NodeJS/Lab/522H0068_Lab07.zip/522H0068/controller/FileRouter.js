const express = require('express');
const multer = require('multer');
const fs = require('fs-extra');
const path = require('path');
const router = express.Router();
const bodyParser = require('body-parser');

const USER_FILES_DIR = process.env.USER_FILES_DIR;

console.log(USER_FILES_DIR)

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        let userId = req.session.user.id;
        const userDir = path.join(__dirname, '..', userId.toString());  

        fs.ensureDirSync(userDir);  

        cb(null, userDir);  
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname);  
    }
});

const upload = multer({ storage: storage });

router.post('/upload', (req, res) => {
    let handler = upload.single('file');
    handler(req, res, (err) => {
        if (err) {
            return res.json({ success: false, message: err.message });
        }

        if (!req.file) {
            return res.json({ success: false, message: "No file uploaded" });
        }

        let userId = req.session.user.id;
        let { path, originalname } = req.file;

        console.log("File uploaded path:", path);  

        res.json({ success: true, message: 'File uploaded successfully' });
    });
});

// Tạo thư mục mới
router.post('/create-folder', (req, res) => {
    const { folderName } = req.body;
    let userId = req.session.user.id;
    console.log(USER_FILES_DIR)
    const userDir = path.join(USER_FILES_DIR, userId.toString());
    const newFolderPath = path.join(userDir, folderName);
    fs.ensureDir(newFolderPath)
        .then(() => {
            res.json({ success: true, message: 'Folder created successfully' });
        })
        .catch((err) => {
            res.json({ success: false, message: 'Error creating folder: ' + err.message });
        });
});

// Tạo tệp mới (ví dụ tạo tệp văn bản rỗng)
router.post('/create-file', (req, res) => {
    const { fileName, content = '' } = req.body;
    let userId = req.session.user.id;
   
    const userDir = path.join(USER_FILES_DIR, userId.toString());

    const filePath = path.join(userDir, fileName);
    fs.writeFile(filePath, content, (err) => {
        if (err) {
            return res.json({ success: false, message: 'Error creating file: ' + err.message });
        }
        res.json({ success: true, message: 'File created successfully' });
    });
});

// Xóa tệp
router.delete('/delete-file', (req, res) => {
    const { fileName } = req.body;
    let userId = req.session.user.id;
    const userDir = path.join(USER_FILES_DIR, userId.toString());

    const filePath = path.join(userDir, fileName);
    fs.remove(filePath, (err) => {
        if (err) {
            return res.json({ success: false, message: 'Error deleting file: ' + err.message });
        }
        res.json({ success: true, message: 'File deleted successfully' });
    });
});

module.exports = router;
