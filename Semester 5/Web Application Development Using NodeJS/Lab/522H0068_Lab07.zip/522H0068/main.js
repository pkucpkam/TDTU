const express = require('express');
const AccountRouter = require('./controller/AccountRouter');
const FileRouter = require('./controller/FileRouter');
const session = require('express-session');
const app = express();
require('dotenv').config();
const fs = require('fs-extra');
const path = require('path');
const bodyParser = require('body-parser');  
app.use(express.json());  
app.use(express.urlencoded({ extended: true })); 


const USER_FILES_DIR = process.env.USER_FILES_DIR;
console.log("USER_FILES_DIR:", USER_FILES_DIR);  

app.set('view engine', 'ejs');

app.use(session({
    secret: '123',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

app.set('view engine', 'ejs');

function checkAuthentication(req, res, next) {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/account/login');
    }
}

app.get('/', checkAuthentication, (req, res) => {
    const userId = req.session.user.id;
    console.log(`Reading files for user ID: ${userId}`);

    let filesOrDirs = [];
    try {
        filesOrDirs = fs.readdirSync(path.join(USER_FILES_DIR, `${userId}`));
    } catch (err) {
        console.error('Error reading directory:', err);
        return res.status(500).send('Không thể đọc thư mục');
    }

    const filesOrDirsMap = filesOrDirs.map(fileName => {
        const filePath = path.join(USER_FILES_DIR, `${userId}`, fileName);
        let fileInfo = fs.statSync(filePath);
        return {
            name: fileName,
            path: filePath,
            isDirectory: fileInfo.isDirectory(),
            size: fileInfo.size,
            lastModified: fileInfo.mtime
        };
    });

    console.log('Files or directories:', filesOrDirsMap);

    res.render('index', { files: filesOrDirsMap });
});

app.use('/account', AccountRouter);
app.use('/',FileRouter)

app.listen(12346, () => console.log('Server running at http://localhost:12346'));
