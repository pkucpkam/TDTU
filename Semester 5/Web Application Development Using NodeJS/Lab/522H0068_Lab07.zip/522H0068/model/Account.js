const { DataTypes } = require('sequelize');
const sequelize = require('../db'); 

const Account = sequelize.define('Account', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    userpassword: {
        type: DataTypes.STRING,
        allowNull: false
    }
}, {
    tableName: 'account',
    timestamps: false   
});

module.exports = Account;
