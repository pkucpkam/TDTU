const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('lab6', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
    port: 3306
});

module.exports = sequelize;
