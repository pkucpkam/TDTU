/** @type {import('next').NextConfig} */
const config = {
  output: 'standalone',
};

export default config;
