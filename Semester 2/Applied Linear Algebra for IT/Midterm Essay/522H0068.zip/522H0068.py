import numpy as np

A = np.random.randint(1,101,(10,10))
B = np.random.randint(1,21,(2,10))
C = np.random.randint(1,21,(10,2))
print("Matrix A :")
print(A)
print("Matrix B :")
print(B)
print("Matrix C :")
print(C)
#a
a = A + A.T + np.matmul(C,B) + np.matmul(B.T,C.T)
print("'a)")
print(a)

#b
S = np.zeros((10,10))
j = 1
for i in range(10,20,1):
    S = S + (A/i)**j
    j+=1
print("'b)")
print(S)

#c
c = A[::2,:]
print("'c)")
print(c)

#d
d = []
for i in range(0,10,1):
    for j in range(0,10,1):
        if (A[i][j] % 2 == 1):
            d.append(A[i][j])
D = np.array(d)
print("'d)")
print(D)

#e
e = []
for i in range(0,10,1):
    for j in range(0,10,1):
        dem = 0
        for k in range(1,A[i][j] + 1,1):
            if (A[i][j] % k == 0):
                dem += 1
        if (dem == 2):
            e.append(A[i,j])
E = np.array(e)
print("'e)")
print(E)

#f
D = np.matmul(C,B)
for i in range(0,D.shape[0],1):
    if (i % 2 == 0):
        D[i] = (D[i][::-1] )
print("'f)")
print(D)

#g
print("'g) ")
# hàm kiểm tra số nguyên tố
def checkSNT(x):
    dem = 0 
    for k in range(1,x + 1,1):
        if (x % k == 0):
            dem += 1
    if (dem == 2):
        return True
    else:
        return False

# tìm số lượng số nguyên tố lớn nhất
max = 0
for i in range(0,10,1):
    dem = 0
    for j in range(0,10,1):
        if (checkSNT(A[i][j])):
            dem += 1
    if (dem > max):
        max = dem
# kiểm tra hàng nào có số lượng số nguyên tố bằng max thì in ra
for i in range(0,10,1):
    dem = 0
    for j in range(0,10,1):
        if (checkSNT(A[i][j])):
            dem += 1
    if (dem == max):
        print(A[i])

#h
print("'h) ")
# tim so luong so le lien nhau nhieu nhat
max1 = 0
for i in range(0,10,1):
    dem = 0
    for j in range(0,10,1):
        if (A[i][j] % 2 == 1):
            dem += 1
            if (dem > max1):
                max1 = dem
        else:
            dem = 0
#ktra xem hang nao co cung so lon nhat thi in ra
for i in range(0,10,1):
    dem = 0
    for j in range(0,10,1):
        if (A[i][j] % 2 == 1):
            dem += 1
            if (dem == max1):
                print(A[i])
        else:
            dem = 0       