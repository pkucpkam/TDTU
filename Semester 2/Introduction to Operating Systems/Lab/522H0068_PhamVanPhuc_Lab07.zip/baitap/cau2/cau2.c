#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <errno.h>

#define MSG_TYPE 1

struct msgbuf {
    long mtype;
    int data;
};

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }
    
    char* filename = argv[1];

    FILE* fp = fopen(filename, "r");
    if (fp == NULL) {
        perror("fopen");
        return 1;
    }

    int num1, num2;
    char op;
    fscanf(fp, "%d %d %c", &num1, &num2, &op);

    key_t key = ftok(".", 'a');
    int msqid = msgget(key, IPC_CREAT | 0666);
    if (msqid == -1) {
        perror("msgget");
        return 1;
    }
    
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return 1;
    }
    if (pid == 0) {
        struct msgbuf msg;
        msg.mtype = MSG_TYPE;
        msg.data = num1;
        if (msgsnd(msqid, &msg, sizeof(msg.data), 0) == -1) {
            perror("msgsnd");
            return 1;
        }
        
        msg.data = num2;
        if (msgsnd(msqid, &msg, sizeof(msg.data), 0) == -1) {
            perror("msgsnd");
            return 1;
        }
        
        msg.data = (int) op;
        if (msgsnd(msqid, &msg, sizeof(msg.data), 0) == -1) {
            perror("msgsnd");
            return 1;
        }

        if (msgrcv(msqid, &msg, sizeof(msg.data), MSG_TYPE, 0) == -1) {
            perror("msgrcv");
            return 1;
        }

        FILE* fp = fopen(filename, "a");
        if (fp == NULL) {
            perror("fopen");
            return 1;
        }
        
        fprintf(fp, "Result: %d\n", msg.data);
        fclose(fp);
        
        return 0;
    }
    else {

        struct msgbuf msg;
        if (msgrcv(msqid, &msg, sizeof(msg.data), MSG_TYPE, 0) == -1) {
            perror("msgrcv");
            return 1;
        }
        num1 = msg.data;
        
        if (msgrcv(msqid, &msg, sizeof(msg.data), MSG_TYPE, 0) == -1) {
            perror("msgrcv");
            return 1;
        }
        num2 = msg.data;
        
        if (msgrcv(msqid, &msg, sizeof(msg.data), MSG_TYPE, 0) == -1) {
            perror("msgrcv");
            return 1;
        }
        op = (char) msg.data;
        
        int result;
        switch(op) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                if (num2 == 0) {
                    printf("Error: division by zero\n");
                    return 1;
                }
                result = num1 / num2;
                break;
            default:
                printf("Error: unknown operator %c\n", op);
                return 1;
        }
        
        msg.mtype = MSG_TYPE;
        msg.data = result;
        if (msgsnd(msqid, &msg, sizeof(msg.data), 0) == -1) {
            perror("msgsnd");
            return 1;
        }
        
        return 0;
    }
}
