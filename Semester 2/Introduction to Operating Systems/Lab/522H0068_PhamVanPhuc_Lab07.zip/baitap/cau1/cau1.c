#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <errno.h>

#define MSG_TYPE 1
#define MAX_CHILDREN 10

struct msgbuf {
    long mtype;
    int data;
};

int factorial(int n) {
    int fact = 1;
    for (int i = 2; i <= n; i++) {
        fact *= i;
    }
    return fact;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: %s n\n", argv[0]);
        return 1;
    }
    
    int n = atoi(argv[1]);
    if (n <= 3) {
        printf("n > 3\n");
        return 1;
    }
    
    key_t key = ftok(".", 'a');
    int msqid = msgget(key, IPC_CREAT | 0666);
    if (msqid == -1) {
        perror("msgget");
        return 1;
    }
    
    int num_children = n - 3;
    if (num_children > MAX_CHILDREN) {
        num_children = MAX_CHILDREN;
    }
    
    pid_t pid;
    for (int i = 0; i < num_children; i++) {
        pid = fork();
        if (pid == -1) {
            perror("fork");
            return 1;
        }
        if (pid == 0) {
            struct msgbuf msg;
            msg.mtype = MSG_TYPE;
            msg.data = n - i - 2; 
            if (msgsnd(msqid, &msg, sizeof(msg.data), 0) == -1) {
                perror("msgsnd");
                return 1;
            }
            exit(0);
        }
    }
    
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += factorial(i);
    }
    
    struct msgbuf msg;
    msg.mtype = MSG_TYPE;
    msg.data = sum;
    if (msgsnd(msqid, &msg, sizeof(msg.data), 0) == -1) {
        perror("msgsnd");
        return 1;
    }
    
    for (int i = 0; i < num_children; i++) {
        struct msgbuf msg;
        if (msgrcv(msqid, &msg, sizeof(msg.data), MSG_TYPE, 0) == -1) {
            if (errno != ENOMSG) {
                perror("msgrcv");
                return 1;
            }
        } else {
            printf("Child process %d calculated %d\n", i+1, factorial(msg.data));
        }
    }
    
    if (msgctl(msqid, IPC_RMID, NULL) == -1) {
        perror("msgctl");
        return 1;
    }
    
    return 0;
}
