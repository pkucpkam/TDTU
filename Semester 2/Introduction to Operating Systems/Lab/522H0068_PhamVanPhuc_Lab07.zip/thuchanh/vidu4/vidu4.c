#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <limits.h>
#include <sys/msg.h>
#include <stdlib.h>
#include <string.h>

struct Message {
    int mtype;
    char* content;
};

int main(int argc, char* argv[]) {
    int mid;
    int id;
    key_t key;
    struct Message msg;
    int n;
    msg.content = (char*)malloc(BUFSIZ);
    if ((key = ftok(".",'a')) == -1) {
        perror("Key created\n");
        return 1;
    }
    if ((mid = msgget(key,IPC_CREAT | 0666)) == -1) {
        perror("Queue created\n");
        return 2;
    }
    switch (fork())
    {
        case -1:
            perror("fork error\n");
            return 3;
        
        case 0:
            msg.mtype = 10;
            msg.content = argv[1];
            n = strlen(msg.content);
            printf("%s\n",msg.content);
            n += sizeof(msg.mtype);
            if (msgsnd(mid,&msg,n,0) == -1) {
                perror("Message Send\n");
                return 4;
            }
            sleep(5);
            printf("Children receive from parent: \n");
            if (n = msgrcv(mid,&msg,BUFSIZ,11,0) == -1) {
                perror("Message Receive\n");
                return 5;
            }
            msg.content[strlen(msg.content)] = 0;
            printf("%s\n",msg.content);
            return 0;
        default:
            sleep(1);
            if (n = msgrcv(mid,&msg,BUFSIZ,10,0) == -1) {
                perror("Message Receive\n");
                return 5;
            }
            printf("Parent receive from children: \n");
            msg.content[strlen(msg.content)] = 0;
            printf("%s\n",msg.content);
            printf("---------------------------------------");
            printf("Message from parent\n");
            msg.content = argv[2];
            n = strlen(msg.content);
            msg.mtype = 11;
            n += sizeof(msg.mtype);
            if (msgsnd(mid,&msg,n,0) == -1) {
                perror ("Message Send\n");
                return 4;
            }
            sleep(10);
            return 0;
    }
    return 0;
}
