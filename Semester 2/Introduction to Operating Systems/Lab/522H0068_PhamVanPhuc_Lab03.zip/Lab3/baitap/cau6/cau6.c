#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {  

    struct timeval start_time, end_time;
    gettimeofday(&start_time, NULL);

    pid_t pid = fork();
    if (pid == -1) {
        printf("Error:\n");
        exit(1);
    }
    else if (pid == 0) {
        system(argv[1]);
        sleep(2);
    }
    else {
        wait(NULL);
        gettimeofday(&end_time, NULL);
        double elapsed_time = (double) (end_time.tv_sec - start_time.tv_sec);
        printf("Thoi gian thuc thi: %f giay\n", elapsed_time);
    }

    return 0;
}

