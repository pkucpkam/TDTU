#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdlib.h>

int main (int argc, char *argv[]) {
	if (argc == 1) {
		printf("Chua co doi so\n");
		exit(0);
	}
	int n = atoi(argv[1]);
	if (n < 0) {
		printf("Khong phai so duong\n");
		exit(0);
	}
	pid_t pid = fork();
	if (pid == 0) {
		while (n > 1) {
			printf("%d\n",n);
			if (n % 2 == 0) {
				n /= 2;
			}
			else {
				n = 1 + n*3;
			}
		}
		printf("1\n");
		printf("Ket thuc tien trinh con\n");
	}
	else {
		wait(NULL);
	}
	return 0;
}
