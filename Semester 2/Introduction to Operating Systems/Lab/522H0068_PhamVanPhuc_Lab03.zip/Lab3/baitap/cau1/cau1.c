#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int main (int argc, char ** argv) {
    int n = atoi(argv[1]);
    int i;
    pid_t pid;
    pid = fork();
    if (pid < 0) printf("fork error! No child created\n");
    else if (pid ==0 ) {
        int s1 = 0;
        for (i = 1; i <= n ; i++) {
            if (n % i == 0) {
                s1 = s1 + i;
            }
        }
        printf("Tong cac uoc cua %d la %d",n,s1);
    }
    else {
        int s2 = 0;
        for (i = 1; i <= n; i++) {
            s2 = s2 + i;
        }
        printf("Tong tu 1 den %d la %d\n ", n,s2);
    }
    return 0;
}
