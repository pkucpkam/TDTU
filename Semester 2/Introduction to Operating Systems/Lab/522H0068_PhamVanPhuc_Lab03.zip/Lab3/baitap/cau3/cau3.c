#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h> 
#include <sys/types.h> 
#include <unistd.h>

int main () {
	printf("A - ID la %d\n", (int)getpid());
	pid_t b = fork();
	if (b == 0) {
		printf("B - ID la %d, la con cua A - ID la %d\n",getpid(),getppid());
		pid_t d = fork();
		if (d == 0) {
			printf("D - ID la %d, la con cua B - ID la %d\n",getpid(),getppid());
			while(1);
		}
		else if (d > 0) {
			pid_t e = fork();
			if (e == 0) {
				printf("E - ID la %d, la con cua B - ID la %d\n", getpid(), getppid());
			}
			else if (e > 0) {
				wait(NULL);
			}
			else {
				printf("error\n");
			}
		}
		else {
			printf("error\n");
		}
	}
	else if (b > 0) {
		pid_t c = fork();
		if (c == 0) {
			printf("C - ID la %d, la con cua A - ID la %d\n",getpid(),getppid());
			wait(NULL);
			pid_t h = fork();
			if (h == 0) {
				printf("H - ID la %d, la con cua C - ID la %d\n",getpid(),getppid());
				while(1);
			}
			else if (h > 0) {
				wait(NULL);
			}
			else {
				printf("error \n");
			}
		}
		else if (c > 0) {
			wait(NULL);
		}
		else {
			printf("error\n");
		}
	}
	else {
		printf("error \n");
	}
}
