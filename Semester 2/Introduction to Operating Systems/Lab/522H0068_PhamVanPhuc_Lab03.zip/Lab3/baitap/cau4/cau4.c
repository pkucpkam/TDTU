#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
	while(1) {
		printf("Phucpham \n");
	}
	return 0;
}
