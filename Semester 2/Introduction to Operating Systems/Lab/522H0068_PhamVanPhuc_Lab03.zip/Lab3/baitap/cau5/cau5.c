#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
	int pid = fork();
	if (pid == 0) {
		printf("child : %d\n",getpid());
		sleep(5);
	}
	else if (pid > 0) {
		printf("parent : %d \n",getpid());
		exit(0);
	}
	else {
		return 0;
	}
	return 0;
}
