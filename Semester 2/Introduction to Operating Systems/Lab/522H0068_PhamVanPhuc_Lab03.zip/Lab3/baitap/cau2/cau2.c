#include <stdio.h>
#include <stdlib.h>

int main() {
	int a;
	printf("Hien duong dan : \n");
	a = system("pwd");
	printf("\n");
	
	printf("Liet ke thu muc : \n");
	a = system("ls");
	printf("\n");
	
	printf("Tao thu muc moi \n");
	a = system("mkdir Phuc");
	printf("\n");
	
	printf("Di chuyen vao thu muc vua tao \n");
	a = system("cd Phuc");
	printf("\n");
	
	return 0;
}
