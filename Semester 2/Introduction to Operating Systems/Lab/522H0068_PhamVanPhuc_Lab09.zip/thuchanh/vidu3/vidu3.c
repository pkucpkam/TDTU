#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <sys/errno.h>
#include <time.h> 
#include <stdlib.h>
#define num 2

union semun{
    int val;
    struct semid_ds *buf;
    unsigned short int *array;
    struct seminfo *_buf;
}sarg;
int Init()
{

    int i, semid;

    if((semid=semget(IPC_PRIVATE, 1,0666 | IPC_EXCL))==-1) return -1;

    sarg.val=1;

    if(semctl (semid, 0, SETVAL, sarg)==-1) return -1;

    return semid;

}

void P(int semid){
    struct sembuf buf;

    buf.sem_num = 0;

    buf.sem_op = -1; // decrease semaphore value

    buf.sem_flg = SEM_UNDO;

    if(semop(semid, &buf, 1)==-1){ 
        perror("semop\n"); exit(1);
    }
}
void V(int semid){
    struct sembuf buf;
    buf.sem_num = 0;
    buf.sem_op = 1; // increase semaphore value 
    buf.sem_flg = SEM_UNDO; 
    if(semop(semid, &buf, 1)==-1){ 
        perror("semop\n"); exit(1); 
    }
}
int Clear(int semid){
    return semctl (semid, 0, IPC_RMID, 0);
}
void test3(int semid) {
    int i =0;
    while(i<num){ 
        P(semid); // enter section 
        printf("%d do something in CS\n", getpid()); 
        sleep(4);
        V(semid); //exit section
        printf("%d out of CS\n", getpid());
        sleep(1);
        i++;
    }
}

void main(int argc, char* argv[]) {
    int semid=Init();
    if(fork()==0) test3 (semid);
    else test3(semid);
    sleep(4);
    Clear (semid);
}