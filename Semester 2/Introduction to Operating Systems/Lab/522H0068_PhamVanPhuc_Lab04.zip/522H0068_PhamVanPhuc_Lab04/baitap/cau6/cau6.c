#include <pthread.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <sys/types.h> 
#include <unistd.h>

struct prime_array {     
	int length;     
	int prime_arr[100];     
	int sum; 
};

static struct prime_array primearr, copy_primearr; 
static int n = 0; 
static int arr[50];

int check_prime(int num) {     
	int i;     
	for (i = 2; i*i <= num; i++) {         
		if (num % i == 0) {             
			return 0;         
		}     
	}     
	return 1; 
}

void* thr1 (void* ar) {     
	int i;     
	FILE *fi;     
	fi = fopen("inp.txt", "r");     
	fscanf(fi, "%d\n", &n);     
	for (i = 0; i < n; i++) {         
		fscanf(fi,"%d", &arr[i]);     
	}     
	fclose(fi); 
}

void* thr2 (void* arg) {     
	int i;     
	int length = 0;     
	int sum = 0;     
	for (i = 0; i < n; i++) {         
		if (check_prime(arr[i]) == 1) {             
		primearr.prime_arr[length] = arr[i];             
		sum += arr[i];             
		length += 1;         
		}     
	}
	primearr.length = length;     
	primearr.sum = sum; 
}

void* thr3 (void* arg) {     
	int min = 0;     
	int i, j;     
	int t;     
	copy_primearr.length = primearr.length;     
	for (i = 0; i < primearr.length; i++) {         
		copy_primearr.prime_arr[i] = primearr.prime_arr[i];     
	}         
	for (i = 0; i < primearr.length - 1; i++) {         
		min = i;         
		for (j = i; j < primearr.length; j++) {             
			if (primearr.prime_arr[min] > primearr.prime_arr[j]) {                 
				min = j;             
			}         
		}   
		t = primearr.prime_arr[min];         
		primearr.prime_arr[min] = primearr.prime_arr[i];
		primearr.prime_arr[i] = t;     
	} 
}

void* thr4 (void* ar) {
    int i;     
	FILE *fo;     
	fo = fopen("result.txt", "wb"); 
	
	fprintf(fo, "So phan tu trong mang: %d\n", n);     
	for (i = 0; i < n - 1; i++) {         
		fprintf(fo,"%d ", arr[i]);     
	}     
	fprintf(fo,"%d\n", arr[n-1]);
	fprintf(fo, "Mang cac so nguyen to la :\n");    
	for (i = 0; i < copy_primearr.length - 1; i++) {         
		fprintf(fo, "%d ", copy_primearr.prime_arr[i]);     
	}     
	fprintf(fo, "%d\n", copy_primearr.prime_arr[copy_primearr.length - 1]);
	
	fprintf(fo, "Tong cac so nguyen to la : %d\n", primearr.sum); 
	
	fprintf(fo, "Mang cac so nguyen to sau khi sap xep\n");     
	for (i = 0; i < primearr.length - 1; i++) {         
		fprintf(fo, "%d ", primearr.prime_arr[i]);     
	}     
	fprintf(fo, "%d\n", primearr.prime_arr[primearr.length - 1]);     
	fclose(fo); 
}

int main (int argc,char * argv[]){     
	pthread_t tid[4];     
	pthread_create(&tid[0], NULL, thr1, (void*) &tid[0]);
	pthread_join(tid[0], NULL); 
	pthread_create(&tid[1], NULL, thr2, (void*) &tid[1]);
	pthread_join(tid[1], NULL);
	pthread_create(&tid[2], NULL, thr3, (void*) &tid[2]);
	pthread_join(tid[2], NULL);
	pthread_create(&tid[3], NULL, thr4, (void*) &tid[3]);
	pthread_join(tid[3], NULL);
	return 0; 
}




