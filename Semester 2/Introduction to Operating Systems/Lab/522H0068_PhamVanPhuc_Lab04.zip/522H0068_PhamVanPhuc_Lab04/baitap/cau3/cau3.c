#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

struct arr {
	int n;
	int a[10];
};
struct file {
	struct arr ar;
	char* filename;
};

static float tb = 0.0;
static int max = 0;
static int min = 0;

void* thr1(void* ar) {
	struct arr *ap = (struct arr*)ar; 
	int i, max1;
	max1 = ap -> a[0];
	for (i = 0; i <ap->n; i++) {
		if (max1 < ap -> a[i]){
			max1 = ap -> a[i];
		}
	}
	max = max1;
}

void* thr2(void* ar) {
	struct arr *ap = (struct arr*)ar; 
	int i, min1;
	min1 = ap -> a[0];
	for (i = 0; i <ap->n; i++) {
		if (min1 > ap -> a[i]){
			min1 = ap -> a[i];
		}
	}
	min = min1;
}

void* thr3(void* ar) {
	struct arr *ap = (struct arr*)ar; 
	int i,s = 0;
	float ave;
	for (i = 0; i <ap->n; i++) {
		s = s + ap -> a[i];
	}
	ave = 1.0*s/(ap -> n);
	tb =ave;
}

void* thr4(void* ar) {
	FILE *out;
	out = fopen("result.txt","wb");
	fprintf(out,"Gia tri lon nhat la %d\n",max);
	fprintf(out,"Gia tri nho nhat la %d\n",min);
	fprintf(out,"Gia tri trung binh la %f\n",tb);
	fclose(out);
}

int main (int argc,char * argv[]){
	int i;     
	pthread_t tid[4];     
	struct arr ar;
	ar.n = argc - 1;     
	for (i=1;i<argc;i++) {         
		ar.a[i-1] = atoi(argv[i]); 
	}	
	pthread_create(&tid[0], NULL, thr1, (void*) &ar);
	pthread_create(&tid[1], NULL, thr2, (void*) &ar);
	pthread_create(&tid[2], NULL, thr3, (void*) &ar);
	
	pthread_join(tid[0], NULL);
	pthread_join(tid[1], NULL); 
	pthread_join(tid[2], NULL);
	
	pthread_create(&tid[3], NULL, thr4, (void*) &tid[3]);
	pthread_join(tid[3], NULL); 
	return 0;
}

