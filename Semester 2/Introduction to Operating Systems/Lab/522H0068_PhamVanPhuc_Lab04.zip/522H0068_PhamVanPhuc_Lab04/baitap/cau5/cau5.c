#include <pthread.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <sys/types.h> 
#include <unistd.h>

static int n = 0;
static long giaithua = 1;
static int tongchan = 0;

void* thr1(void* ar) {
	int i;
	long giaithua1 = 1;
	for (i = 1; i <=n ; i++) {
		giaithua1 = giaithua1*i;
	}
	giaithua = giaithua1;
}

void* thr2(void* ar) {
	int i, tongchan1 = 0;
	for (i = 1; i <= giaithua; i++) {
		if (i % 2 == 0) {
			tongchan1 += i;
		}
	}
	tongchan = tongchan1;
}

void* thr3(void* ar) {
	FILE *out;
	out = fopen((char *)ar,"wb");
	fprintf(out,"n = %d\n",n);
	fprintf(out, "%d! = %ld\n", n, giaithua);
	fprintf(out, "Tong chan be hon giai thua = %d\n", tongchan);
	fclose(out); 
}

int main (int argc,char * argv[]){     
	int i;     
	pthread_t tid[3];     
	n = atoi(argv[1]);
	pthread_create(&tid[0], NULL, thr1, (void*) &tid[0]);
	pthread_join(tid[0], NULL);
	
	pthread_create(&tid[1], NULL, thr2, (void*) &tid[1]); 
	pthread_join(tid[1], NULL); 
	
	pthread_create(&tid[2], NULL, thr3, argv[2]);
	pthread_join(tid[2], NULL);
	
	printf("Da tao ra tap tin %s\n", argv[2]); 
	return 0;
}
	
