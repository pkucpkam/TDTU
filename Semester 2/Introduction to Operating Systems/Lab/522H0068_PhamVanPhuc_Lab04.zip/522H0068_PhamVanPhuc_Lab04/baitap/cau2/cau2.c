#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
int check_prime(int num) {
    int i;    
    for (i = 2; i*i <= num; i++) {         
        if (num % i == 0) {             
            return 0;        
        }     
    }     
    return 1;
}
    void* thr1(void* ar){     
        int n = *((int *)ar);     
        int i;     
        if (n < 2) {

        } 
        else if (n == 2) {         
            printf("2\n");     
        } 
        else {         
            printf("2");         
            for ( i = 3; i <= n; i+=2) {             
                if (check_prime(i) == 1){                 
                    printf(" %d", i);             
                    }         
            }
        }        
        printf("\n");     
}

int main(int argc, char * argv[]) {
    pthread_t tid;
    int n = atoi(argv[1]);
    pthread_create(&tid,NULL,thr1,(void*) &n);
    pthread_join(tid,NULL);
    printf("Done\n");
    return 0;  
}