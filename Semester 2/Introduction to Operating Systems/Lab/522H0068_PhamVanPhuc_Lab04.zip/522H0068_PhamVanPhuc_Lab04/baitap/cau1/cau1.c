#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
int a[100];
int n;
static int max;
static int min;
void *thread1(void *ar) {
    int max = a[0];
    for (int i = 1; i < n; i++) {
        if (a[i] > max) {
            max = a[i];
        } 
    }
    printf("So lon nhat la %d\n",max );
}

void *thread2(void *ar) {
    int min = a[0];
    for (int i = 1; i < n; i++) {
        if (a[i] < min) {
            min = a[i];
        } 
    }
    printf("So nho nhat la %d\n",min );
}

void *thread3(void *ar) {
    float t = 0;
    for (int i = 0; i < n; i++) {
        t = t + a[i];
    }
    float tb = (float) t/n;
    printf("trung binh la %f\n",tb );
}

int main(int argc, char* argv[]) {
    int i;
    n = argc - 1;
    for (i = 0; i < n;i++) {
        a[i] = atoi(argv[i+1]);
    }
    pthread_t tid1;
    pthread_create(&tid1,NULL,&thread1,NULL);
    pthread_join(tid1,NULL);
    pthread_t tid2;
    pthread_create(&tid2,NULL,&thread2,NULL);
    pthread_join(tid2,NULL);
    pthread_t tid3;
    pthread_create(&tid3,NULL,&thread3,NULL);
    pthread_join(tid3,NULL);
    return 0;
}