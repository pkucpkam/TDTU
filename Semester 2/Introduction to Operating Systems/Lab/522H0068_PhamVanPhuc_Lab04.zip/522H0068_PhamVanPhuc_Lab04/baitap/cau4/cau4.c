#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

static long slchar;
struct file {
	char* source_file;
	char* target_file;
};

void* thr1(void* ar){ 
	struct file *ap = (struct file*) ar;
	FILE *fi;
	fi = fopen(ap->source_file,"r"); 
	FILE *fo; 
	fo = fopen(ap->target_file,"wb"); 
	
	int dem=0;
	char c;
	while(c != EOF) { 
		c = fgetc(fi); 
		if (c != EOF) { 
			fputc(c, fo);
		}
		dem++;
	}
	slchar = dem;
}

int main (int argc,char * argv[]){ 
	pthread_t tid;     
	struct file f;     
	f.source_file = argv[1];     
	f.target_file = argv[2];
	pthread_create(&tid, NULL, thr1, (void*) &f);
	pthread_join(tid, NULL);
	printf("Da sao chep thanh cong %ld ki tu.\n", slchar);
	return 0;
}
