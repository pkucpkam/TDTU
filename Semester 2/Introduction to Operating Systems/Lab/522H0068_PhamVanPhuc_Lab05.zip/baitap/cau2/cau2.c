#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define MAX_SIZE 100

int array[MAX_SIZE];
int array_size;

void *read_file(void *arg) {
    char *filename = (char *) arg;
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("Error");
        exit(1);
    }

    fscanf(fp, "%d", &array_size);
    for (int i = 0; i < array_size; i++) {
        fscanf(fp, "%d", &array[i]);
    }

    fclose(fp);
    return NULL;
}

int is_prime(int n) {
    if (n < 2) {
        return 0;
    }

    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            return 0;
        }
    }

    return 1;
}

volatile int prime_sum = 0;

void *count_primes(void *arg) {
    for (int i = 0; i < array_size; i++) {
        if (is_prime(array[i])) {
            prime_sum += array[i];
        }
    }

    return NULL;
}


int compare_ints(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

void *sort_array(void *arg) {
    qsort(array, array_size, sizeof(int), compare_ints);

    return NULL;
}

void *write_file(void *arg) {
    char *filename = (char *) arg;
    FILE *fp = fopen(filename, "w");
    if (!fp) {
        perror("Error");
        exit(1);
    }

    fprintf(fp, "Size of array: %d\n", array_size);
    fprintf(fp, "Value of elements: ");
    for (int i = 0; i < array_size; i++) {
        fprintf(fp, "%d ", array[i]);
    }
    fprintf(fp, "\n");

    fprintf(fp, "Primes: ");
    for (int i = 0; i < array_size; i++) {
        if (is_prime(array[i])) {
            fprintf(fp, "%d ", array[i]);
        }
    }
    fprintf(fp, "\n");

    fprintf(fp, "Sum of Primes: %d\n", prime_sum);
    fclose(fp);
    return NULL;
}

void *write1_file(void *arg) {
    char *filename = (char *) arg;
    FILE *fp = fopen(filename, "a");
    if (!fp) {
        perror("Error");
        exit(1);
    }
	fprintf(fp, "Primes sorted from smallest to highest: ");
    for (int i = 0; i < array_size; i++) {
        if (is_prime(array[i])) {
            fprintf(fp, "%d ", array[i]);
        }
    }
    fclose(fp);
    return NULL;
}
int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Failed");
        return 0;
    }

    pthread_t tid[5];
    pthread_create(&tid[0], NULL, read_file, argv[1]);
	pthread_join(tid[0], NULL);
	pthread_create(&tid[1], NULL, count_primes, NULL);
	pthread_join(tid[1], NULL);
	pthread_create(&tid[2], NULL, write_file, "output.txt");
	pthread_join(tid[2], NULL);
	pthread_create(&tid[3], NULL, sort_array, NULL);
	pthread_join(tid[3], NULL);
	pthread_create(&tid[4], NULL, write1_file, "output.txt");
	pthread_join(tid[4], NULL);


    return 0;
}

