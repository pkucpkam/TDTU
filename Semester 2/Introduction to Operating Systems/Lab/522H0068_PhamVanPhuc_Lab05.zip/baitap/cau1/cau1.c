#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int n, factorial = 1, sum = 0;

void *calculate_factorial(void *arg) {
    if (n != 0) {
        for (int i = 1; i <= n; i++) {
            factorial *= i;
        }
    }
    pthread_exit(NULL);
}

void *calculate_sum(void *arg) {
    for (int i = 1; i < factorial; i++) {
        if (factorial % i == 0) {
            sum += i;
        }
    }
    pthread_exit(NULL);
}

void *write_to_file(void *arg) {
    FILE *fp = fopen((char *) arg, "w");
    fprintf(fp, "N = %d\n", n);
    fprintf(fp, "%d! = %d\n", n, factorial);
    fprintf(fp, "Sum = %d\n", sum);
    fclose(fp);
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    n = atoi(argv[1]);

    pthread_t tid1, tid2, tid3;

    pthread_create(&tid1, NULL, calculate_factorial, NULL);
    pthread_join(tid1, NULL);
	
	pthread_create(&tid2, NULL, calculate_sum, NULL);
    pthread_join(tid2, NULL);

    pthread_create(&tid3, NULL, write_to_file, (void *)argv[2]);
    pthread_join(tid3, NULL);

    return 0;
}

