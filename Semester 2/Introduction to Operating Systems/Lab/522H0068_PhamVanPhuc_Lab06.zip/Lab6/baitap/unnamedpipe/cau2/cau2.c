#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    int pipefd[2];
    pid_t pid;
    int num1, num2;
    char operation;
    int result;

    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid = fork();

    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) { 

        close(pipefd[0]);

        read(pipefd[1], &num1, sizeof(num1));
        read(pipefd[1], &num2, sizeof(num2));
        read(pipefd[1], &operation, sizeof(operation));

        switch (operation) {
            case '+': result = num1 + num2; break;
            case '-': result = num1 - num2; break;
            case '*': result = num1 * num2; break;
            case '/': result = num1 / num2; break;
        }

        write(pipefd[1], &result, sizeof(result));

        close(pipefd[1]);

        exit(EXIT_SUCCESS);
    } else { 

        close(pipefd[1]);

        printf("Enter first number: ");
        scanf("%d", &num1);

        printf("Enter second number: ");
        scanf("%d", &num2);

        printf("Enter operation (+, -, *, /): ");
        scanf(" %c", &operation);

        write(pipefd[0], &num1, sizeof(num1));
        write(pipefd[0], &num2, sizeof(num2));
        write(pipefd[0], &operation, sizeof(operation));

        read(pipefd[0], &result, sizeof(result));

        close(pipefd[0]);

        FILE *fp = fopen("result.txt", "w");
        if (fp == NULL) {
            perror("fopen");
            exit(EXIT_FAILURE);
        }
        fprintf(fp, "%d", result);
        fclose(fp);

        printf("Result in file result.txt\n");

        exit(EXIT_SUCCESS);
    }
}

