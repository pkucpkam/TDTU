#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int factorial(int n) {
    if (n == 0) {
        return 1;
    } else {
        return n * factorial(n-1);
    }
}

int main(int argc, char *argv[]) {
    int n = atoi(argv[1]); 

    int pipefd[2];
    pid_t pid;

    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid = fork();
    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) { 
        close(pipefd[0]); 
        int result = factorial(n);
        write(pipefd[1], &result, sizeof(result));
        close(pipefd[1]); 
        exit(EXIT_SUCCESS);
    } else { 
        close(pipefd[1]); 
        int result;
        read(pipefd[0], &result, sizeof(result));
        printf("%d! = %d\n", n, result);
        close(pipefd[0]); 
        exit(EXIT_SUCCESS);
    }
}

