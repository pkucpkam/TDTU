#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>

#define FIFO_NAME "myfifo"

int main() {
    int fd, fd2, num1, num2;
    char operation;

    mkfifo(FIFO_NAME, 0666);

    if (fork() == 0) {
        fd = open(FIFO_NAME, O_RDONLY);
        read(fd, &num1, sizeof(num1));
        read(fd, &num2, sizeof(num2));
        read(fd, &operation, sizeof(operation));

        int result;

        switch (operation) {
            case '+': result = num1 + num2; break;
            case '-': result = num1 - num2; break;
            case '*': result = num1 * num2; break;
            case '/': result = num1 / num2; break;
        }

        close(fd);
        fd2 = open("result.txt", O_WRONLY | O_CREAT, 0666);
        dprintf(fd2, "%d", result);
        close(fd2);
        exit(0);
    } else {
        fd = open(FIFO_NAME, O_WRONLY);

        printf("Enter first number: ");
        scanf("%d", &num1);

        printf("Enter second number: ");
        scanf("%d", &num2);

        printf("Enter operation (+, -, *, /): ");
        scanf(" %c", &operation);

        write(fd, &num1, sizeof(num1));
        write(fd, &num2, sizeof(num2));
        write(fd, &operation, sizeof(operation));

        close(fd);

        wait(NULL);

        printf("Result in file result.txt\n");

        unlink(FIFO_NAME);

        exit(0);
    }
}

