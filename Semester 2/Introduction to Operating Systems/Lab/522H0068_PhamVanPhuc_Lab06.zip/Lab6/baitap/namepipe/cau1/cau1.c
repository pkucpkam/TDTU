#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define PIPE_NAME "/tmp/my_pipe"

int factorial(int n) {
    int result = 1;
    for (int i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}

int main(int argc, char *argv[]) {
    int n, fd;
    pid_t pid;
    char buf[256];

    if (mkfifo(PIPE_NAME, 0666) == -1) {
        perror("mkfifo");
        exit(EXIT_FAILURE);
    }

    if (argc < 2) {
        fprintf(stderr, "Usage: %s n\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    n = atoi(argv[1]);

    pid = fork();

    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) { 
        int result = factorial(n);

        fd = open(PIPE_NAME, O_WRONLY);
        if (fd == -1) {
            perror("open");
            exit(EXIT_FAILURE);
        }

        sprintf(buf, "%d", result);
        if (write(fd, buf, sizeof(buf)) == -1) {
            perror("write");
            exit(EXIT_FAILURE);
        }

        close(fd);
        exit(EXIT_SUCCESS);
    } else { 
        int status, result;

        fd = open(PIPE_NAME, O_RDONLY);
        if (fd == -1) {
            perror("open");
            exit(EXIT_FAILURE);
        }

        wait(&status);

        if (read(fd, buf, sizeof(buf)) == -1) {
            perror("read");
            exit(EXIT_FAILURE);
        }

        result = atoi(buf);
        printf("%d! = %d\n", n, result);

        close(fd);

        if (unlink(PIPE_NAME) == -1) {
            perror("unlink");
            exit(EXIT_FAILURE);
        }

        exit(EXIT_SUCCESS);
    }
}

