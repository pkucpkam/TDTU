#include <stdio.h>
#include <stdlib.h>

int is_integer(char *s) {
    int i = 0;
    if (s[i] == '-') {
        i++;
    }
    for (; s[i] != '\0'; i++) {
        if (s[i] < '0' || s[i] > '9') {
            return 0;
        }
    }
    return 1;
}

void bubble_sort(int *numbers, int n) {
    int i, j, temp;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (numbers[j] > numbers[j+1]) {
                temp = numbers[j];
                numbers[j] = numbers[j+1];
                numbers[j+1] = temp;
            }
        }
    }
}

int main(int argc, char *argv[]) {
    int i, n = 0;
    int *numbers = NULL;
    for (i = 1; i < argc; i++) {
        if (is_integer(argv[i])) {
            n++;
            numbers = (int *) realloc(numbers, n * sizeof(int));
            numbers[n-1] = atoi(argv[i]);
        }
    }
    printf("Sau khi sap xep la: ");
    bubble_sort(numbers, n);
    for (i = 0; i < n; i++) {
        printf("%d ", numbers[i]);
    }
    printf("\n");
    return 0;
}
