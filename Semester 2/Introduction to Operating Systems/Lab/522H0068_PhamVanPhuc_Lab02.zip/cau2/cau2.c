#include <stdio.h>
#include <stdlib.h>

int main(int argc, char ** argv) {
	int i = 0;
	int check = argc;
	int n = atoi(argv[1]);
	if (check > 2){
		printf("Thua doi so\n");
	}
	else if ( n <= 0) {
		printf("Doi so khong phai la so nguyen \n");
	}
	else {
		//in cac uoc cua so n
		printf("Cac uoc so cua %d la : ",n);
		for (i = 1; i <=n; i++) {
			if (n % i == 0) {
				printf("%d, ",i);
			}
		} 
		printf("\n");
		//Phan tich thanh so nguyen to
		int dem;
		printf("%d =",n);
		for(i = 2; i <= n; i++){
        dem = 0;
        while(n % i == 0){
            ++dem;
            n /= i;
        }
        if(dem){
            if(dem > 1) printf("%d^%d", i, dem);
            else printf("%d", i);
            if(n > i){
                printf(" * ");
            }
        }
    }
	}
}
