#include <stdio.h>
#include "math.h"

int main(int argc, char *argv[]) {
    
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);

    if (argv[3][0] == '+') {
        printf("%d + %d = %d\n", a, b, add(a, b));
    } else if (argv[2][0] == '-') {
        printf("%d - %d = %d\n", a, b, sub(a, b));
    } else {
        printf("Loi phep tinh\n");
    }

    return 0;
}

