#include <stdio.h>
#include <stdlib.h>
int main(int argc, char ** argv) {
    int a = atoi(argv[1]);
    printf("a = %d\n",a);
    if (argc > 2) {
        printf("Doi so truyen vao qua nhieu lan \n");
    }
    else if (a < 0) {
        printf("Doi so nhap vao khong phai la so nguyen duong \n");
    }
    else 
    {
        int i = 0;
        int sum = 0;
        for (i = 0; i <= a; i++) {
            sum = sum + i;
        }
        printf("S = %d\n",sum);
    }
}