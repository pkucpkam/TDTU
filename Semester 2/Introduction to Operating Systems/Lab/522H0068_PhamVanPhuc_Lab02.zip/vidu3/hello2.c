#include <stdio.h>
void hello_2(int i) {
	printf("Hello, parameter 2 = %d\n", i);
}
