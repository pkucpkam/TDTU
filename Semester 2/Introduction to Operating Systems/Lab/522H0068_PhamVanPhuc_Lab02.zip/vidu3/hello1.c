#include <stdio.h>
void hello_1(int i) {
	printf("Hello, parameter 1 = %d\n", i);
}
