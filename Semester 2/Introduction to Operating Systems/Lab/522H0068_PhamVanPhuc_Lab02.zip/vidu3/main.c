#include <stdio.h>
#include <stdlib.h>
int main(int argc, char ** argv) {
	int i = atoi(argv[1]);
	int k = atoi(argv[2]);
	hello_1(i); hello_2(k);
}
