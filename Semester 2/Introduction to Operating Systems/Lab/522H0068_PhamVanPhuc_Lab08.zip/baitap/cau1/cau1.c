#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>


#define ARRAY_SIZE 10

int main() {
    int shmid_0, shmid_1;
    int *shm_0, *shm_1;
    int sum = 0;
    
    shmid_0 = shmget(IPC_PRIVATE, (ARRAY_SIZE + 1) * sizeof(int), IPC_CREAT | 0666);
    shmid_1 = shmget(IPC_PRIVATE, sizeof(int), IPC_CREAT | 0666);
    
    shm_0 = (int*) shmat(shmid_0, NULL, 0);
    shm_1 = (int*) shmat(shmid_1, NULL, 0);
    
    pid_t pid = fork();
    
    if (pid == -1) {
        printf("Fork failed!\n");
        exit(1);
    } else if (pid == 0) {
        
        shm_0[0] = ARRAY_SIZE;
        for (int i = 1; i <= ARRAY_SIZE; i++) {
            shm_0[i] = i;
        }
        
        shmdt(shm_0);
        shmdt(shm_1);
        
        exit(0);
    } else {

        wait(NULL);
        
        int array_size = shm_0[0];
        for (int i = 1; i <= array_size; i++) {
            sum += shm_0[i];
        }
        
        *shm_1 = sum;
        
        printf("Sum of array elements: %d\n", *shm_1);
        
        shmdt(shm_0);
        shmdt(shm_1);
        shmctl(shmid_0, IPC_RMID, NULL);
        shmctl(shmid_1, IPC_RMID, NULL);
    }
    
    return 0;
}

