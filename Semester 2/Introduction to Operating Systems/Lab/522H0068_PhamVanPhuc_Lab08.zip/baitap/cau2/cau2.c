#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <unistd.h>

int main() {
    int shmid = shmget(IPC_PRIVATE, 3 * sizeof(int), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget");
        exit(1);
    }

    int *data = (int *) shmat(shmid, NULL, 0);
    if (data == (int *) -1) {
        perror("shmat");
        exit(1);
    }

    pid_t pid = fork();
    if (pid == 0) {

        FILE *fp = fopen("input.txt", "r");
        if (fp == NULL) {
            perror("fopen");
            exit(1);
        }

        int a, b;
        char op;

        fscanf(fp, "%d %d %c", &a, &b, &op);
        data[0] = a;
        data[1] = b;
        data[2] = (int) op;

        if (fclose(fp) != 0) {
            perror("fclose");
            exit(1);
        }

        printf("OK\n");

        while (data[2] == 0) {}

        printf("Result is %d\n", data[2]);

        fp = fopen("output.txt", "w");
        if (fp == NULL) {
            perror("fopen");
            exit(1);
        }

        fprintf(fp, "%d\n", data[2]);

        if (fclose(fp) != 0) {
            perror("fclose");
            exit(1);
        }

        if (shmdt(data) < 0) {
            perror("shmdt");
            exit(1);
        }

        exit(0);

    } else if (pid > 0) {

        // Parent process
        while (data[2] == 0) {}

        int a = data[0];
        int b = data[1];
        char op = (char) data[2];
        int result;

        switch (op) {
            case '+':
                result = a + b;
                break;
            case '-':
                result = a - b;
                break;
            case '*':
                result = a * b;
                break;
            case '/':
                result = a / b;
                break;
            default:
                fprintf(stderr, "Invalid operator: %c\n", op);
                exit(1);
        }

        data[2] = result;

        waitpid(pid, NULL, 0);

        if (shmdt(data) < 0) {
            perror("shmdt");
            exit(1);
        }

    } else {
        perror("fork");
        exit(1);
    }

    if (shmctl(shmid, IPC_RMID, NULL) < 0) {
        perror("shmctl");
        exit(1);
    }

    return 0;
}
