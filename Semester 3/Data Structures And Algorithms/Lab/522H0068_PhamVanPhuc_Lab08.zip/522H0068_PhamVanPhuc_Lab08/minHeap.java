import java.util.NoSuchElementException;

public class minHeap {
    int heap[];
    int heapSize;
    int maxSize;

    public minHeap(int capacity) {
        heapSize = 0;
        this.maxSize = capacity + 1;
        heap = new int[maxSize];
        heap[0] = Integer.MAX_VALUE; // Set a large value as the root for minHeap
    }

    private int parent(int i) {
        return i / 2;
    }

    private int left(int i) {
        return i * 2;
    }

    private int right(int i) {
        return i * 2 + 1;
    }

    private void swap(int i, int j) {
        int temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    public void insert(int key) throws NoSuchElementException {
        if (heapSize == maxSize) {
            throw new NoSuchElementException("Overflow Exception");
        }
        heapSize++;
        heap[heapSize] = key;
        shiftUp(heapSize);
    }

    private void shiftUp(int i) {
        while (i > 1 && heap[parent(i)] > heap[i]) {
            swap(parent(i), i);
            i = parent(i);
        }
    }

    public int extractMin() throws NoSuchElementException {
        if (heapSize == 0) {
            throw new NoSuchElementException("Underflow Exception");
        }
        int min = heap[1];
        heap[1] = heap[heapSize];
        heapSize--;
        shiftDown(1);
        return min;
    }

    private void shiftDown(int i) {
        while (i <= heapSize) {
            int min = heap[i];
            int minId = i;
            int leftChild = left(i);
            if (leftChild <= heapSize && heap[leftChild] < min) {
                min = heap[leftChild];
                minId = leftChild;
            }

            int rightChild = right(i);
            if (rightChild <= heapSize && heap[rightChild] < min) {
                min = heap[rightChild];
                minId = rightChild;
            }

            if (minId != i) {
                swap(minId, i);
                i = minId;
            } else {
                break;
            }
        }
    }

    public void print() {
        for (int i = 1; i <= heapSize / 2; i++) {
            System.out.print(" PARENT : " + heap[i] + " LEFT CHILD : " +
                    heap[2 * i] + " RIGHT CHILD :" + heap[2 * i + 1]);
            System.out.println();
        }
    }

    public static minHeap createHeap(int[] arr) {
        int n = arr.length;
        minHeap heap = new minHeap(n);
        for (int i = 0; i < n; i++) {
            heap.insert(arr[i]);
        }
        return heap;
    }

    public static void heapSort(int[] arr) {
        int n = arr.length;
        minHeap heap = createHeap(arr);
        for (int i = 0; i < n; i++) {
            arr[i] = heap.extractMin();
        }
    }

    public static void main(String[] args) {
        int[] arr = { 12, 11, 13, 5, 6, 7, 3 };
        minHeap heap = createHeap(arr);
        heap.print();
        heapSort(arr);
        for (int i : arr) {
            System.out.println(i);
        }
    }
}
