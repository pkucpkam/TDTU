public class Ex1 
{

    public static int prod_recur(int a, int b)
    {
        if(b == 0) return 0;
        if(b < 0) return - prod_recur(a, -b);
        return a + prod_recur(a, b - 1);
    }

    public static int bin2dec(int n, int exp)
    {
        if(n == 0) return 0;
        else
        {
            int lastDigit = n%10;
            int decimal = lastDigit * (int) Math.pow(2,exp);
            return decimal + bin2dec(n/10, exp + 1);
        }
    }

    public static int maxDigit(int n)
    {
        if(n<10) return n;
        return Math.max(n%10,maxDigit(n/10));
    }

    public static int maxElement(int[] a, int n)
    {
        if(n==0) return a[0];
        return Math.max(a[n], maxElement(a, n-1));
    }

    public static int search(int a[], int n, int key) 
    {
        return searchRecursive(a, n, key, 0);
    }
    
    private static int searchRecursive(int a[], int n, int key, int index) {
        if (n < 0) 
        {
            return -1;
        }
    
        if (a[n] == key) 
        {
            return index + n;
        }
        return searchRecursive(a, n - 1, key, index);
    } 

    public static int findLastEvenPosition(int a[], int n) 
    {
        if(n < 0) return -1;
        if(a[n] %2 == 0) return n;
        return findLastEvenPosition(a, n-1);
    }
    public static void main(String[] args) 
    {
        int[] a = {1, 3, 5, 8, 9, 2, 4, 7, 6};
        System.out.println(prod_recur(2, 2));
        System.out.println(bin2dec(1000, 0));
        System.out.println(maxDigit(1234456789));
        System.out.println(maxElement(a,2 ));
        System.out.println(search(a, a.length -1, 1));
        System.out.println(findLastEvenPosition(a,a.length-1));
    }
}
