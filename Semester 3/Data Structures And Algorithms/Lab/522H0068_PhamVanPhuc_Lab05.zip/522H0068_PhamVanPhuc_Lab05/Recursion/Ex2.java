public class Ex2 
{
    public static int  cal1(int n)
    {
        int sum = 1;
        for(int i = 1; i <= n; i++)
        {
            sum *= 2;
        }
        return sum;
    }
    public static int cal1Recur(int n)
    {
        if(n == 0) return 1;
        if(n == 1) return 2;
        return (int) Math.pow(2,n) + cal1Recur(n-1);
    }

    public static double cal2(int n)
    {
        double sum = 0;
        for(int i = 0; i <= n; i++)
        {
           sum += (double) (n+1)/2;
        }
        return sum;
    }
    public static double cal2Recur(int n)
    {
        if(n == 0) return (double) 1/2;
        return (double) (n+1)/2 + cal1Recur(n-1);
    }
    public static void main(String[] args)
    {
        System.out.println(cal1(5));
        System.out.println(cal2(5));
    }
}
