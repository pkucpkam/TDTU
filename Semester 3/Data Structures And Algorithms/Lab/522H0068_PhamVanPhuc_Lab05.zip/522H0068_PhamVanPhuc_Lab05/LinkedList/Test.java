public class Test {
    public static void main(String[] args) {
        IntLinkedList list = new IntLinkedList();
        list.addFirst(3);
        list.addFirst(2);
        list.addFirst(1);
        list.addLast(4);
        list.addLast(5);
        list.addLast(8);
        list.print();
        list.removeAt(1);
        list.print();
        System.out.println(list.searchKey(5));
        System.out.println(list.countOdd());
        System.out.println(list.checkSorted());
    }
}
