public class IntLinkedList implements ListInterface
{
    private Node head;
    public IntLinkedList()
    {
        head = null;
    }
    public void addFirst(int data)
    {
        head = new Node(data,head);
    }
    public boolean addLast(int data)
    {
        if(head == null)
        {
            addFirst(data);
            return true;
        }
        else
        {
            Node tmp = head;
            while(tmp.getNext() != null)
            {
                tmp = tmp.getNext();
            }
            Node newNode = new Node(data,null);
            tmp.setNext(newNode);
            return true;
        }
    }
    public int countOdd()
    {
        int count = 0;
        if(head == null)
            return 0;
        else
        {
            Node cur = head;
            while(cur != null)
            {
                if(cur.getData() % 2 == 1)
                    count++;
                cur = cur.getNext();
            }
                
        }
        return count;
    }
    public boolean removeAt(int position)
    {
        if(position < 1 || head == null)
            return false;
        else
        {
            Node cur = head;
            Node pre = null;
            int curPos = 1;
            while(curPos <= position && cur.getNext() != null)
            {
                pre = cur;
                cur = cur.getNext();
                curPos++;
            }
            if(cur == null)
                return false;
            else
            {
                pre.setNext(cur.getNext());
                return true;
            }
        }
    }
    public int searchKey(int key)
    {
        int position = 1;
        Node cur = head;
        while(cur != null)
        {
            if(cur.getData() == key)
                return position;
            cur = cur.getNext();
            position++;
        }
        return -1;
    }
    public void print()
    {
        if(head == null)
            System.out.println("List is empty");
        else
        {
            Node tmp = head;
            System.out.print("List: " + tmp.getData());
            tmp = tmp.getNext();
            while(tmp != null)
            {
                System.out.print(" " + tmp.getData());
                tmp = tmp.getNext();
            }
            System.out.println();
        }
    }
    public boolean checkSorted() 
    {
        if(head == null || head.getNext() == null)
            return true;
        else
        {
            Node cur = head;
            while(cur!= null)
            {
                if(cur.getData() > cur.getNext().getData() || cur.getData() < cur.getNext().getData())
                    return true;
                return false;
            }
            return false;
        }
    }
}