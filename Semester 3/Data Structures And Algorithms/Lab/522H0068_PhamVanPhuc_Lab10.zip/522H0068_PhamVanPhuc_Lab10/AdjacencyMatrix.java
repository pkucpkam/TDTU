import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

public class AdjacencyMatrix {
    private int[][] adj;
    private final int NUMBER_OF_VERTICES;

    public AdjacencyMatrix(int vertices) {
        NUMBER_OF_VERTICES = vertices;
        adj = new int[NUMBER_OF_VERTICES][NUMBER_OF_VERTICES];
    }

    // Initialize with an input filename
    public AdjacencyMatrix(String filename) throws Exception {
        Scanner sc = new Scanner(new BufferedReader(new FileReader(filename)));
        NUMBER_OF_VERTICES = sc.nextInt();
        adj = new int[NUMBER_OF_VERTICES][NUMBER_OF_VERTICES];
        sc.nextLine();
        for (int i = 0; i < NUMBER_OF_VERTICES; i++)
            for (int j = 0; j < NUMBER_OF_VERTICES; j++)
                adj[i][j] = sc.nextInt();
    }

    public void setEgde(int vertexSource, int vertexDestination, int weight) {
        try {
            adj[vertexSource][vertexDestination] = weight;
            adj[vertexDestination][vertexSource] = weight;
        } catch (ArrayIndexOutOfBoundsException indexBounce) {
            System.out.println("The vertex is invalid");
        }
    }

    public int getEgde(int vertexSource, int vertexDestination) {
        try {
            return adj[vertexSource][vertexDestination];
        } catch (ArrayIndexOutOfBoundsException indexBounce) {
            System.out.println("The vertex is invalid");
        }
        return -1;
    }

    public void printGraph() {
        for (int i = 0; i < NUMBER_OF_VERTICES; i++) {
            for (int j = 0; j < NUMBER_OF_VERTICES; j++) {
                System.out.print(adj[i][j] + " ");
            }
            System.out.println();
        }
    }

    public int countVer() {
        return NUMBER_OF_VERTICES;
    }

    public int countEdges() {
        int count = 0;
        for (int i = 0; i < NUMBER_OF_VERTICES; i++) {
            for (int j = 0; j < NUMBER_OF_VERTICES; j++) {
                count += adj[i][j];
            }
        }
        return count;
    }

    public void Enumerae(int u) {
        for (int i = 0; i < NUMBER_OF_VERTICES; i++) {
            if (adj[u - 1][i] == 1) {
                System.out.print(i + 1 + " ");
            }
        }
        System.out.println();
    }

    public boolean existence(int u, int v) {
        if (adj[u - 1][v - 1] == 1)
            return true;
        return false;
    }

    public void BFS(int startV) {
        boolean visited[] = new boolean[NUMBER_OF_VERTICES];
        Queue<Integer> queue = new LinkedList<>();
        queue.add(startV);
        visited[startV] = true;

        BFS(queue, visited);
        System.out.println();
    }

    private void BFS(Queue<Integer> queue, boolean[] visited) {
        if (queue.isEmpty()) {
            return;
        }
        int currV = queue.poll();
        System.out.print(currV + " ");
        for (int i = 0; i < NUMBER_OF_VERTICES; i++) {
            if (adj[currV][i] == 1 && !visited[i]) {
                queue.add(i);
                visited[i] = true;
            }
        }

        BFS(queue, visited);
    }

    public void DFS(int startV) {
        boolean[] visited = new boolean[NUMBER_OF_VERTICES];
        DFS(startV, visited);
        System.out.println();
    }

    public void DFS(int currV, boolean[] visited) {
        System.out.print(currV + " ");
        visited[currV] = true;
        for (int i = 0; i < NUMBER_OF_VERTICES; i++) {
            if (adj[currV][i] == 1 && !visited[i]) {
                DFS(i, visited);
            }
        }
    }

    public void StackDFS(int startV) {
        boolean visited[] = new boolean[NUMBER_OF_VERTICES];
        Stack<Integer> stack = new Stack<>();
        stack.push(startV);
        while (!stack.isEmpty()) {
            int currV = stack.pop();
            if (!visited[currV]) {
                System.out.print(currV + " ");
                visited[currV] = true;
            }

            for (int i = NUMBER_OF_VERTICES - 1; i >= 0; i--) {
                if (adj[currV][i] == 1 && !visited[i]) {
                    stack.push(i);
                }
            }
        }
        System.out.println();
    }

    public boolean isReachable(int u, int v) {
        if (adj[u][v] == 1)
            return true;
        return false;
    }

    // PRIM'S AL
    public void primMST() {
        int[] parent = new int[NUMBER_OF_VERTICES];
        int[] key = new int[NUMBER_OF_VERTICES];
        boolean[] mstSet = new boolean[NUMBER_OF_VERTICES];

        for (int i = 0; i < NUMBER_OF_VERTICES; i++) {
            key[i] = Integer.MAX_VALUE;
            mstSet[i] = false;
        }

        key[0] = 0;

        parent[0] = -1;

        for (int count = 0; count < NUMBER_OF_VERTICES - 1; count++) {
            int u = minKey(key, mstSet);
            mstSet[u] = true;
            for (int v = 0; v < NUMBER_OF_VERTICES; v++) {
                if (adj[u][v] != 0 && !mstSet[v] && adj[u][v] < key[v]) {
                    parent[v] = u;
                    key[v] = adj[u][v];
                }
            }
        }
        printMST(parent);
    }

    private void printMST(int[] parent) {
        System.out.println("Minimum Spanning Tree (Prim's Algorithm):");
        for (int i = 1; i < NUMBER_OF_VERTICES; i++) {
            System.out.println(parent[i] + " -- " + i + " == " + adj[i][parent[i]]);
        }

        // Calculate the total weight of the MST
        int totalWeight = 0;
        for (int i = 1; i < NUMBER_OF_VERTICES; i++) {
            totalWeight += adj[i][parent[i]];
        }
        System.out.println("Minimum Cost Spanning Tree: " + totalWeight);
    }

    private int minKey(int[] key, boolean[] mstSet) {
        int min = Integer.MAX_VALUE, minIndex = -1;

        for (int v = 0; v < NUMBER_OF_VERTICES; v++) {
            if (!mstSet[v] && key[v] < min) {
                min = key[v];
                minIndex = v;
            }
        }

        return minIndex;
    }

    public List<IntegerTriple> convertToEdgeList() {
        List<IntegerTriple> edgeList = new ArrayList<>();
        for (int i = 0; i < NUMBER_OF_VERTICES; i++) {
            for (int j = i + 1; j < NUMBER_OF_VERTICES; j++) {
                if (adj[i][j] != 0) {
                    edgeList.add(new IntegerTriple(adj[i][j], i + 1, j + 1));
                }
            }
        }
        return edgeList;
    }

    public int getSize() {
        return NUMBER_OF_VERTICES;
    }

    public static void main(String args[]) throws Exception {
        AdjacencyMatrix AdjMatrix = new AdjacencyMatrix("input1.txt");
        System.out.println("'a) AM : ");
        AdjMatrix.printGraph();

        System.out.println("Prim's Algorithm for Minimum Spanning Tree (MST):");
        AdjMatrix.primMST();

    }
}