import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Kruskals {

    static class Subset {
        int parent, rank;

        Subset(int parent, int rank) {
            this.parent = parent;
            this.rank = rank;
        }
    }

    static int find(Subset[] subsets, int i) {
        if (subsets[i].parent != i) {
            subsets[i].parent = find(subsets, subsets[i].parent);
        }
        return subsets[i].parent;
    }

    static void union(Subset[] subsets, int x, int y) {
        int xroot = find(subsets, x);
        int yroot = find(subsets, y);

        if (subsets[xroot].rank < subsets[yroot].rank) {
            subsets[xroot].parent = yroot;
        } else if (subsets[xroot].rank > subsets[yroot].rank) {
            subsets[yroot].parent = xroot;
        } else {
            subsets[yroot].parent = xroot;
            subsets[xroot].rank++;
        }
    }

    public static List<IntegerTriple> kruskalsMST(List<IntegerTriple> edgeList, int numberOfVertices) {
        List<IntegerTriple> mst = new ArrayList<>();
        int totalWeight = 0; 

        Collections.sort(edgeList, Comparator.comparing(IntegerTriple::getWeight));
        Subset[] subsets = new Subset[numberOfVertices];
        for (int i = 0; i < numberOfVertices; i++) {
            subsets[i] = new Subset(i, 0);
        }
        for (IntegerTriple edge : edgeList) {
            int sourceRoot = find(subsets, edge.getSource() - 1);
            int destRoot = find(subsets, edge.getDest() - 1);

            if (sourceRoot != destRoot) {
                mst.add(edge);
                union(subsets, sourceRoot, destRoot);
                totalWeight += edge.getWeight();
            }
        }

        System.out.println("Minimum Cost Spanning Tree Weight: " + totalWeight);
        return mst;
    }

    public static void main(String[] args) throws Exception {
        AdjacencyMatrix adjMatrix = new AdjacencyMatrix("input1.txt");
        List<IntegerTriple> edgeList = adjMatrix.convertToEdgeList();

        System.out.println("Edge List before Kruskal's Algorithm:");
        for (IntegerTriple edge : edgeList) {
            System.out.println(edge.toString());
        }
        List<IntegerTriple> mst = kruskalsMST(edgeList, adjMatrix.getSize());
        System.out.println("\nMinimum Spanning Tree (Kruskal's Algorithm):");
        for (IntegerTriple edge : mst) {
            System.out.println(edge.toString());
        }
    }
}
