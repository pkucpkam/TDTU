import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class Cau2 {
    public static void main(String args[]) {
        try {
            File file = new File("Input2.txt");
            Scanner scanner = new Scanner(file);
            Scanner scanner2 = new Scanner(System.in);
            // read R
            String line = scanner.nextLine();
            String R = line.substring(3, line.length() - 1);
            // readF
            String line1 = scanner.nextLine();
            line1 = line1.substring(3, line1.length() - 1);
            ArrayList<String> F = new ArrayList<>();
            for (String string : line1.split(",")) {
                F.add(string);
            }
            // read Attri
            String Attribute = args[0];
            scanner.close();
            scanner2.close();

            // process requirement
            String closure = closure(Attribute, F);
            ArrayList<String> keys = keys(R, F);

            // ghi file
            writeDataToFile("Output2.txt", closure, keys);
        } catch (IOException e) {
            System.err.println("Error reading from the file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static String closure(String attribute, ArrayList<String> F) {
        HashSet<Character> result = new HashSet<>();
        for (Character ch : attribute.toCharArray()) {
            result.add(ch);
        }
        boolean changed;
        do {
            changed = false;
            for (String f : F) {
                String[] str = f.split("->");
                String left = str[0];
                String right = str[1];
                if (isSubset(left, result)) {
                    for (char ch : right.toCharArray()) {
                        if (!result.contains(ch)) {
                            result.add(ch);
                            changed = true;
                        }
                    }
                }
            }
        } while (changed);

        String result1 = "";
        for (char ch : result) {
            result1 += ch;
        }
        return result1;
    }

    private static boolean isSubset(String subset, HashSet<Character> set) {
        for (char ch : subset.toCharArray()) {
            if (!set.contains(ch)) {
                return false;
            }
        }
        return true;
    }

    private static ArrayList<String> keys(String R, ArrayList<String> F) {
        ArrayList<String> keys = new ArrayList<>();
        ArrayList<String> subsets = genSub(R);
        for (String subset : subsets) {
            String closureResult = closure(subset, F);
            if (closureResult.equals(R)) {
                keys.add(subset);
            }
        }
        ArrayList<String> newKeys = new ArrayList<>(keys);
        for (String key : keys) {
            for (String key1 : keys) {
                if (!key.equals(key1) && key.contains(key1)) {
                    newKeys.remove(key);
                }
            }
        }
        return newKeys;
    }

    private static ArrayList<String> genSub(String R) {
        ArrayList<String> subsets = new ArrayList<>();
        int n = R.length();
        for (int i = 0; i < (1 << n); i++) {
            String subset = "";
            for (int j = 0; j < n; j++) {
                if ((i & (1 << j)) > 0) {
                    subset += R.charAt(j);
                }
            }
            subsets.add(subset);
        }
        subsets.remove("");
        return subsets;
    }

    private static void writeDataToFile(String filePath, String closure, ArrayList<String> keys) {
        try {
            File file = new File(filePath);
            FileWriter fileWriter = new FileWriter(file);
            PrintWriter printWriter = new PrintWriter(fileWriter);
            printWriter.println("Closure : " + closure);
            printWriter.println("Keys : " + keys);
            printWriter.close();
            System.out.println("Write file completed");
        } catch (IOException e) {
            System.err.println("Error writing to the file: " + e.getMessage());
            e.printStackTrace();
        }
    }
}