﻿USE MASTER
GO
CREATE DATABASE QuanLyBanHang
GO

CREATE TABLE SanPham
(
  maSP VARCHAR(20) NOT NULL	PRIMARY KEY,
  tenSP NVARCHAR(255) NOT NULL,
  giaBan INT NOT NULL CHECK(giaBan > 0)
);

CREATE TABLE KhachHang
(
  maKH VARCHAR(20) NOT NULL PRIMARY KEY,
  tenKH NVARCHAR(255) NOT NULL,
  sdt VARCHAR(20) NOT NULL,
  diaChi NVARCHAR(255) NOT NULL
);


CREATE TABLE Giay
(
  maSP VARCHAR(20) NOT NULL PRIMARY KEY,
  soLuong INT NOT NULL,
  mauSac VARCHAR(20) NOT NULL,
  size INT NOT NULL,
  FOREIGN KEY (maSP) REFERENCES SanPham(maSP)
);

CREATE TABLE NhaSanXuat
(
  maNXS VARCHAR(20) NOT NULL PRIMARY KEY,
  tenNSX NVARCHAR(255) NOT NULL,
  maSP VARCHAR(20) NOT NULL,	
  quocGia NVARCHAR(50) NOT NULL,
  FOREIGN KEY (maSP) REFERENCES Giay(maSP)
);

CREATE TABLE Tho
(
  maTho VARCHAR(20) NOT NULL PRIMARY KEY,
  tenTho NVARCHAR(255) NOT NULL,
  sdt VARCHAR(20) NOT NULL,
  tienLuong INT NOT NULL
);

CREATE TABLE HoaDon
(
  maHD VARCHAR(20) NOT NULL PRIMARY KEY,
  maKH VARCHAR(20) NOT NULL,
  ngayTao DATE NOT NULL DEFAULT GETDATE(),
  FOREIGN KEY (maKH) REFERENCES KhachHang(maKH)
);

CREATE TABLE TrangSuc
( 
  maSP VARCHAR(20) NOT NULL PRIMARY KEY,
  chatLieu NVARCHAR(255) NOT NULL,
  loai VARCHAR(100) NOT NULL,
  maTho VARCHAR(20) NOT NULL,
  FOREIGN KEY (maSP) REFERENCES SanPham(maSP),
  FOREIGN KEY (maTho) REFERENCES Tho(maTho)
);


CREATE TABLE ChiTietHoaDon
(
  maHD VARCHAR(20) NOT NULL,
  maSP VARCHAR(20) NOT NULL,
  soLuong INT NOT NULL,
  FOREIGN KEY (maHD) REFERENCES HoaDon(maHD),
  FOREIGN KEY (maSP) REFERENCES SanPham(maSP)
);


CREATE TABLE Thuoc
(
  maSP VARCHAR(20) NOT NULL,
  maHD VARCHAR(20) NOT NULL,
  PRIMARY KEY (maSP, maHD),
  FOREIGN KEY (maSP) REFERENCES SanPham(maSP),
  FOREIGN KEY (maHD) REFERENCES HoaDon(maHD)
);

--THÊM DỮ LIỆU
-- Thêm dữ liệu vào bảng SanPham
INSERT INTO SanPham (maSP, tenSP, giaBan) VALUES
('SP001', N'Giày Nike', 500000),
('SP002', N'Giày Adidas', 120000),
('SP003', N'Giày Puma', 800000),
('SP004', N'Dây chuyền 1', 1000000),
('SP005', N'Nhẫn 1', 120000),
('SP006', N'Vòng tay 1', 80000);

-- Thêm dữ liệu vào bảng KhachHang
INSERT INTO KhachHang (maKH, tenKH, sdt, diaChi) VALUES
('KH001', N'Phạm Văn Phúc', '0358948134', N'Đắk Lắk'),
('KH002', N'Lê Minh Sáng', '0987654321', N'TP Hồ Chí Minh'),
('KH003', N'Nguyễn Âu Ngọc Đăng', '0983474321', N'Thanh Hóa');

-- Thêm dữ liệu vào bảng Giay
INSERT INTO Giay (maSP, soLuong, mauSac, size) VALUES
('SP001', 50, 'Đỏ', 42), 
('SP002', 30, 'Xanh', 39),
('SP003', 20, 'Vàng', 41);

-- Thêm dữ liệu vào bảng Hang
INSERT INTO NhaSanXuat(maNXS, tenNSX, maSP, quocGia) VALUES
('H001', N'Nike', 'SP001', N'Hoa Kỳ'),
('H002', N'Adidas', 'SP002', N'Đức'),
('H003', N'Puma', 'SP003', N'Đức');

-- Thêm dữ liệu vào bảng Tho
INSERT INTO Tho (maTho, tenTho, sdt, tienLuong) VALUES
('T001', N'Võ Nhật Hào', '0923523454', 5000000),
('T002', N'Đặng Thành Nhân', '023423543213', 6000000),
('T003', N'Nguyễn Thành Nhân', '01237623476', 7000000);

-- Thêm dữ liệu vào bảng HoaDon
INSERT INTO HoaDon (maHD, maKH, ngayTao) VALUES
('HD001', 'KH001', '2023-11-26'),
('HD002', 'KH002', '2023-11-27'),
('HD003', 'KH003', '2023-11-28');

-- Thêm dữ liệu vào bảng TrangSuc
INSERT INTO TrangSuc (maSP, chatLieu, loai, maTho) VALUES
('SP004', N'Vàng', '1', 'T001'),
('SP005', N'Bạc', '1', 'T002'),
('SP006', N'Bạc', '2', 'T003');

-- Thêm dữ liệu vào bảng ChiTietHoaDon
INSERT INTO ChiTietHoaDon (maHD, maSP, soLuong) VALUES
('HD001', 'SP001', 2),
('HD002', 'SP002', 1),
('HD003', 'SP003', 3);

-- Thêm dữ liệu vào bảng Thuoc
INSERT INTO Thuoc (maSP, maHD) VALUES
('SP001', 'HD001'),
('SP002', 'HD002'),
('SP003', 'HD003');


--FUNCTION TẠO MÃ SỐ KHÁCH HÀNG MỚI
CREATE FUNCTION dbo.LayMaKhachHangMoi()
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @MaKhachHangMoi VARCHAR(20);
    SELECT TOP 1 @MaKhachHangMoi = 'KH' + RIGHT('000' + CAST(CONVERT(INT, SUBSTRING(maKH, 3, LEN(maKH))) + 1 AS VARCHAR), 3)
    FROM KhachHang
    ORDER BY maKH DESC;
    
    IF @MaKhachHangMoi IS NULL
        SET @MaKhachHangMoi = 'KH001';
    RETURN @MaKhachHangMoi;
END;

--GỌI FUNCTION 
DECLARE @MaKhachHangMoi VARCHAR(20);
SET @MaKhachHangMoi = dbo.LayMaKhachHangMoi();
PRINT @MaKhachHangMoi;

--PROCEDURE ĐỂ THÊM KHÁCH HÀNG VÀO BẢNG
-- TẠO STORED PROCEDURE
CREATE PROCEDURE dbo.ThemKhachHangMoi
    @TenKH NVARCHAR(255),
    @SDT VARCHAR(20),
    @DiaChi NVARCHAR(255)
AS
BEGIN
    DECLARE @MaKH VARCHAR(20);
    -- GỌI FUNCTION ĐỂ LẤY MÃ KHÁCH HÀNG MỚI
    SET @MaKH = dbo.LayMaKhachHangMoi();
    -- THÊM DỮ LIỆU VÀO BẢNG KHÁCH HÀNG
    INSERT INTO KhachHang (maKH, tenKH, sdt, diaChi)
    VALUES (@MaKH, @TenKH, @SDT, @DiaChi);
END;

-- SỬ DỤNG PROCEDURE
EXEC dbo.ThemKhachHangMoi 
    @TenKH = N'Nguyễn Văn A',
    @SDT = '0923523534',
    @DiaChi = N'Vũng Tàu';

--FUNCTION TẠO MÃ SỐ THỢ MỚI 
CREATE FUNCTION dbo.MaThoMoi()
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @MaThoMoi VARCHAR(20);
    SELECT TOP 1 @MaThoMoi = 'T' + RIGHT('000' + CAST(CONVERT(INT, SUBSTRING(maTho, 3, LEN(maTho))) + 1 AS VARCHAR), 3)
    FROM Tho
    ORDER BY maTho DESC;
    
    IF @MaThoMoi IS NULL
        SET @MaThoMoi = 'T001';
    RETURN @MaThoMoi;
END;

--GỌI FUNCTION TẠO MÃ THỢ MỚI
DECLARE @MaThoMoi VARCHAR(20);
SET @MaThoMoi = dbo.MaThoMoi();
PRINT @MaThoMoi;

--PROCEDURE THÊM THỢ MỚI VÀO BẢNG THỢ
-- TẠO STORED PROCEDURE
CREATE PROCEDURE dbo.ThemThoMoi
    @TenTho NVARCHAR(255),
    @SDT VARCHAR(20),
    @TienLuong INT
AS
BEGIN
    DECLARE @MaTho VARCHAR(20);
    -- GỌI FUNCTION ĐỂ LẤY MÃ THỢ MỚI
    SET @MaTho = dbo.MaThoMoi();
    -- THÊM DỮ LIỆU VÀO BẢNG THỢ
    INSERT INTO Tho(maTho, tenTho, sdt, tienLuong)
    VALUES (@MaTho, @TenTho, @SDT, @TienLuong);
END;

-- SỬ DỤNG PROCEDURE ĐỂ THÊM THỢ MỚI 
EXEC dbo.ThemThoMoi
    @TenTho = N'Nguyễn Văn Nam',
    @SDT = '0934235434',
    @TienLuong = 10000000

--TRIGGER KIỂM TRA RÀNG BUỘC KHÓA NGOẠI VÀ GIÁ TRỊ
CREATE TRIGGER Trigger_CheckChiTietHoaDon
ON ChiTietHoaDon
INSTEAD OF INSERT
AS
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM inserted i
        WHERE i.soLuong > 0 
    )
    BEGIN
        PRINT N'Dữ liệu không hợp lệ! ';
        ROLLBACK;
        RETURN;
    END

    -- KIỂM TRA RÀNG BUỘC KHÓA NGOẠI
    IF EXISTS (
        SELECT 1
        FROM inserted i
        LEFT JOIN HoaDon hd ON i.maHD = hd.maHD
        WHERE hd.maHD IS NULL
    )
    BEGIN
        PRINT N'Ràng buộc khóa ngoại với bảng HoaDon không hợp lệ!';
        ROLLBACK;
        RETURN;
    END

    IF EXISTS (
        SELECT 1
        FROM inserted i
        LEFT JOIN SanPham sp ON i.maSP = sp.maSP
        WHERE sp.maSP IS NULL
    )
    BEGIN
        PRINT N'Ràng buộc khóa ngoại với bảng SanPham không hợp lệ!';
        ROLLBACK;
        RETURN;
    END
    -- Chèn dữ liệu vào bảng nếu thỏa mãn
    INSERT INTO ChiTietHoaDon (maHD, maSP, soLuong)
    SELECT maHD, maSP, soLuong
    FROM inserted;
END;


INSERT INTO ChiTietHoaDon (maHD, maSP, soLuong) VALUES
('HD001', 'SP001', 0)
INSERT INTO ChiTietHoaDon (maHD, maSP, soLuong) VALUES
('HD001', 'SP020', 5)