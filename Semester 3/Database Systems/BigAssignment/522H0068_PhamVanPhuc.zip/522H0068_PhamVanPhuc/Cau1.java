import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

class Attribute {
    String name;
    boolean isPK;
    boolean isFK;

    public Attribute(Attribute newAttribute) {
        this.name = newAttribute.name;
        this.isPK = newAttribute.isFK;
        this.isFK = newAttribute.isPK;
    }

    public Attribute(String name, boolean isPK) {
        this.name = name;
        this.isPK = isPK;
        this.isFK = false;
    }

    public Attribute(String name) {
        this.name = name;
        this.isFK = false;
        this.isPK = false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isPK() {
        return isPK;
    }

    public void setPK(boolean isPK) {
        this.isPK = isPK;
    }

    public boolean isFK() {
        return isFK;
    }

    public void setFK(boolean isFK) {
        this.isFK = isFK;
    }

    @Override
    public String toString() {
        String result = this.name;
        if (isPK && isFK) {
            result += "(PK,FK)";
        } else if (isPK) {
            result += "(PK)";
        } else if (isFK) {
            result += "(FK)";
        }
        return result;
    }
}

class Table {
    String name;
    ArrayList<Attribute> attributes = new ArrayList<>();

    public Table(String name) {
        this.name = name;
    }

    public void addAttribute(Attribute attribute) {
        attributes.add(attribute);

    }

    public void addFK(Attribute attribute) {
        Attribute newAttribute = new Attribute(attribute.getName());
        boolean tmp = attribute.isPK();
        newAttribute.setPK(tmp);
        newAttribute.setFK(true);
        attributes.add(newAttribute);
    }

    public ArrayList<Attribute> getPK() {
        ArrayList<Attribute> listPK = new ArrayList<>();
        for (Attribute attribute : attributes) {
            if (attribute.isPK()) {
                listPK.add(attribute);
            }
        }
        return listPK;
    }

    public ArrayList<Attribute> getFK() {
        ArrayList<Attribute> listFK = new ArrayList<>();
        for (Attribute attribute : attributes) {
            if (attribute.isFK()) {
                listFK.add(attribute);
            }
        }
        return listFK;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Attribute> getAttributes() {
        return attributes;
    }

    public void setAttributes(ArrayList<Attribute> attributes) {
        this.attributes = attributes;
    }

    @Override
    public String toString() {

        return name + " " + attributes;
    }

}

class Relationship {
    String table1;
    String table2;
    String typeRela;
    String connected;
    ArrayList<String> connnectAttri = new ArrayList<>();

    public ArrayList<String> getConnnectAttri() {
        return connnectAttri;
    }

    public void addConnnectAttri(String connnectAttri) {
        this.connnectAttri.add(connnectAttri);
    }

    public Relationship(String table1, String table2, String typeRela) {
        this.table1 = table1;
        this.table2 = table2;
        this.typeRela = typeRela;
        this.connected = "";
        ;
    }

    public Relationship(String table1, String table2, String typeRela, String connected) {
        this.table1 = table1;
        this.table2 = table2;
        this.typeRela = typeRela;
        this.connected = connected;

    }

    public String getTable1() {
        return table1;
    }

    public void setTable1(String table1) {
        this.table1 = table1;
    }

    public String getTable2() {
        return table2;
    }

    public void setTable2(String table2) {
        this.table2 = table2;
    }

    public String getTypeRela() {
        return typeRela;
    }

    public void setTypeRela(String typeRela) {
        this.typeRela = typeRela;
    }

    @Override
    public String toString() {
        String resuls = table1 + " " + table2 + " " + connnectAttri;
        return resuls;
    }

    public String getConnected() {
        return connected;
    }

    public void setConnected(String connected) {
        this.connected = connected;
    }

}

public class Cau1 {
    public static void main(String[] args) {
        ArrayList<Table> tables = new ArrayList<>();
        ArrayList<Relationship> relationships = new ArrayList<>();
        ArrayList<Relationship> temp = new ArrayList<>();
        readDataFromFile("Input1.txt", tables, relationships);

        // process
        for (Relationship rela : relationships) {
            switch (rela.getTypeRela()) {
                case "1-1":
                    ArrayList<Attribute> pk = new ArrayList<>();
                    for (Table table : tables) {
                        if (table.getName().equals(rela.getTable1())) {
                            pk = table.getPK();
                        }
                    }

                    for (Table table : tables) {
                        if (table.getName().equals(rela.getTable2())) {
                            for (Attribute attribute : pk) {
                                Attribute newAttribute = new Attribute(attribute.getName());
                                newAttribute.setPK(false);
                                table.addFK(newAttribute);
                            }
                        }
                    }

                    for (Attribute attribute : pk) {
                        rela.addConnnectAttri(attribute.getName());
                    }
                    break;

                case "1-N":
                    ArrayList<Attribute> pk1 = new ArrayList<>();
                    for (Table table : tables) {
                        if (table.getName().equals(rela.getTable1())) {
                            pk1 = table.getPK();
                        }
                    }

                    for (Table table : tables) {
                        if (table.getName().equals(rela.getTable2())) {
                            for (Attribute attribute : pk1) {
                                Attribute newAttribute = new Attribute(attribute.getName());
                                newAttribute.setPK(false);
                                table.addFK(newAttribute);
                            }
                        }
                    }
                    for (Attribute attribute : pk1) {
                        rela.addConnnectAttri(attribute.getName());
                    }
                    break;

                case "N-N":
                    ArrayList<Attribute> listPK1 = new ArrayList<>();
                    ArrayList<Attribute> listPK2 = new ArrayList<>();
                    for (Table table : tables) {
                        if (table.getName().equals(rela.getTable1())) {
                            for (Attribute attribute : table.getPK()) {
                                listPK1.add(attribute);
                            }
                        }
                    }
                    for (Table table : tables) {
                        if (table.getName().equals(rela.getTable2())) {
                            for (Attribute attribute : table.getPK()) {
                                listPK2.add(attribute);
                            }
                        }
                    }

                    Table newTable = new Table(rela.getConnected());
                    for (Attribute attribute : listPK1) {
                        newTable.addFK(attribute);
                    }
                    for (Attribute attribute : listPK2) {
                        newTable.addFK(attribute);
                    }
                    tables.add(newTable);

                    Relationship newRelationship = new Relationship(newTable.getName(), rela.getTable1(), "", "");
                    for (Attribute attribute : listPK1) {
                        newRelationship.addConnnectAttri(attribute.getName());
                    }
                    temp.add(newRelationship);

                    newRelationship = new Relationship(newTable.getName(), rela.getTable2(), "", "");
                    for (Attribute attribute : listPK2) {
                        newRelationship.addConnnectAttri(attribute.getName());
                    }
                    temp.add(newRelationship);

                    break;
                case "KETHUA":
                    ArrayList<Attribute> atri = new ArrayList<>();
                    for (Table table : tables) {
                        if (table.getName().equals(rela.getTable2())) {
                            atri = table.getAttributes();
                        }
                    }
                    for (Table table : tables) {
                        if (table.getName().equals(rela.getTable1())) {
                            for (Attribute atrAttribute : atri) {
                                if (atrAttribute.isPK()) {
                                    table.addFK(atrAttribute);
                                    rela.addConnnectAttri(atrAttribute.getName());
                                } else {
                                    table.addAttribute(atrAttribute);
                                }
                            }
                        }
                    }
                    break;
                default:
                    break;

            }
        }

        for (Relationship relationship : temp) {
            relationships.add(relationship);
        }

        ArrayList<Relationship> temp1 = new ArrayList<>(relationships);
        for (Relationship relationship : temp1) {
            if (relationship.getTypeRela().equals("N-N")) {
                relationships.remove(relationship);
            }
        }
        writeDataToFile("Output1.txt", tables, relationships);
    }

    private static void readDataFromFile(String filePath, ArrayList<Table> tables,
            ArrayList<Relationship> relationships) {
        try {
            File file = new File(filePath);
            Scanner scanner = new Scanner(file);

            boolean isRelationship = true;

            scanner.nextLine();
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.equals("Relationship")) {
                    isRelationship = false;
                    continue;
                }
                if (isRelationship) {
                    String[] parts = line.split(" ");
                    Table table = new Table(parts[0].trim());
                    for (int i = 1; i < parts.length; i++) {
                        String attributeName = " ";
                        Attribute attribute = null;
                        if (parts[i].contains("(PK)")) {
                            attributeName = parts[i].substring(0, parts[i].length() - 4);
                            attribute = new Attribute(attributeName, true);
                        } else {
                            attributeName = parts[i];
                            attribute = new Attribute(attributeName);
                        }
                        table.addAttribute(attribute);
                    }
                    tables.add(table);
                } else {
                    String[] parts = line.split(" ");
                    if (line.contains("KETHUA")) {
                        Relationship relation = new Relationship(parts[0], parts[2], parts[1]);
                        relationships.add(relation);
                    } else {
                        Relationship relation = new Relationship(parts[0], parts[2], parts[1], parts[3]);
                        relationships.add(relation);
                    }
                }
            }
            scanner.close();
        } catch (IOException e) {
            System.err.println("Error reading from the file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void writeDataToFile(String filePath, ArrayList<Table> tables,
            ArrayList<Relationship> relationships) {
        try {
            File file = new File(filePath);
            FileWriter fileWriter = new FileWriter(file);
            PrintWriter printWriter = new PrintWriter(fileWriter);

            printWriter.println("Tables : ");
            for (Table table : tables) {
                printWriter.println(table.toString());
            }

            printWriter.println();
            printWriter.println("Realtionship : ");

            for (Relationship relationship : relationships) {
                printWriter.println(relationship.toString());
            }

            printWriter.close();
            System.out.println("Write file completed");
        } catch (IOException e) {
            System.err.println("Error writing to the file: " + e.getMessage());
            e.printStackTrace();
        }
    }
}