<?php

require_once "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['productId'])) {
        $productId = $_POST['productId'];
        // Thực hiện xóa sản phẩm từ cơ sở dữ liệu với productId đã nhận được
        $sql = "DELETE FROM product WHERE id = $productId";
        if ($conn->query($sql) === TRUE) {
        } else {
        }
    } else {
    }
}
?>