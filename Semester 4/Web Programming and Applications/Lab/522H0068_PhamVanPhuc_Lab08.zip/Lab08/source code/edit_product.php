<?php
require_once "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $productId = $_POST['productId'];
    $productName = $_POST['productName'];
    $productPrice = $_POST['productPrice'];
    $productDescription = $_POST['productDescription'];

    $sql = "UPDATE product SET name = '$productName', price = '$productPrice', description = '$productDescription' WHERE id = '$productId'";

    if ($conn->query($sql) === TRUE) {
        echo "Product updated successfully";
    } else {
        echo "Error updating product: " . $conn->error;
    }
    $conn->close();
}
?>
