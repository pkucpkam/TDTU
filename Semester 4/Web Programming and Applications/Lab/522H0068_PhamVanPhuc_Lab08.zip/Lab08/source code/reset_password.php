<?php
$error = '';

if (isset($_GET['reset_token']) && isset($_GET['email'])) {
    $email = $_GET['email'];
    $token = $_GET['reset_token'];

    $pass = $_POST['pass'];
    $pass_confirm = $_POST['pass-confirm'];

    if (empty($email)) {
        $error = 'Please enter your email';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'This is not a valid email address';
    } elseif (empty($pass)) {
        $error = 'Please enter your password';
    } elseif (strlen($pass) < 6) {
        $error = 'Password must have at least 6 characters';
    } elseif ($pass != $pass_confirm) {
        $error = 'Passwords do not match';
    } else {
        require_once "database.php";

        $stmt = $conn->prepare("SELECT * FROM reset_token WHERE email = ? AND token = ?");
        $stmt->bind_param("ss", $email, $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 0) {
            $error = 'Invalid reset token';
        } else {
            $row = $result->fetch_assoc();
            $expire_on = $row['expire_on'];

            if ($expire_on < time()) {
                $error = 'Reset token has expired';
            } else {
                $stmt = $conn->prepare("UPDATE account SET password = ? WHERE email = ?");
                $hashed_password = password_hash($pass, PASSWORD_DEFAULT);
                $stmt->bind_param("ss", $hashed_password, $email);

                if ($stmt->execute()) {
                    $stmt = $conn->prepare("DELETE FROM reset_token WHERE email = ?");
                    $stmt->bind_param("s", $email);
                    $stmt->execute();

                    header("Location: login.php?password_reset=success");
                    exit();
                } else {
                    $error = 'Error updating password: ' . $conn->error;
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Reset user password</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.5.3/css/bootstrap.min.css" integrity="sha512-oc9+XSs1H243/FRN9Rw62Fn8EtxjEYWHXRvjS43YtueEewbS6ObfXcJNyohjHqVKFPoXXUxwc+q1K7Dee6vv9g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.5.3/js/bootstrap.min.js" integrity="sha512-8qmis31OQi6hIRgvkht0s6mCOittjMa9GMqtK9hes5iEQBQE/Ca6yGE5FsW36vyipGoWQswBj/QBm2JR086Rkw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.11.8/umd/popper.min.js" integrity="sha512-TPh2Oxlg1zp+kz3nFA0C5vVC6leG/6mm1z9+mA81MI5eaUVqasPLO8Cuk4gMF4gUfP5etR73rgU/8PNMsSesoQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <h3 class="text-center text-secondary mt-5 mb-3">Reset Password</h3>
                <form novalidate method="post" action="" class="border rounded w-100 mb-5 mx-auto px-3 pt-3 bg-light">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input readonly value="<?= isset($_GET['email']) ? htmlspecialchars($_GET['email']) : ''; ?>" name="email" id="email" type="text" class="form-control" placeholder="Email address">
                    </div>
                    <div class="form-group">
                        <label for="pass">Password</label>
                        <input value="<?= isset($_POST['pass']) ? htmlspecialchars($_POST['pass']) : ''; ?>" name="pass" required class="form-control" type="password" placeholder="Password" id="pass">
                        <div class="invalid-feedback">Password is not valid.</div>
                    </div>
                    <div class="form-group">
                        <label for="pass2">Confirm Password</label>
                        <input value="<?= isset($_POST['pass-confirm']) ? htmlspecialchars($_POST['pass-confirm']) : ''; ?>" name="pass-confirm" required class="form-control" type="password" placeholder="Confirm Password" id="pass2">
                        <div class="invalid-feedback">Password is not valid.</div>
                    </div>
                    <div class="form-group">
                        <?php if (!empty($error)) : ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php elseif (isset($_GET['password_reset']) && $_GET['password_reset'] === 'success') : ?>
                            <div class="alert alert-success">Password reset successfully. You can now <a href="login.php">login</a> with your new password.</div>
                        <?php endif; ?>
                        <button class="btn btn-success px-5">Change password</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>