<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/PHPMailer-master/src/SMTP.php';

// Khai báo các thông tin cần thiết
$to_email = "channel.topdz@gmail.com";
$subject = "Test Email from PHPMailer";
$body = "This is a test email sent from PHPMailer.";

// Tạo một đối tượng PHPMailer
$mail = new PHPMailer(true);

try {
    // Cài đặt thông số gửi email
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'phucpham.1803@gmail.com'; // Địa chỉ email của bạn
    $mail->Password = 'phamvanphuc'; // Mật khẩu email của bạn
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    // Thiết lập thông tin người gửi và người nhận
    $mail->setFrom('your_email@gmail.com', 'Your Name');
    $mail->addAddress($to_email);

    // Thiết lập tiêu đề và nội dung của email
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $body;

    // Gửi email
    if ($mail->send()) {
        echo "Email sent successfully!";
    } else {
        echo "Error sending email: " . $mail->ErrorInfo;
    }
} catch (Exception $e) {
    echo "Error sending email: " . $mail->ErrorInfo;
}
?>
