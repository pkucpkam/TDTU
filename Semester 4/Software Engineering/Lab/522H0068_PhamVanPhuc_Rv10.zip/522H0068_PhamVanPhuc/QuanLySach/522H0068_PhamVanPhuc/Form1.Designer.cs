﻿namespace _522H0068_PhamVanPhuc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtTIM = new System.Windows.Forms.TextBox();
            this.textBox = new System.Windows.Forms.Label();
            this.BTIM = new System.Windows.Forms.Button();
            this.grp3 = new System.Windows.Forms.GroupBox();
            this.grd1 = new System.Windows.Forms.DataGridView();
            this.grp1 = new System.Windows.Forms.GroupBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.txtTacGia = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTenSach = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaSach = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grp2 = new System.Windows.Forms.GroupBox();
            this.BIN = new System.Windows.Forms.Button();
            this.BLUU = new System.Windows.Forms.Button();
            this.BSUA = new System.Windows.Forms.Button();
            this.BXOA = new System.Windows.Forms.Button();
            this.BTHEM = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.grp3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd1)).BeginInit();
            this.grp1.SuspendLayout();
            this.grp2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtTIM);
            this.groupBox2.Controls.Add(this.textBox);
            this.groupBox2.Controls.Add(this.BTIM);
            this.groupBox2.Location = new System.Drawing.Point(80, 199);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(641, 52);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tìm kiếm";
            // 
            // txtTIM
            // 
            this.txtTIM.Location = new System.Drawing.Point(205, 21);
            this.txtTIM.Name = "txtTIM";
            this.txtTIM.Size = new System.Drawing.Size(213, 27);
            this.txtTIM.TabIndex = 4;
            // 
            // textBox
            // 
            this.textBox.AutoSize = true;
            this.textBox.Location = new System.Drawing.Point(86, 21);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(63, 20);
            this.textBox.TabIndex = 3;
            this.textBox.Text = "Mã sách";
            // 
            // BTIM
            // 
            this.BTIM.Location = new System.Drawing.Point(465, 18);
            this.BTIM.Name = "BTIM";
            this.BTIM.Size = new System.Drawing.Size(80, 30);
            this.BTIM.TabIndex = 2;
            this.BTIM.Text = "Tìm";
            this.BTIM.UseVisualStyleBackColor = true;
            this.BTIM.Click += new System.EventHandler(this.BTIM_Click);
            // 
            // grp3
            // 
            this.grp3.Controls.Add(this.grd1);
            this.grp3.Location = new System.Drawing.Point(83, 257);
            this.grp3.Name = "grp3";
            this.grp3.Size = new System.Drawing.Size(638, 271);
            this.grp3.TabIndex = 13;
            this.grp3.TabStop = false;
            this.grp3.Text = "Thông tin về sách";
            // 
            // grd1
            // 
            this.grd1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd1.Location = new System.Drawing.Point(19, 26);
            this.grd1.Name = "grd1";
            this.grd1.RowHeadersWidth = 51;
            this.grd1.RowTemplate.Height = 29;
            this.grd1.Size = new System.Drawing.Size(601, 239);
            this.grd1.TabIndex = 0;
            this.grd1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grd1_CellClick);
            // 
            // grp1
            // 
            this.grp1.Controls.Add(this.txtSoLuong);
            this.grp1.Controls.Add(this.txtTacGia);
            this.grp1.Controls.Add(this.label8);
            this.grp1.Controls.Add(this.label3);
            this.grp1.Controls.Add(this.txtTenSach);
            this.grp1.Controls.Add(this.label2);
            this.grp1.Controls.Add(this.txtMaSach);
            this.grp1.Controls.Add(this.label1);
            this.grp1.Location = new System.Drawing.Point(80, 14);
            this.grp1.Name = "grp1";
            this.grp1.Size = new System.Drawing.Size(641, 110);
            this.grp1.TabIndex = 11;
            this.grp1.TabStop = false;
            this.grp1.Text = "Quản lý sách";
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(380, 74);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(181, 27);
            this.txtSoLuong.TabIndex = 7;
            // 
            // txtTacGia
            // 
            this.txtTacGia.Location = new System.Drawing.Point(97, 74);
            this.txtTacGia.Name = "txtTacGia";
            this.txtTacGia.Size = new System.Drawing.Size(181, 27);
            this.txtTacGia.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(309, 77);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 20);
            this.label8.TabIndex = 5;
            this.label8.Text = "Số lượng";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Tác giả";
            // 
            // txtTenSach
            // 
            this.txtTenSach.Location = new System.Drawing.Point(380, 33);
            this.txtTenSach.Name = "txtTenSach";
            this.txtTenSach.Size = new System.Drawing.Size(243, 27);
            this.txtTenSach.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(309, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tên sách";
            // 
            // txtMaSach
            // 
            this.txtMaSach.Location = new System.Drawing.Point(96, 30);
            this.txtMaSach.Name = "txtMaSach";
            this.txtMaSach.Size = new System.Drawing.Size(179, 27);
            this.txtMaSach.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã sách";
            // 
            // grp2
            // 
            this.grp2.Controls.Add(this.BIN);
            this.grp2.Controls.Add(this.BLUU);
            this.grp2.Controls.Add(this.BSUA);
            this.grp2.Controls.Add(this.BXOA);
            this.grp2.Controls.Add(this.BTHEM);
            this.grp2.Location = new System.Drawing.Point(80, 130);
            this.grp2.Name = "grp2";
            this.grp2.Size = new System.Drawing.Size(641, 63);
            this.grp2.TabIndex = 12;
            this.grp2.TabStop = false;
            this.grp2.Text = "Thao tác";
            // 
            // BIN
            // 
            this.BIN.Location = new System.Drawing.Point(514, 26);
            this.BIN.Name = "BIN";
            this.BIN.Size = new System.Drawing.Size(80, 30);
            this.BIN.TabIndex = 2;
            this.BIN.Text = "In";
            this.BIN.UseVisualStyleBackColor = true;
            this.BIN.Click += new System.EventHandler(this.BIN_Click);
            // 
            // BLUU
            // 
            this.BLUU.Location = new System.Drawing.Point(402, 26);
            this.BLUU.Name = "BLUU";
            this.BLUU.Size = new System.Drawing.Size(80, 30);
            this.BLUU.TabIndex = 2;
            this.BLUU.Text = "Lưu";
            this.BLUU.UseVisualStyleBackColor = true;
            this.BLUU.Click += new System.EventHandler(this.BLUU_Click);
            // 
            // BSUA
            // 
            this.BSUA.Location = new System.Drawing.Point(277, 26);
            this.BSUA.Name = "BSUA";
            this.BSUA.Size = new System.Drawing.Size(80, 30);
            this.BSUA.TabIndex = 2;
            this.BSUA.Text = "Sửa";
            this.BSUA.UseVisualStyleBackColor = true;
            this.BSUA.Click += new System.EventHandler(this.BSUA_Click);
            // 
            // BXOA
            // 
            this.BXOA.Location = new System.Drawing.Point(146, 26);
            this.BXOA.Name = "BXOA";
            this.BXOA.Size = new System.Drawing.Size(80, 30);
            this.BXOA.TabIndex = 1;
            this.BXOA.Text = "Xóa";
            this.BXOA.UseVisualStyleBackColor = true;
            this.BXOA.Click += new System.EventHandler(this.BXOA_Click);
            // 
            // BTHEM
            // 
            this.BTHEM.Location = new System.Drawing.Point(29, 26);
            this.BTHEM.Name = "BTHEM";
            this.BTHEM.Size = new System.Drawing.Size(80, 30);
            this.BTHEM.TabIndex = 0;
            this.BTHEM.Text = "Thêm";
            this.BTHEM.UseVisualStyleBackColor = true;
            this.BTHEM.Click += new System.EventHandler(this.BTHEM_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 542);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.grp3);
            this.Controls.Add(this.grp1);
            this.Controls.Add(this.grp2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grp3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grd1)).EndInit();
            this.grp1.ResumeLayout(false);
            this.grp1.PerformLayout();
            this.grp2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox2;
        private TextBox txtTIM;
        private Label textBox;
        private Button BTIM;
        private GroupBox grp3;
        private DataGridView grd1;
        private GroupBox grp1;
        private TextBox txtSoLuong;
        private TextBox txtTacGia;
        private Label label8;
        private Label label3;
        private TextBox txtTenSach;
        private Label label2;
        private TextBox txtMaSach;
        private Label label1;
        private GroupBox grp2;
        private Button BIN;
        private Button BLUU;
        private Button BSUA;
        private Button BXOA;
        private Button BTHEM;
    }
}