﻿use master 
create database ThuVien2
use ThuVien2
-- Tạo bảng Độc giả
CREATE TABLE DocGia (
    MaDocGia VARCHAR(10) PRIMARY KEY,
    HoTen NVARCHAR(50),
    NgaySinh DATE
);

-- Tạo bảng Sách
CREATE TABLE Sach (
    MaSach VARCHAR(10) PRIMARY KEY,
    TenSach NVARCHAR(100),
    TacGia NVARCHAR(50),
    SoLuong INT
);

-- Tạo bảng MuonSach
CREATE TABLE MuonSach (
    MaPhieuMuon VARCHAR(20) PRIMARY KEY,
    MaDocGia VARCHAR(10),
    NgayMuon DATE,
    FOREIGN KEY (MaDocGia) REFERENCES DocGia(MaDocGia)
);

-- Tạo bảng ChiTietPhieuMuon
CREATE TABLE ChiTietPhieuMuon (
    MaPhieuMuon VARCHAR(20),
    MaSach VARCHAR(10),
    NgayTra DATE,
    PRIMARY KEY (MaPhieuMuon, MaSach),
    FOREIGN KEY (MaPhieuMuon) REFERENCES MuonSach(MaPhieuMuon),
    FOREIGN KEY (MaSach) REFERENCES Sach(MaSach)
);

--Insert data
-- Thêm dữ liệu vào bảng Độc giả
INSERT INTO DocGia (MaDocGia, HoTen, NgaySinh) VALUES
('DG001', 'Nguyen Van A', '1990-05-15'),
('DG002', 'Tran Thi B', '1985-08-20'),
('DG003', 'Le Van C', '1995-02-10');

-- Thêm dữ liệu vào bảng Sách
INSERT INTO Sach (MaSach, TenSach, TacGia, SoLuong) VALUES
('MS101', 'Sach 1', 'Tac Gia 1', 20),
('MS102', 'Sach 2', 'Tac Gia 2', 15),
('MS103', 'Sach 3', 'Tac Gia 3', 25);

-- Thêm dữ liệu vào bảng MuonSach
INSERT INTO MuonSach (MaPhieuMuon, MaDocGia, NgayMuon) VALUES
('20240413-001', 'DG001', '2024-03-01'),
('20240414-002', 'DG002', '2024-03-05'),
('20240415-003', 'DG003', '2024-03-08');

-- Thêm dữ liệu vào bảng ChiTietPhieuMuon
INSERT INTO ChiTietPhieuMuon (MaPhieuMuon, MaSach, NgayTra) VALUES
('20240413-001', 'MS101', '2024-03-10'),
('20240413-001', 'MS102', '2024-03-10'),
('20240414-002', 'MS103', '2024-03-12'),
('20240415-003', 'MS101', '2024-03-15');


select * from MuonSach


