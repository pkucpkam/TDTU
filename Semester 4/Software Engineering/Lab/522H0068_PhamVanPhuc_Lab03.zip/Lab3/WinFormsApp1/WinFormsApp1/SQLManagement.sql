﻿use master
create database Students
use Students

CREATE TABLE Student (
    StudentID VARCHAR(10) PRIMARY KEY,
    FullName VARCHAR(50),
    Hometown VARCHAR(50),
    DOB DATE,
    GPA DECIMAL(3, 1)
);

CREATE TABLE Project (
    ProjectID VARCHAR(10) PRIMARY KEY,
    ProjectName VARCHAR(50),
    Supervisor VARCHAR(50),
    Funding FLOAT
);

CREATE TABLE Student_Project (
    StudentID VARCHAR(10),
    ProjectID VARCHAR(10),
    InternshipPlace VARCHAR(50),
    Distance INT,
    Results DECIMAL(3, 1),
    PRIMARY KEY (StudentID, ProjectID),
    FOREIGN KEY (StudentID) REFERENCES Student(StudentID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);

INSERT INTO student
VALUES
    ('SV01', 'Trần Thanh Trâm', 'Sài Gòn', '1998-03-23', 8.5),
    ('SV02', 'Nguyễn Hồng Linh', 'Thanh Hóa', '2000-01-20', 9.0),
    ('SV03', 'Trần Thanh Phước', 'Tiền Giang', '2001-07-12', 7.5),
    ('SV04', 'Nguyễn Minh Hải', 'Nghệ An', '1993-02-28', 7.0),
    ('SV05', 'Trần Thị Hồng Nhung', 'Kiên Giang', '1998-07-15', 9.0);

INSERT INTO Project
VALUES
    ('DT01', 'Quản lý quán ăn', 'Nguyễn Thễ Hữu', 100000000),
    ('DT02', 'Quản lý khách sạn', 'Trần Trung Hiếu', 200000000),
    ('DT03', 'Quản lý sân bóng đá mini', 'Nguyễn Công Tâm', 300000000),
    ('DT04', 'Quản lý shop hoa tươi', 'Đặng Đức Trung', 150000000),
    ('DT05', 'Quản lý cửa hàng điện thoại', 'Trịnh Thanh Duy', 2000000000);

INSERT INTO Student_Project
VALUES
    ('SV01', 'DT01', 'Tiền Giang', 70, 8.0),
    ('SV02', 'DT01', 'Bình Dương', 50, 7.0),
    ('SV03', 'DT02', 'Vũng Tàu', 150, 9.5),
    ('SV03', 'DT03', 'Long An', 50, 8.5),
    ('SV04', 'DT03', 'Nha Trang', 500, 10);