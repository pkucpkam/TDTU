﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grb1 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BPRINT1 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.BALL1 = new System.Windows.Forms.Button();
            this.cbChuNhiem = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbQueQuan = new System.Windows.Forms.ComboBox();
            this.BPRINT = new System.Windows.Forms.Button();
            this.BALL = new System.Windows.Forms.Button();
            this.queQuan = new System.Windows.Forms.Label();
            this.grb2 = new System.Windows.Forms.GroupBox();
            this.grd = new System.Windows.Forms.DataGridView();
            this.kpi1 = new System.Windows.Forms.Button();
            this.kpi2 = new System.Windows.Forms.Button();
            this.kpi3 = new System.Windows.Forms.Button();
            this.grb1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grb2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd)).BeginInit();
            this.SuspendLayout();
            // 
            // grb1
            // 
            this.grb1.Controls.Add(this.groupBox1);
            this.grb1.Controls.Add(this.BALL1);
            this.grb1.Controls.Add(this.cbChuNhiem);
            this.grb1.Controls.Add(this.label1);
            this.grb1.Controls.Add(this.cbQueQuan);
            this.grb1.Controls.Add(this.BPRINT);
            this.grb1.Controls.Add(this.BALL);
            this.grb1.Controls.Add(this.queQuan);
            this.grb1.Location = new System.Drawing.Point(23, 19);
            this.grb1.Name = "grb1";
            this.grb1.Size = new System.Drawing.Size(751, 120);
            this.grb1.TabIndex = 0;
            this.grb1.TabStop = false;
            this.grb1.Text = "Tìm kiếm";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BPRINT1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(8, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(751, 120);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm kiếm";
            // 
            // BPRINT1
            // 
            this.BPRINT1.Location = new System.Drawing.Point(548, 77);
            this.BPRINT1.Name = "BPRINT1";
            this.BPRINT1.Size = new System.Drawing.Size(82, 28);
            this.BPRINT1.TabIndex = 8;
            this.BPRINT1.Text = "Xem in";
            this.BPRINT1.UseVisualStyleBackColor = true;
            this.BPRINT1.Click += new System.EventHandler(this.BPRINT1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(440, 77);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 28);
            this.button1.TabIndex = 7;
            this.button1.Text = "Tất cả";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(111, 81);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(277, 28);
            this.comboBox1.TabIndex = 6;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Chủ nhiệm";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(113, 39);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(285, 28);
            this.comboBox2.TabIndex = 4;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(548, 35);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(82, 28);
            this.button2.TabIndex = 3;
            this.button2.Text = "Xem in";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(440, 36);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(82, 28);
            this.button3.TabIndex = 2;
            this.button3.Text = "Tất cả";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Quê quán";
            // 
            // BALL1
            // 
            this.BALL1.Location = new System.Drawing.Point(440, 77);
            this.BALL1.Name = "BALL1";
            this.BALL1.Size = new System.Drawing.Size(82, 28);
            this.BALL1.TabIndex = 7;
            this.BALL1.Text = "Tất cả";
            this.BALL1.UseVisualStyleBackColor = true;
            this.BALL1.Click += new System.EventHandler(this.BALL1_Click);
            // 
            // cbChuNhiem
            // 
            this.cbChuNhiem.FormattingEnabled = true;
            this.cbChuNhiem.Location = new System.Drawing.Point(111, 81);
            this.cbChuNhiem.Name = "cbChuNhiem";
            this.cbChuNhiem.Size = new System.Drawing.Size(277, 28);
            this.cbChuNhiem.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Chủ nhiệm";
            // 
            // cbQueQuan
            // 
            this.cbQueQuan.FormattingEnabled = true;
            this.cbQueQuan.Location = new System.Drawing.Point(113, 39);
            this.cbQueQuan.Name = "cbQueQuan";
            this.cbQueQuan.Size = new System.Drawing.Size(285, 28);
            this.cbQueQuan.TabIndex = 4;
            this.cbQueQuan.SelectedIndexChanged += new System.EventHandler(this.cbQueQuan_SelectedIndexChanged);
            // 
            // BPRINT
            // 
            this.BPRINT.Location = new System.Drawing.Point(548, 35);
            this.BPRINT.Name = "BPRINT";
            this.BPRINT.Size = new System.Drawing.Size(82, 28);
            this.BPRINT.TabIndex = 3;
            this.BPRINT.Text = "Xem in";
            this.BPRINT.UseVisualStyleBackColor = true;
            this.BPRINT.Click += new System.EventHandler(this.BPRINT_Click);
            // 
            // BALL
            // 
            this.BALL.Location = new System.Drawing.Point(440, 36);
            this.BALL.Name = "BALL";
            this.BALL.Size = new System.Drawing.Size(82, 28);
            this.BALL.TabIndex = 2;
            this.BALL.Text = "Tất cả";
            this.BALL.UseVisualStyleBackColor = true;
            this.BALL.Click += new System.EventHandler(this.BALL_Click);
            // 
            // queQuan
            // 
            this.queQuan.AutoSize = true;
            this.queQuan.Location = new System.Drawing.Point(20, 39);
            this.queQuan.Name = "queQuan";
            this.queQuan.Size = new System.Drawing.Size(73, 20);
            this.queQuan.TabIndex = 0;
            this.queQuan.Text = "Quê quán";
            // 
            // grb2
            // 
            this.grb2.Controls.Add(this.grd);
            this.grb2.Location = new System.Drawing.Point(29, 138);
            this.grb2.Name = "grb2";
            this.grb2.Size = new System.Drawing.Size(740, 281);
            this.grb2.TabIndex = 1;
            this.grb2.TabStop = false;
            this.grb2.Text = "Danh sách sinh viên";
            // 
            // grd
            // 
            this.grd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd.Location = new System.Drawing.Point(17, 31);
            this.grd.Name = "grd";
            this.grd.RowHeadersWidth = 51;
            this.grd.RowTemplate.Height = 29;
            this.grd.Size = new System.Drawing.Size(712, 243);
            this.grd.TabIndex = 0;
            // 
            // kpi1
            // 
            this.kpi1.Location = new System.Drawing.Point(815, 34);
            this.kpi1.Name = "kpi1";
            this.kpi1.Size = new System.Drawing.Size(131, 28);
            this.kpi1.TabIndex = 5;
            this.kpi1.Text = "KP <= 10 triệu";
            this.kpi1.UseVisualStyleBackColor = true;
            this.kpi1.Click += new System.EventHandler(this.kpi1_Click);
            // 
            // kpi2
            // 
            this.kpi2.Location = new System.Drawing.Point(815, 78);
            this.kpi2.Name = "kpi2";
            this.kpi2.Size = new System.Drawing.Size(131, 28);
            this.kpi2.TabIndex = 6;
            this.kpi2.Text = "KP <= 100 triệu";
            this.kpi2.UseVisualStyleBackColor = true;
            this.kpi2.Click += new System.EventHandler(this.kpi2_Click);
            // 
            // kpi3
            // 
            this.kpi3.Location = new System.Drawing.Point(815, 122);
            this.kpi3.Name = "kpi3";
            this.kpi3.Size = new System.Drawing.Size(131, 28);
            this.kpi3.TabIndex = 7;
            this.kpi3.Text = "KP > 100 triệu";
            this.kpi3.UseVisualStyleBackColor = true;
            this.kpi3.Click += new System.EventHandler(this.kpi3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1063, 450);
            this.Controls.Add(this.kpi3);
            this.Controls.Add(this.kpi2);
            this.Controls.Add(this.kpi1);
            this.Controls.Add(this.grb2);
            this.Controls.Add(this.grb1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grb1.ResumeLayout(false);
            this.grb1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grb2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grd)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox grb1;
        private ComboBox cbQueQuan;
        private Button BPRINT;
        private Button BALL;
        private Label queQuan;
        private GroupBox grb2;
        private DataGridView grd;
        private Button kpi1;
        private Button kpi2;
        private Button kpi3;
        private Button BALL1;
        private ComboBox cbChuNhiem;
        private Label label1;
        private GroupBox groupBox1;
        private Button BPRINT1;
        private Button button1;
        private ComboBox comboBox1;
        private Label label2;
        private ComboBox comboBox2;
        private Button button2;
        private Button button3;
        private Label label3;
    }
}