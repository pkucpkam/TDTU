﻿namespace _522H0068_PhamVanPhuc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTIM = new System.Windows.Forms.TextBox();
            this.textBox = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BTIM = new System.Windows.Forms.Button();
            this.txtTacGia = new System.Windows.Forms.TextBox();
            this.grp4 = new System.Windows.Forms.GroupBox();
            this.CHITIET = new System.Windows.Forms.Button();
            this.SHOW = new System.Windows.Forms.Button();
            this.ngayTRA = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.BMUON = new System.Windows.Forms.Button();
            this.ngayMuon = new System.Windows.Forms.DateTimePicker();
            this.maSachMuon = new System.Windows.Forms.TextBox();
            this.maDGMuon = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.grd1 = new System.Windows.Forms.DataGridView();
            this.grp3 = new System.Windows.Forms.GroupBox();
            this.BTHEM = new System.Windows.Forms.Button();
            this.grp1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTenSach = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaSach = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grp2 = new System.Windows.Forms.GroupBox();
            this.BIN = new System.Windows.Forms.Button();
            this.BLUU = new System.Windows.Forms.Button();
            this.BSUA = new System.Windows.Forms.Button();
            this.BXOA = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.grd2 = new System.Windows.Forms.DataGridView();
            this.groupBox2.SuspendLayout();
            this.grp4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd1)).BeginInit();
            this.grp3.SuspendLayout();
            this.grp1.SuspendLayout();
            this.grp2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd2)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(380, 74);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(181, 27);
            this.txtSoLuong.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(309, 77);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 20);
            this.label8.TabIndex = 5;
            this.label8.Text = "Số lượng";
            // 
            // txtTIM
            // 
            this.txtTIM.Location = new System.Drawing.Point(205, 21);
            this.txtTIM.Name = "txtTIM";
            this.txtTIM.Size = new System.Drawing.Size(213, 27);
            this.txtTIM.TabIndex = 4;
            // 
            // textBox
            // 
            this.textBox.AutoSize = true;
            this.textBox.Location = new System.Drawing.Point(86, 21);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(63, 20);
            this.textBox.TabIndex = 3;
            this.textBox.Text = "Mã sách";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtTIM);
            this.groupBox2.Controls.Add(this.textBox);
            this.groupBox2.Controls.Add(this.BTIM);
            this.groupBox2.Location = new System.Drawing.Point(12, 197);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(641, 52);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tìm kiếm";
            // 
            // BTIM
            // 
            this.BTIM.Location = new System.Drawing.Point(465, 18);
            this.BTIM.Name = "BTIM";
            this.BTIM.Size = new System.Drawing.Size(80, 30);
            this.BTIM.TabIndex = 2;
            this.BTIM.Text = "Tìm";
            this.BTIM.UseVisualStyleBackColor = true;
            this.BTIM.Click += new System.EventHandler(this.BTIM_Click);
            // 
            // txtTacGia
            // 
            this.txtTacGia.Location = new System.Drawing.Point(97, 74);
            this.txtTacGia.Name = "txtTacGia";
            this.txtTacGia.Size = new System.Drawing.Size(181, 27);
            this.txtTacGia.TabIndex = 6;
            // 
            // grp4
            // 
            this.grp4.Controls.Add(this.CHITIET);
            this.grp4.Controls.Add(this.SHOW);
            this.grp4.Controls.Add(this.ngayTRA);
            this.grp4.Controls.Add(this.label7);
            this.grp4.Controls.Add(this.BMUON);
            this.grp4.Controls.Add(this.ngayMuon);
            this.grp4.Controls.Add(this.maSachMuon);
            this.grp4.Controls.Add(this.maDGMuon);
            this.grp4.Controls.Add(this.label6);
            this.grp4.Controls.Add(this.label5);
            this.grp4.Controls.Add(this.label4);
            this.grp4.Location = new System.Drawing.Point(682, 24);
            this.grp4.Name = "grp4";
            this.grp4.Size = new System.Drawing.Size(497, 225);
            this.grp4.TabIndex = 9;
            this.grp4.TabStop = false;
            this.grp4.Text = "Mượn sách";
            // 
            // CHITIET
            // 
            this.CHITIET.Location = new System.Drawing.Point(346, 151);
            this.CHITIET.Name = "CHITIET";
            this.CHITIET.Size = new System.Drawing.Size(104, 39);
            this.CHITIET.TabIndex = 10;
            this.CHITIET.Text = "CTPM";
            this.CHITIET.UseVisualStyleBackColor = true;
            this.CHITIET.Click += new System.EventHandler(this.CHITIET_Click);
            // 
            // SHOW
            // 
            this.SHOW.Location = new System.Drawing.Point(205, 153);
            this.SHOW.Name = "SHOW";
            this.SHOW.Size = new System.Drawing.Size(104, 39);
            this.SHOW.TabIndex = 9;
            this.SHOW.Text = "DS Mượn";
            this.SHOW.UseVisualStyleBackColor = true;
            this.SHOW.Click += new System.EventHandler(this.SHOW_Click);
            // 
            // ngayTRA
            // 
            this.ngayTRA.Location = new System.Drawing.Point(122, 104);
            this.ngayTRA.Name = "ngayTRA";
            this.ngayTRA.Size = new System.Drawing.Size(242, 27);
            this.ngayTRA.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 111);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 20);
            this.label7.TabIndex = 7;
            this.label7.Text = "Ngày trả";
            // 
            // BMUON
            // 
            this.BMUON.Location = new System.Drawing.Point(53, 155);
            this.BMUON.Name = "BMUON";
            this.BMUON.Size = new System.Drawing.Size(104, 35);
            this.BMUON.TabIndex = 6;
            this.BMUON.Text = "Mượn";
            this.BMUON.UseVisualStyleBackColor = true;
            this.BMUON.Click += new System.EventHandler(this.BMUON_Click);
            // 
            // ngayMuon
            // 
            this.ngayMuon.Location = new System.Drawing.Point(122, 62);
            this.ngayMuon.Name = "ngayMuon";
            this.ngayMuon.Size = new System.Drawing.Size(242, 27);
            this.ngayMuon.TabIndex = 5;
            // 
            // maSachMuon
            // 
            this.maSachMuon.Location = new System.Drawing.Point(346, 22);
            this.maSachMuon.Name = "maSachMuon";
            this.maSachMuon.Size = new System.Drawing.Size(135, 27);
            this.maSachMuon.TabIndex = 4;
            // 
            // maDGMuon
            // 
            this.maDGMuon.Location = new System.Drawing.Point(104, 22);
            this.maDGMuon.Name = "maDGMuon";
            this.maDGMuon.Size = new System.Drawing.Size(153, 27);
            this.maDGMuon.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "Ngày mượn";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(277, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Mã sách";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Mã độc giả";
            // 
            // grd1
            // 
            this.grd1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd1.Location = new System.Drawing.Point(19, 26);
            this.grd1.Name = "grd1";
            this.grd1.RowHeadersWidth = 51;
            this.grd1.RowTemplate.Height = 29;
            this.grd1.Size = new System.Drawing.Size(601, 239);
            this.grd1.TabIndex = 0;
            this.grd1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grd1_CellContentClick);
            // 
            // grp3
            // 
            this.grp3.Controls.Add(this.grd1);
            this.grp3.Location = new System.Drawing.Point(15, 255);
            this.grp3.Name = "grp3";
            this.grp3.Size = new System.Drawing.Size(638, 271);
            this.grp3.TabIndex = 8;
            this.grp3.TabStop = false;
            this.grp3.Text = "Thông tin về sách";
            // 
            // BTHEM
            // 
            this.BTHEM.Location = new System.Drawing.Point(29, 26);
            this.BTHEM.Name = "BTHEM";
            this.BTHEM.Size = new System.Drawing.Size(80, 30);
            this.BTHEM.TabIndex = 0;
            this.BTHEM.Text = "Thêm";
            this.BTHEM.UseVisualStyleBackColor = true;
            this.BTHEM.Click += new System.EventHandler(this.BTHEM_Click);
            // 
            // grp1
            // 
            this.grp1.Controls.Add(this.txtSoLuong);
            this.grp1.Controls.Add(this.txtTacGia);
            this.grp1.Controls.Add(this.label8);
            this.grp1.Controls.Add(this.label3);
            this.grp1.Controls.Add(this.txtTenSach);
            this.grp1.Controls.Add(this.label2);
            this.grp1.Controls.Add(this.txtMaSach);
            this.grp1.Controls.Add(this.label1);
            this.grp1.Location = new System.Drawing.Point(12, 12);
            this.grp1.Name = "grp1";
            this.grp1.Size = new System.Drawing.Size(641, 110);
            this.grp1.TabIndex = 6;
            this.grp1.TabStop = false;
            this.grp1.Text = "Quản lý sách";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Tác giả";
            // 
            // txtTenSach
            // 
            this.txtTenSach.Location = new System.Drawing.Point(380, 33);
            this.txtTenSach.Name = "txtTenSach";
            this.txtTenSach.Size = new System.Drawing.Size(243, 27);
            this.txtTenSach.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(309, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tên sách";
            // 
            // txtMaSach
            // 
            this.txtMaSach.Location = new System.Drawing.Point(96, 30);
            this.txtMaSach.Name = "txtMaSach";
            this.txtMaSach.Size = new System.Drawing.Size(179, 27);
            this.txtMaSach.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã sách";
            // 
            // grp2
            // 
            this.grp2.Controls.Add(this.BIN);
            this.grp2.Controls.Add(this.BLUU);
            this.grp2.Controls.Add(this.BSUA);
            this.grp2.Controls.Add(this.BXOA);
            this.grp2.Controls.Add(this.BTHEM);
            this.grp2.Location = new System.Drawing.Point(12, 128);
            this.grp2.Name = "grp2";
            this.grp2.Size = new System.Drawing.Size(641, 63);
            this.grp2.TabIndex = 7;
            this.grp2.TabStop = false;
            this.grp2.Text = "Thao tác";
            // 
            // BIN
            // 
            this.BIN.Location = new System.Drawing.Point(514, 26);
            this.BIN.Name = "BIN";
            this.BIN.Size = new System.Drawing.Size(80, 30);
            this.BIN.TabIndex = 2;
            this.BIN.Text = "In";
            this.BIN.UseVisualStyleBackColor = true;
            this.BIN.Click += new System.EventHandler(this.BIN_Click);
            // 
            // BLUU
            // 
            this.BLUU.Location = new System.Drawing.Point(402, 26);
            this.BLUU.Name = "BLUU";
            this.BLUU.Size = new System.Drawing.Size(80, 30);
            this.BLUU.TabIndex = 2;
            this.BLUU.Text = "Lưu";
            this.BLUU.UseVisualStyleBackColor = true;
            this.BLUU.Click += new System.EventHandler(this.BLUU_Click);
            // 
            // BSUA
            // 
            this.BSUA.Location = new System.Drawing.Point(277, 26);
            this.BSUA.Name = "BSUA";
            this.BSUA.Size = new System.Drawing.Size(80, 30);
            this.BSUA.TabIndex = 2;
            this.BSUA.Text = "Sửa";
            this.BSUA.UseVisualStyleBackColor = true;
            this.BSUA.Click += new System.EventHandler(this.BSUA_Click);
            // 
            // BXOA
            // 
            this.BXOA.Location = new System.Drawing.Point(146, 26);
            this.BXOA.Name = "BXOA";
            this.BXOA.Size = new System.Drawing.Size(80, 30);
            this.BXOA.TabIndex = 1;
            this.BXOA.Text = "Xóa";
            this.BXOA.UseVisualStyleBackColor = true;
            this.BXOA.Click += new System.EventHandler(this.BXOA_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.grd2);
            this.groupBox1.Location = new System.Drawing.Point(682, 255);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(574, 271);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin mượn sách";
            // 
            // grd2
            // 
            this.grd2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd2.Location = new System.Drawing.Point(13, 26);
            this.grd2.Name = "grd2";
            this.grd2.RowHeadersWidth = 51;
            this.grd2.RowTemplate.Height = 29;
            this.grd2.Size = new System.Drawing.Size(555, 239);
            this.grd2.TabIndex = 0;
            this.grd2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grd2_CellContentClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1268, 550);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.grp4);
            this.Controls.Add(this.grp3);
            this.Controls.Add(this.grp1);
            this.Controls.Add(this.grp2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grp4.ResumeLayout(false);
            this.grp4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd1)).EndInit();
            this.grp3.ResumeLayout(false);
            this.grp1.ResumeLayout(false);
            this.grp1.PerformLayout();
            this.grp2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grd2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private TextBox txtSoLuong;
        private Label label8;
        private TextBox txtTIM;
        private Label textBox;
        private GroupBox groupBox2;
        private Button BTIM;
        private TextBox txtTacGia;
        private GroupBox grp4;
        private Button CHITIET;
        private Button SHOW;
        private DateTimePicker ngayTRA;
        private Label label7;
        private Button BMUON;
        private DateTimePicker ngayMuon;
        private TextBox maSachMuon;
        private TextBox maDGMuon;
        private Label label6;
        private Label label5;
        private Label label4;
        private DataGridView grd1;
        private GroupBox grp3;
        private Button BTHEM;
        private GroupBox grp1;
        private Label label3;
        private TextBox txtTenSach;
        private Label label2;
        private TextBox txtMaSach;
        private Label label1;
        private GroupBox grp2;
        private Button BIN;
        private Button BLUU;
        private Button BSUA;
        private Button BXOA;
        private GroupBox groupBox1;
        private DataGridView grd2;
    }
}