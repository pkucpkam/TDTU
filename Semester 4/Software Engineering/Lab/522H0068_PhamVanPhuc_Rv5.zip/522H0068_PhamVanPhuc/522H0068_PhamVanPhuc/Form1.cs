﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using iTextSharp.text.pdf;
using iTextSharp.text;
using System.IO;
using System.Drawing.Printing;
using System.Xml.Linq;


namespace _522H0068_PhamVanPhuc
{
    public partial class Form1 : Form
    {
        SqlConnection cn;
        SqlDataAdapter data;
        SqlCommand cm;
        DataTable tb;
        int dk = 0;
        public Form1()
        {
            InitializeComponent();
        }

        void formload()
        {
            showGRD();
            enable(grp1, false);
            BXOA.Enabled = false;
            BSUA.Enabled = false;
            BLUU.Enabled = false;
            dk = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string s = "initial catalog = ThuVien2; data source = LAPTOP-GL3OSLED\\SQLEXPRESS; integrated security = true";
            //s = "server = <ten sverver>; database = <ten db>; uid = ; pwd = ";

            cn = new SqlConnection(s);
            cn.Open();
            formload();
        }

        public void enable(GroupBox grp, bool b)
        {
            grp.Enabled = b;
        }

        public void showGRD()
        {
            string sql = "select * from Sach";
            data = new SqlDataAdapter(sql, cn);
            tb = new DataTable();
            data.Fill(tb);
            grd1.DataSource = tb;
        }

        private void BTHEM_Click(object sender, EventArgs e)
        {
            enable(grp1, true);
            txtMaSach.Clear();
            txtTenSach.Clear();
            txtMaSach.Focus();
            BLUU.Enabled = true;
            dk = 1;
        }

        private void BXOA_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Delete?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                string checkSql = "SELECT COUNT(*) FROM ChiTietPhieuMuon WHERE MaSach = '" + txtMaSach.Text + "'";
                SqlCommand checkCmd = new SqlCommand(checkSql, cn);
                int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                if (count > 0)
                {
                    MessageBox.Show("Cannot delete. There are related records in ChiTietPhieuMuon.");
                }
                else
                {
                    string deleteSql = "DELETE FROM Sach WHERE MaSach = '" + txtMaSach.Text + "'";
                    SqlCommand deleteCmd = new SqlCommand(deleteSql, cn);
                    deleteCmd.ExecuteNonQuery();
                    MessageBox.Show("Delete Complete");
                    formload();
                }
            }
        }

        private void BSUA_Click(object sender, EventArgs e)
        {
            enable(grp1, true);
            txtMaSach.Enabled = false;
            txtTenSach.Enabled = true;
            txtTacGia.Enabled = true;
            txtSoLuong.Enabled = true;
            txtMaSach.Focus();
            BLUU.Enabled = true;
            dk = 2;
        }

        private void BLUU_Click(object sender, EventArgs e)
        {
            string sql = "";

            if (dk == 1)
            {
                if (txtMaSach.Text == "")
                {
                    MessageBox.Show("Please enter MaSach");
                    return;
                }


                sql = "SELECT * FROM Sach WHERE MaSach = '" + txtMaSach.Text + "'";
                data = new SqlDataAdapter(sql, cn);
                tb = new DataTable();
                data.Fill(tb);

                if (tb.Rows.Count > 0)
                {
                    MessageBox.Show("Book ID already exists");
                    txtMaSach.Focus();
                    return;
                }


                sql = "INSERT INTO Sach VALUES ('" + txtMaSach.Text + "', N'" + txtTenSach.Text + "', N'" + txtTacGia.Text + "', N'" + txtSoLuong.Text + "')";
                cm = new SqlCommand(sql, cn);
                cm.ExecuteNonQuery();
            }
            else if (dk == 2)
            {
                if (txtMaSach.Text == "")
                {
                    MessageBox.Show("Please select a Sach to edit");
                    return;
                }

                sql = "UPDATE Sach SET TenSach = N'" + txtTenSach.Text + "', TacGia = N'" + txtTacGia.Text + "', SoLuong = N'" + txtSoLuong.Text + "' where maSach = '" + txtMaSach.Text + "'";
                cm = new SqlCommand(sql, cn);
                cm.ExecuteNonQuery();
            }


            formload();
        }

        private void grd1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtMaSach.Text = grd1.CurrentRow.Cells[0].Value.ToString();
            txtTenSach.Text = grd1.CurrentRow.Cells[1].Value.ToString();
            txtTacGia.Text = grd1.CurrentRow.Cells[2].Value.ToString();
            txtSoLuong.Text = grd1.CurrentRow.Cells[3].Value.ToString();
            BXOA.Enabled = true;
            BSUA.Enabled = true;
        }

        private void BIN_Click(object sender, EventArgs e)
        {
            if (grd1.Rows.Count - 1 > 0)
            {
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "PDF (*.pdf)|*.pdf";
                sfd.FileName = "Output.pdf";
                bool fileError = false;
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(sfd.FileName))
                    {
                        try
                        {
                            File.Delete(sfd.FileName);
                        }
                        catch (IOException ex)
                        {
                            fileError = true;
                            MessageBox.Show("It wasn't possible to write the data to the disk." + ex.Message);
                        }
                    }
                    if (!fileError)
                    {
                        try
                        {
                            PdfPTable pdfTable = new PdfPTable(grd1.Columns.Count);
                            pdfTable.DefaultCell.Padding = 3;
                            pdfTable.WidthPercentage = 100;
                            pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;
                            //add column
                            foreach (DataGridViewColumn column in grd1.Columns)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText));
                                pdfTable.AddCell(cell);
                            }

                            //add value
                            for (int i = 0; i < grd1.Rows.Count - 1; ++i)
                            {
                                for (int j = 0; j < grd1.Columns.Count; ++j)
                                {
                                    // string s = grd.Rows[i].Cells[j].Value.ToString();
                                    pdfTable.AddCell(grd1.Rows[i].Cells[j].Value.ToString());

                                }
                            }

                            using (FileStream stream = new FileStream(sfd.FileName, FileMode.Create))
                            {
                                Document pdfDoc = new Document(PageSize.A4, 10f, 20f, 20f, 10f);
                                PdfWriter.GetInstance(pdfDoc, stream);
                                pdfDoc.Open();
                                pdfDoc.Add(pdfTable);
                                pdfDoc.Close();
                                stream.Close();
                            }

                            MessageBox.Show("Data Exported Successfully !!!", "Info");
                            // Application.Run(sfd.FileName);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error :" + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("No Record To Export !!!", "Info");
            }
        }

        private void BTIM_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtTIM.Text))
            {
                string searchValue = txtTIM.Text.Trim();
                string sql = "SELECT * FROM Sach WHERE MaSach LIKE '%" + searchValue + "%'";

                data = new SqlDataAdapter(sql, cn);
                tb = new DataTable();
                data.Fill(tb);

                if (tb.Rows.Count > 0)
                {
                    grd1.DataSource = tb;
                    MessageBox.Show("Data found successfully!", "Info");
                }
                else
                {
                    MessageBox.Show("No matching records found!", "Info");
                }
            }
            else
            {
                MessageBox.Show("Please enter a search value!", "Info");
            }
        }

        private void BMUON_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem thông tin đã nhập đủ chưa
            if (string.IsNullOrWhiteSpace(maSachMuon.Text) || string.IsNullOrWhiteSpace(maDGMuon.Text) ||
                string.IsNullOrWhiteSpace(ngayMuon.Text) || string.IsNullOrWhiteSpace(ngayTRA.Text))
            {
                MessageBox.Show("Vui lòng nhập đủ thông tin mượn sách!");
                return;
            }

            if (ngayTRA.Value < ngayMuon.Value)
            {
                MessageBox.Show("Ngày trả phải lớn hơn hoặc bằng ngày mượn!");
                return;
            }

            // Tạo mã phiếu mượn mới
            DateTime a = ngayMuon.Value;
            string aAsString = a.ToString("yyyyMMdd");
            string maPhieuMuon = TaoMaPhieuMoi(aAsString);

            // Thêm thông tin vào bảng MuonSach
            string insertMuonSachSql = "INSERT INTO MuonSach (MaPhieuMuon, MaDocGia, NgayMuon) " +
                                       "VALUES (@MaPhieuMuon, @MaDocGia, @NgayMuon)";
            cm = new SqlCommand(insertMuonSachSql, cn);
            cm.Parameters.AddWithValue("@MaPhieuMuon", maPhieuMuon);
            cm.Parameters.AddWithValue("@MaDocGia", maDGMuon.Text);
            cm.Parameters.AddWithValue("@NgayMuon", ngayMuon.Value);

            // Thực hiện truy vấn
            cm.ExecuteNonQuery();

            string insertChiTietPhieuMuonSql = "INSERT INTO ChiTietPhieuMuon (MaPhieuMuon, MaSach, NgayTra) " +
                                       "VALUES (@MaPhieuMuon, @MaSach, @NgayTra)";
            cm = new SqlCommand(insertChiTietPhieuMuonSql, cn);
            cm.Parameters.AddWithValue("@MaPhieuMuon", maPhieuMuon);
            cm.Parameters.AddWithValue("@MaSach", maSachMuon.Text);
            cm.Parameters.AddWithValue("@NgayTra", ngayTRA.Value);

            // Thực hiện truy vấn
            cm.ExecuteNonQuery();

            MessageBox.Show("Thêm thông tin mượn sách thành công!");
            // Gọi hàm cập nhật hiển thị danh sách
            formload();
        }

        private string TaoMaPhieuMoi(string dayy)
        {
            string maPhieuMoi = "";

            // Lấy số cao nhất từ cơ sở dữ liệu
            string query = "SELECT MAX(CAST(SUBSTRING(MaPhieuMuon, LEN(MaPhieuMuon) - 2, 3) AS INT)) FROM MuonSach";

            using (SqlCommand command = new SqlCommand(query, cn))
            {
                object result = command.ExecuteScalar();

                int maxId = result == DBNull.Value ? 0 : Convert.ToInt32(result);

                maPhieuMoi = dayy + "-" + (maxId + 1).ToString("D3");
            }

            return maPhieuMoi;
        }


        private void SHOW_Click(object sender, EventArgs e)
        {
            string sql = "select * from MuonSach";
            data = new SqlDataAdapter(sql, cn);
            tb = new DataTable();
            data.Fill(tb);
            grd2.DataSource = tb;
        }

        private void CHITIET_Click(object sender, EventArgs e)
        {
            string sql = "select * from ChiTietPhieuMuon";
            data = new SqlDataAdapter(sql, cn);
            tb = new DataTable();
            data.Fill(tb);
            grd2.DataSource = tb;
        }

        private void grd2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}