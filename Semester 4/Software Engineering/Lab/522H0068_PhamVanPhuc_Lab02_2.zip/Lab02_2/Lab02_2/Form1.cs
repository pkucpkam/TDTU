﻿using System.Data;
using System.Data.SqlClient;

namespace Lab02_2
{
    public partial class Form1 : Form
    {

        SqlConnection cn;
        SqlDataAdapter data;
        SqlCommand cm;
        DataTable tb;
        int dk = 0;
        public Form1()
        {
            InitializeComponent();
        }

        void formload()
        {
            showGRD();
            enable(grp1, false);
            bDEL.Enabled = false;
            bEDIT.Enabled = false;
            bSAVE.Enabled = false;
            dk = 0;
        }

        public void enable(GroupBox grp, bool b)
        {
            grp.Enabled = b;
        }

        public void showGRD()
        {
            string sql = "select * from Project";
            data = new SqlDataAdapter(sql, cn);
            tb = new DataTable();
            data.Fill(tb);
            grd.DataSource = tb;
        }

        private void grp1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string s = "initial catalog = Students1; data source = LAPTOP-GL3OSLED\\SQLEXPRESS; integrated security = true";
            //s = "server = <ten sverver>; database = <ten db>; uid = ; pwd = ";
            cn = new SqlConnection(s);
            cn.Open();
            formload();
        }

        private void bADD_Click(object sender, EventArgs e)
        {
            enable(grp1, true);
            bSAVE.Enabled = true;
            msDeTai.Clear();
            tenDT.Clear();
            kinhPhi.Clear();
            dk = 1;
            msDeTai.Focus();
        }

        private void bCANCEL_Click(object sender, EventArgs e)
        {
            formload();
        }

        private void bDEL_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Delete?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                string sql = "delete from Project where ProjectID = '" + msDeTai.Text + "'";
                cm = new SqlCommand(sql, cn);
                cm.ExecuteNonQuery();
                formload();
            }
        }

        private void bEDIT_Click(object sender, EventArgs e)
        {
            enable(grp1, true);
        }

        private void grd_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            msDeTai.Text = grd.CurrentRow.Cells[0].Value.ToString();
            tenDT.Text = grd.CurrentRow.Cells[1].Value.ToString();
            cnDT.Text = grd.CurrentRow.Cells[2].Value.ToString();
            kinhPhi.Text = grd.CurrentRow.Cells[3].Value.ToString();
            bDEL.Enabled = true;
            bSAVE.Enabled = true;
            bEDIT.Enabled = true;
            enable(grp1, false);
        }

        private void bSAVE_Click(object sender, EventArgs e)
        {
            string sql = "";
            if (dk == 1)//Add
            {
                //check primary key
                sql = "select * from Project where ProjectID = '" + msDeTai.Text + "'";
                data = new SqlDataAdapter(sql, cn);
                tb = new DataTable();
                data.Fill(tb);
                if (tb.Rows.Count > 0)
                {
                    MessageBox.Show("Student exists");
                    msDeTai.Focus();
                    return;
                }
                //Insert into
                sql = "insert into Project values ('" + msDeTai.Text + "', N'" + tenDT.Text + "', N'" + cnDT.Text + "', '" + "', '" + kinhPhi.Text + "')";
                cm = new SqlCommand(sql, cn);
                cm.ExecuteNonQuery();
            }
            else //dk =2
            {
                //Update
                sql = "update Project set ProjectName = N'" + tenDT.Text + "', Supervisor = N'" + cnDT.Text + "', Funding = " + kinhPhi.Text + " where ProjectID = '" + msDeTai.Text + "'";
                cm = new SqlCommand(sql, cn);
                cm.ExecuteNonQuery();
            }
            formload();
        }
    }
}