﻿using System.Data;
using System.Data.SqlClient;

namespace Lab7_Sinhvien
{
    public partial class Form1 : Form
    {

        SqlConnection cn;
        SqlDataAdapter data;
        SqlCommand cm;
        DataTable tb;
        int dk = 0;
        public Form1()
        {
            InitializeComponent();
        }


        private void grp1_Enter(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        void formload()
        {
            showGRD();
            enable(grp1, false);
            bDEL.Enabled = false;
            bEDIT.Enabled = false;
            bSAVE.Enabled = false;
            dk = 0;
        }

        public void enable(GroupBox grp, bool b)
        {
            grp.Enabled = b;
        }

        public void showGRD()
        {
            string sql = "select * from SinhVien";
            data = new SqlDataAdapter(sql, cn);
            tb = new DataTable();
            data.Fill(tb);
            grd.DataSource = tb;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string s = "initial catalog = CourseRegis; data source = LAPTOP-GL3OSLED\\SQLEXPRESS; integrated security = true";
            //s = "server = <ten sverver>; database = <ten db>; uid = ; pwd = ";

            cn = new SqlConnection(s);
            cn.Open();
            formload();
        }

        private void grd_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void grd_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtMK.Text = grd.CurrentRow.Cells[6].Value.ToString();
            txtMSSV.Text = grd.CurrentRow.Cells[0].Value.ToString();
            txtTenSV.Text = grd.CurrentRow.Cells[1].Value.ToString();
            txtQueQuan.Text = grd.CurrentRow.Cells[3].Value.ToString();
            txtGioitinh.Text = grd.CurrentRow.Cells[4].Value.ToString();
            txtDiaChi.Text = grd.CurrentRow.Cells[5].Value.ToString();
            dateSN.Text = grd.CurrentRow.Cells[2].Value.ToString();

            bDEL.Enabled = true;
            bEDIT.Enabled = true;
        }

        private void bADD_Click(object sender, EventArgs e)
        {
            txtMK.Clear();
            txtMSSV.Clear();
            txtTenSV.Clear();
            txtQueQuan.Clear();
            txtGioitinh.Clear();
            txtDiaChi.Clear();
            dateSN.Value = DateTime.Now;

            txtMSSV.ReadOnly = true;

            enable(grp1, true);
            bSAVE.Enabled = true;   

        }

        private string GenerateStudentID(string makhoa)
        {
            string query = "SELECT MAX(Masv) FROM SinhVien";
            SqlCommand cmd = new SqlCommand(query, cn);

            try
            {
                string maxStudentID = cmd.ExecuteScalar()?.ToString();

                if (string.IsNullOrEmpty(maxStudentID))
                    return makhoa + "0001";

                int currentNumber = int.Parse(maxStudentID.Substring(2));
                string newStudentID = makhoa + (currentNumber + 1).ToString("D4"); 

                return newStudentID;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
                return null;
            }
        }

        private void txtTK_Leave(object sender, EventArgs e)
        {
           
        }

        private void txtMK_Leave(object sender, EventArgs e)
        {
            string makhoa = txtMK.Text;
            txtMSSV.Text = GenerateStudentID(makhoa);
        }

        private void bSAVE_Click(object sender, EventArgs e)
        {
            try
            {
                string masv = txtMSSV.Text;
                string ten = txtTenSV.Text;
                string ns = dateSN.Value.ToString("yyyy-MM-dd");
                string qq = txtQueQuan.Text;
                string gioitinh = txtGioitinh.Text;
                string dc = txtDiaChi.Text;
                string makhoa = txtMK.Text;

                // Kiểm tra xem MSSV đã tồn tại trong cơ sở dữ liệu hay không
                string queryCheck = "SELECT COUNT(*) FROM SinhVien WHERE Masv = @Masv";
                SqlCommand cmdCheck = new SqlCommand(queryCheck, cn);
                cmdCheck.Parameters.AddWithValue("@Masv", masv);
                int count = (int)cmdCheck.ExecuteScalar();

                if (count > 0)
                {
                    // Nếu MSSV đã tồn tại, thực hiện câu lệnh UPDATE
                    string queryUpdate = "UPDATE SinhVien SET Ten = @Ten, NS = @NS, QQ = @QQ, Gioitinh = @Gioitinh, DC = @DC, Makhoa = @Makhoa WHERE Masv = @Masv";
                    SqlCommand cmdUpdate = new SqlCommand(queryUpdate, cn);
                    cmdUpdate.Parameters.AddWithValue("@Ten", ten);
                    cmdUpdate.Parameters.AddWithValue("@NS", ns);
                    cmdUpdate.Parameters.AddWithValue("@QQ", qq);
                    cmdUpdate.Parameters.AddWithValue("@Gioitinh", gioitinh);
                    cmdUpdate.Parameters.AddWithValue("@DC", dc);
                    cmdUpdate.Parameters.AddWithValue("@Makhoa", makhoa);
                    cmdUpdate.Parameters.AddWithValue("@Masv", masv);
                    int rowsUpdated = cmdUpdate.ExecuteNonQuery();

                    if (rowsUpdated > 0)
                    {
                        MessageBox.Show("Đã cập nhật dữ liệu thành công!");
                        showGRD();
                    }
                    else
                    {
                        MessageBox.Show("Cập nhật dữ liệu không thành công!");
                    }
                }
                else
                {
                    // Nếu MSSV chưa tồn tại, thực hiện câu lệnh INSERT
                    string queryInsert = "INSERT INTO SinhVien (Masv, Ten, NS, QQ, Gioitinh, DC, Makhoa) VALUES (@Masv, @Ten, @NS, @QQ, @Gioitinh, @DC, @Makhoa)";
                    SqlCommand cmdInsert = new SqlCommand(queryInsert, cn);
                    cmdInsert.Parameters.AddWithValue("@Masv", masv);
                    cmdInsert.Parameters.AddWithValue("@Ten", ten);
                    cmdInsert.Parameters.AddWithValue("@NS", ns);
                    cmdInsert.Parameters.AddWithValue("@QQ", qq);
                    cmdInsert.Parameters.AddWithValue("@Gioitinh", gioitinh);
                    cmdInsert.Parameters.AddWithValue("@DC", dc);
                    cmdInsert.Parameters.AddWithValue("@Makhoa", makhoa);
                    int rowsInserted = cmdInsert.ExecuteNonQuery();

                    if (rowsInserted > 0)
                    {
                        MessageBox.Show("Đã thêm dữ liệu thành công!");
                        showGRD();
                    }
                    else
                    {
                        MessageBox.Show("Thêm dữ liệu không thành công!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void bEDIT_Click(object sender, EventArgs e)
        {
            bEDIT.Enabled = true;
            enable(grp1, true);
            bSAVE.Enabled = true;
        }

        private void bDEL_Click(object sender, EventArgs e)
        {
            try
            {
                // Trích xuất mã sinh viên từ TextBox
                string masv = txtMSSV.Text;

                // Xác nhận việc xóa bản ghi
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa sinh viên này?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    // Thực hiện câu lệnh DELETE
                    string queryDelete = "DELETE FROM SinhVien WHERE Masv = @Masv";
                    SqlCommand cmdDelete = new SqlCommand(queryDelete, cn);
                    cmdDelete.Parameters.AddWithValue("@Masv", masv);
                    int rowsDeleted = cmdDelete.ExecuteNonQuery();

                    if (rowsDeleted > 0)
                    {
                        MessageBox.Show("Đã xóa sinh viên thành công!");
                        showGRD(); // Cập nhật hiển thị bảng dữ liệu sau khi xóa
                    }
                    else
                    {
                        MessageBox.Show("Không thể xóa sinh viên!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}