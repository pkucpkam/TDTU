﻿namespace Lab7_Sinhvien
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grp3 = new System.Windows.Forms.GroupBox();
            this.grd = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.grp1 = new System.Windows.Forms.GroupBox();
            this.dateSN = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMSSV = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtQueQuan = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtGioitinh = new System.Windows.Forms.TextBox();
            this.txtTenSV = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMK = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.grp2 = new System.Windows.Forms.GroupBox();
            this.bCANCEL = new System.Windows.Forms.Button();
            this.bSAVE = new System.Windows.Forms.Button();
            this.bEDIT = new System.Windows.Forms.Button();
            this.bDEL = new System.Windows.Forms.Button();
            this.bADD = new System.Windows.Forms.Button();
            this.grp3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd)).BeginInit();
            this.grp1.SuspendLayout();
            this.grp2.SuspendLayout();
            this.SuspendLayout();
            // 
            // grp3
            // 
            this.grp3.Controls.Add(this.grd);
            this.grp3.Location = new System.Drawing.Point(45, 300);
            this.grp3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grp3.Name = "grp3";
            this.grp3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grp3.Size = new System.Drawing.Size(788, 330);
            this.grp3.TabIndex = 24;
            this.grp3.TabStop = false;
            this.grp3.Text = "Danh sách sinh viên";
            // 
            // grd
            // 
            this.grd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd.Location = new System.Drawing.Point(11, 50);
            this.grd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grd.Name = "grd";
            this.grd.RowHeadersWidth = 62;
            this.grd.RowTemplate.Height = 25;
            this.grd.Size = new System.Drawing.Size(771, 257);
            this.grd.TabIndex = 0;
            this.grd.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grd_CellClick);
            this.grd.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grd_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Khoa";
            // 
            // grp1
            // 
            this.grp1.Controls.Add(this.dateSN);
            this.grp1.Controls.Add(this.label5);
            this.grp1.Controls.Add(this.txtMSSV);
            this.grp1.Controls.Add(this.label4);
            this.grp1.Controls.Add(this.txtQueQuan);
            this.grp1.Controls.Add(this.txtDiaChi);
            this.grp1.Controls.Add(this.txtGioitinh);
            this.grp1.Controls.Add(this.txtTenSV);
            this.grp1.Controls.Add(this.label7);
            this.grp1.Controls.Add(this.txtMK);
            this.grp1.Controls.Add(this.label8);
            this.grp1.Controls.Add(this.label6);
            this.grp1.Controls.Add(this.label3);
            this.grp1.Controls.Add(this.label1);
            this.grp1.Location = new System.Drawing.Point(39, 13);
            this.grp1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grp1.Name = "grp1";
            this.grp1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grp1.Size = new System.Drawing.Size(845, 195);
            this.grp1.TabIndex = 23;
            this.grp1.TabStop = false;
            this.grp1.Text = "Thông tin sinh viên";
            this.grp1.Enter += new System.EventHandler(this.grp1_Enter);
            // 
            // dateSN
            // 
            this.dateSN.Location = new System.Drawing.Point(553, 69);
            this.dateSN.Name = "dateSN";
            this.dateSN.Size = new System.Drawing.Size(241, 27);
            this.dateSN.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(451, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Ngay Sinh";
            // 
            // txtMSSV
            // 
            this.txtMSSV.Location = new System.Drawing.Point(102, 65);
            this.txtMSSV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMSSV.Name = "txtMSSV";
            this.txtMSSV.Size = new System.Drawing.Size(178, 27);
            this.txtMSSV.TabIndex = 7;
            this.txtMSSV.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "MSSV";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // txtQueQuan
            // 
            this.txtQueQuan.Location = new System.Drawing.Point(102, 142);
            this.txtQueQuan.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtQueQuan.Name = "txtQueQuan";
            this.txtQueQuan.Size = new System.Drawing.Size(178, 27);
            this.txtQueQuan.TabIndex = 5;
            this.txtQueQuan.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(545, 145);
            this.txtDiaChi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(249, 27);
            this.txtDiaChi.TabIndex = 5;
            // 
            // txtGioitinh
            // 
            this.txtGioitinh.Location = new System.Drawing.Point(545, 110);
            this.txtGioitinh.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtGioitinh.Name = "txtGioitinh";
            this.txtGioitinh.Size = new System.Drawing.Size(243, 27);
            this.txtGioitinh.TabIndex = 5;
            // 
            // txtTenSV
            // 
            this.txtTenSV.Location = new System.Drawing.Point(102, 107);
            this.txtTenSV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTenSV.Name = "txtTenSV";
            this.txtTenSV.Size = new System.Drawing.Size(178, 27);
            this.txtTenSV.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 142);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "Que quan";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtMK
            // 
            this.txtMK.AcceptsReturn = true;
            this.txtMK.Location = new System.Drawing.Point(102, 22);
            this.txtMK.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMK.Name = "txtMK";
            this.txtMK.Size = new System.Drawing.Size(178, 27);
            this.txtMK.TabIndex = 0;
            this.txtMK.Leave += new System.EventHandler(this.txtMK_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(451, 145);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "Dia chi";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(451, 110);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Gioi tinh";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tên sinh viên";
            // 
            // grp2
            // 
            this.grp2.Controls.Add(this.bCANCEL);
            this.grp2.Controls.Add(this.bSAVE);
            this.grp2.Controls.Add(this.bEDIT);
            this.grp2.Controls.Add(this.bDEL);
            this.grp2.Controls.Add(this.bADD);
            this.grp2.Location = new System.Drawing.Point(45, 216);
            this.grp2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grp2.Name = "grp2";
            this.grp2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grp2.Size = new System.Drawing.Size(788, 76);
            this.grp2.TabIndex = 25;
            this.grp2.TabStop = false;
            this.grp2.Text = "Functions";
            // 
            // bCANCEL
            // 
            this.bCANCEL.Location = new System.Drawing.Point(391, 22);
            this.bCANCEL.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bCANCEL.Name = "bCANCEL";
            this.bCANCEL.Size = new System.Drawing.Size(78, 40);
            this.bCANCEL.TabIndex = 4;
            this.bCANCEL.Text = "Cancel";
            this.bCANCEL.UseVisualStyleBackColor = true;
            // 
            // bSAVE
            // 
            this.bSAVE.Location = new System.Drawing.Point(306, 22);
            this.bSAVE.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bSAVE.Name = "bSAVE";
            this.bSAVE.Size = new System.Drawing.Size(78, 40);
            this.bSAVE.TabIndex = 1;
            this.bSAVE.Text = "Save";
            this.bSAVE.UseVisualStyleBackColor = true;
            this.bSAVE.Click += new System.EventHandler(this.bSAVE_Click);
            // 
            // bEDIT
            // 
            this.bEDIT.Location = new System.Drawing.Point(222, 22);
            this.bEDIT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bEDIT.Name = "bEDIT";
            this.bEDIT.Size = new System.Drawing.Size(78, 40);
            this.bEDIT.TabIndex = 3;
            this.bEDIT.Text = "Edit";
            this.bEDIT.UseVisualStyleBackColor = true;
            this.bEDIT.Click += new System.EventHandler(this.bEDIT_Click);
            // 
            // bDEL
            // 
            this.bDEL.Location = new System.Drawing.Point(137, 22);
            this.bDEL.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bDEL.Name = "bDEL";
            this.bDEL.Size = new System.Drawing.Size(78, 40);
            this.bDEL.TabIndex = 2;
            this.bDEL.Text = "Delete";
            this.bDEL.UseVisualStyleBackColor = true;
            this.bDEL.Click += new System.EventHandler(this.bDEL_Click);
            // 
            // bADD
            // 
            this.bADD.Location = new System.Drawing.Point(53, 22);
            this.bADD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bADD.Name = "bADD";
            this.bADD.Size = new System.Drawing.Size(78, 40);
            this.bADD.TabIndex = 0;
            this.bADD.Text = "Add";
            this.bADD.UseVisualStyleBackColor = true;
            this.bADD.Click += new System.EventHandler(this.bADD_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(908, 684);
            this.Controls.Add(this.grp3);
            this.Controls.Add(this.grp1);
            this.Controls.Add(this.grp2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grp3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grd)).EndInit();
            this.grp1.ResumeLayout(false);
            this.grp1.PerformLayout();
            this.grp2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox grp3;
        private DataGridView grd;
        private Label label1;
        private GroupBox grp1;
        private TextBox txtTenSV;
        private TextBox txtMK;
        private Label label3;
        private GroupBox grp2;
        private Button bCANCEL;
        private Button bSAVE;
        private Button bEDIT;
        private Button bDEL;
        private Button bADD;
        private TextBox txtMSSV;
        private Label label4;
        private DateTimePicker dateSN;
        private Label label5;
        private TextBox txtQueQuan;
        private Label label7;
        private TextBox txtDiaChi;
        private TextBox txtGioitinh;
        private Label label8;
        private Label label6;
    }
}