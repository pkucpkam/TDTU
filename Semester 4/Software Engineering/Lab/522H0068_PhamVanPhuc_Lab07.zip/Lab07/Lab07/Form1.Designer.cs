﻿namespace Lab07
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bSAVE = new System.Windows.Forms.Button();
            this.bEDIT = new System.Windows.Forms.Button();
            this.bADD = new System.Windows.Forms.Button();
            this.txtDD = new System.Windows.Forms.TextBox();
            this.txtTK = new System.Windows.Forms.TextBox();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.txtMK = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.bCANCEL = new System.Windows.Forms.Button();
            this.grp2 = new System.Windows.Forms.GroupBox();
            this.bDEL = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.grp1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grd = new System.Windows.Forms.DataGridView();
            this.grp3 = new System.Windows.Forms.GroupBox();
            this.grp2.SuspendLayout();
            this.grp1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd)).BeginInit();
            this.grp3.SuspendLayout();
            this.SuspendLayout();
            // 
            // bSAVE
            // 
            this.bSAVE.Location = new System.Drawing.Point(306, 22);
            this.bSAVE.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bSAVE.Name = "bSAVE";
            this.bSAVE.Size = new System.Drawing.Size(78, 40);
            this.bSAVE.TabIndex = 1;
            this.bSAVE.Text = "Save";
            this.bSAVE.UseVisualStyleBackColor = true;
            // 
            // bEDIT
            // 
            this.bEDIT.Location = new System.Drawing.Point(222, 22);
            this.bEDIT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bEDIT.Name = "bEDIT";
            this.bEDIT.Size = new System.Drawing.Size(78, 40);
            this.bEDIT.TabIndex = 3;
            this.bEDIT.Text = "Edit";
            this.bEDIT.UseVisualStyleBackColor = true;
            // 
            // bADD
            // 
            this.bADD.Location = new System.Drawing.Point(53, 22);
            this.bADD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bADD.Name = "bADD";
            this.bADD.Size = new System.Drawing.Size(78, 40);
            this.bADD.TabIndex = 0;
            this.bADD.Text = "Add";
            this.bADD.UseVisualStyleBackColor = true;
            this.bADD.Click += new System.EventHandler(this.bADD_Click);
            // 
            // txtDD
            // 
            this.txtDD.Location = new System.Drawing.Point(102, 68);
            this.txtDD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDD.Name = "txtDD";
            this.txtDD.Size = new System.Drawing.Size(178, 27);
            this.txtDD.TabIndex = 5;
            // 
            // txtTK
            // 
            this.txtTK.Location = new System.Drawing.Point(556, 21);
            this.txtTK.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTK.Name = "txtTK";
            this.txtTK.Size = new System.Drawing.Size(178, 27);
            this.txtTK.TabIndex = 1;
            this.txtTK.TextChanged += new System.EventHandler(this.txtTK_TextChanged);
            this.txtTK.Leave += new System.EventHandler(this.txtTK_Leave);
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(556, 64);
            this.txtSDT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(178, 27);
            this.txtSDT.TabIndex = 4;
            // 
            // txtMK
            // 
            this.txtMK.AcceptsReturn = true;
            this.txtMK.Location = new System.Drawing.Point(102, 22);
            this.txtMK.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMK.Name = "txtMK";
            this.txtMK.Size = new System.Drawing.Size(178, 27);
            this.txtMK.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(451, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tên Khoa";
            // 
            // bCANCEL
            // 
            this.bCANCEL.Location = new System.Drawing.Point(391, 22);
            this.bCANCEL.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bCANCEL.Name = "bCANCEL";
            this.bCANCEL.Size = new System.Drawing.Size(78, 40);
            this.bCANCEL.TabIndex = 4;
            this.bCANCEL.Text = "Cancel";
            this.bCANCEL.UseVisualStyleBackColor = true;
            // 
            // grp2
            // 
            this.grp2.Controls.Add(this.bCANCEL);
            this.grp2.Controls.Add(this.bSAVE);
            this.grp2.Controls.Add(this.bEDIT);
            this.grp2.Controls.Add(this.bDEL);
            this.grp2.Controls.Add(this.bADD);
            this.grp2.Location = new System.Drawing.Point(28, 131);
            this.grp2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grp2.Name = "grp2";
            this.grp2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grp2.Size = new System.Drawing.Size(788, 76);
            this.grp2.TabIndex = 22;
            this.grp2.TabStop = false;
            this.grp2.Text = "Functions";
            // 
            // bDEL
            // 
            this.bDEL.Location = new System.Drawing.Point(137, 22);
            this.bDEL.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bDEL.Name = "bDEL";
            this.bDEL.Size = new System.Drawing.Size(78, 40);
            this.bDEL.TabIndex = 2;
            this.bDEL.Text = "Delete";
            this.bDEL.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(451, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Số điện thoại";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Địa điểm";
            // 
            // grp1
            // 
            this.grp1.Controls.Add(this.txtDD);
            this.grp1.Controls.Add(this.txtTK);
            this.grp1.Controls.Add(this.txtSDT);
            this.grp1.Controls.Add(this.txtMK);
            this.grp1.Controls.Add(this.label2);
            this.grp1.Controls.Add(this.label5);
            this.grp1.Controls.Add(this.label3);
            this.grp1.Controls.Add(this.label1);
            this.grp1.Location = new System.Drawing.Point(28, 13);
            this.grp1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grp1.Name = "grp1";
            this.grp1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grp1.Size = new System.Drawing.Size(788, 106);
            this.grp1.TabIndex = 20;
            this.grp1.TabStop = false;
            this.grp1.Text = "Thông tin Khoa";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Khoa";
            // 
            // grd
            // 
            this.grd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd.Location = new System.Drawing.Point(11, 28);
            this.grd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grd.Name = "grd";
            this.grd.RowHeadersWidth = 62;
            this.grd.RowTemplate.Height = 25;
            this.grd.Size = new System.Drawing.Size(771, 257);
            this.grd.TabIndex = 0;
            this.grd.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grd_CellClick);
            this.grd.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grd_CellContentClick);
            // 
            // grp3
            // 
            this.grp3.Controls.Add(this.grd);
            this.grp3.Location = new System.Drawing.Point(28, 215);
            this.grp3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grp3.Name = "grp3";
            this.grp3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grp3.Size = new System.Drawing.Size(788, 330);
            this.grp3.TabIndex = 21;
            this.grp3.TabStop = false;
            this.grp3.Text = "Danh sách khoa";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(874, 513);
            this.Controls.Add(this.grp2);
            this.Controls.Add(this.grp1);
            this.Controls.Add(this.grp3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grp2.ResumeLayout(false);
            this.grp1.ResumeLayout(false);
            this.grp1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd)).EndInit();
            this.grp3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Button bSAVE;
        private Button bEDIT;
        private Button bADD;
        private TextBox txtDD;
        private TextBox txtTK;
        private TextBox txtSDT;
        private TextBox txtMK;
        private Label label2;
        private Button bCANCEL;
        private GroupBox grp2;
        private Button bDEL;
        private Label label5;
        private Label label3;
        private GroupBox grp1;
        private Label label1;
        private DataGridView grd;
        private GroupBox grp3;
    }
}