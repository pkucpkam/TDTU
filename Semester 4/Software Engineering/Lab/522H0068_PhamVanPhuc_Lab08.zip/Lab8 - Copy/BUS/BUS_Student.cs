﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public class BUS_Student
    {
        private DAL_Student dalStudent;

        public BUS_Student(string studentID, string fullName, string hometown, DateTime dob, decimal gpa)
        {
            dalStudent = new DAL_Student(studentID, fullName, hometown, dob, gpa);
        }

        public void AddStudent()
        {
            dalStudent.AddStudent();
        }

        public void UpdateStudent()
        {
            dalStudent.UpdateStudent();
        }

        public void DeleteStudent()
        {
            dalStudent.DeleteStudent();
        }

        public DataTable SelectAllStudents()
        {
            return dalStudent.SelectAllStudents();
        }

        public DataTable SelectStudentByID(string studentID)
        {
            return dalStudent.SelectStudentByID(studentID);
        }

        public DataTable SelectStudentsOrderByGPA()
        {
            return dalStudent.SelectStudentsOrderByGPA();
        }

        public DataTable SelectStudentsByHometown(string hometown)
        {
            return dalStudent.SelectStudentsByHometown(hometown);
        }

        public string GetNextStudentID()
        {

            DataTable tb = dalStudent.SelectAllStudents();
            if (tb.Rows.Count > 0)
            {
                string lastStudentID = tb.Rows[tb.Rows.Count - 1]["StudentID"].ToString();
                int lastNumber = int.Parse(lastStudentID.Substring(2)) + 1; 
                string nextStudentID = $"MS{lastNumber:00}"; 
                return nextStudentID;

            }
            else
            {
                return "SV001";
            }
        }
    }
}