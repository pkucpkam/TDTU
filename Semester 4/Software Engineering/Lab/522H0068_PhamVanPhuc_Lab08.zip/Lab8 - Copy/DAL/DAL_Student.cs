﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DAL
{
    public class DAL_Student
    {
        private DTO_Student student;

        public DAL_Student(string studentID, string fullName, string hometown, DateTime dob, decimal gpa)
        {
            student = new DTO_Student(studentID, fullName, hometown, dob, gpa);
        }

        public void AddStudent()
        {
            string query = $"INSERT INTO Student VALUES ('{student.StudentID}', '{student.FullName}', '{student.Hometown}', '{student.DOB.ToString("yyyy-MM-dd")}', {student.GPA})";
            Connection.actionQuery(query);
        }

        public void UpdateStudent()
        {
            string query = $"UPDATE Student SET FullName = '{student.FullName}', Hometown = '{student.Hometown}', DOB = '{student.DOB.ToString("yyyy-MM-dd")}', GPA = {student.GPA} WHERE StudentID = '{student.StudentID}'";
            Connection.actionQuery(query);
        }

        public void DeleteStudent()
        {
            string query = $"DELETE FROM Student WHERE StudentID = '{student.StudentID}'";
            Connection.actionQuery(query);
        }

        public DataTable SelectAllStudents()
        {
            string query = "SELECT * FROM Student";
            return Connection.selectQuery(query);
        }

        public DataTable SelectStudentByID(string studentID)
        {
            string query = $"SELECT * FROM Student WHERE StudentID = '{studentID}'";
            return Connection.selectQuery(query);
        }

        public DataTable SelectStudentsOrderByGPA()
        {
            string query = "SELECT * FROM Student ORDER BY GPA DESC";
            return Connection.selectQuery(query);
        }

        public DataTable SelectStudentsByHometown(string hometown)
        {
            string query = $"SELECT * FROM Student WHERE Hometown = '{hometown}'";
            return Connection.selectQuery(query);
        }
    }
}