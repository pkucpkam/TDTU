﻿using BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace Lab8
{
    public partial class Form1 : Form
    {
        BUS_Student l;
        int dk = 0;

        public void enable(GroupBox grp, bool b)
        {
            grp.Enabled = b;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            l = new BUS_Student("SV001", "Full Name", "Hometown", DateTime.Now, 0);
            grd.DataSource = l.SelectAllStudents();

            enable(grp1, false);

        }

        private void bADD_Click(object sender, EventArgs e)
        {
            dk = 1;
            txtSID.Text = l.GetNextStudentID();

            txtFN.Clear();
            txtGPA.Clear();
            cbHT.Text = "";
            enable(grp1, true);


        }

        private void bSAVE_Click(object sender, EventArgs e)
        {
            string s = "";
            decimal gpa;
            decimal.TryParse(txtGPA.Text, out gpa);
            if (dk == 1)
            {
                l = new BUS_Student(txtSID.Text, txtFN.Text, cbHT.Text, dpDOB.Value, gpa);
                l.AddStudent();
            }
            else if (dk == 2)
            {
                l = new BUS_Student(txtSID.Text, txtFN.Text, cbHT.Text, dpDOB.Value, gpa);
                l.UpdateStudent();
            }
            grd.DataSource = l.SelectAllStudents();
        }

        private void bEDIT_Click(object sender, EventArgs e)
        {
            enable(grp1, true);
        }

        private void bDEL_Click(object sender, EventArgs e)
        {
            decimal gpa;
            decimal.TryParse(txtGPA.Text, out gpa);
            l = new BUS_Student(txtSID.Text, txtFN.Text, cbHT.Text, dpDOB.Value, gpa);
            l.DeleteStudent();
        }

        private void grd_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtSID.Text = grd.CurrentRow.Cells[0].Value.ToString();
            txtFN.Text = grd.CurrentRow.Cells[1].Value.ToString();
            cbHT.Text = grd.CurrentRow.Cells[2].Value.ToString();
            dpDOB.Text = grd.CurrentRow.Cells[3].Value.ToString();
            txtGPA.Text = grd.CurrentRow.Cells[4].Value.ToString();

            bDEL.Enabled = true;
            bEDIT.Enabled = true;
        }
    }
}