package com.example.lab05;

import java.io.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "LoginServlet", value = "/login")
public class LoginServlet extends HttpServlet {
    // Xử lý GET (Hiển thị form đăng nhập)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Chuyển tiếp đến trang login.jsp khi nhận yêu cầu GET
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    // Xử lý POST (Xử lý đăng nhập)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Kiểm tra và xử lý đăng nhập
        UserDao userDao = new UserDao();
        User user = userDao.validateUser(username, password);

        if (user != null) {
            // Lưu thông tin người dùng vào session
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            // Sau khi đăng nhập thành công, chuyển hướng đến trang chủ
            response.sendRedirect("/lab05");
        } else {
            // Nếu đăng nhập thất bại, hiển thị thông báo lỗi
            request.setAttribute("error", "Invalid username or password.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}