'use client';

import * as React from 'react';
import RouterLink from 'next/link';
import { useRouter } from 'next/navigation';
import { zodResolver } from '@hookform/resolvers/zod';
import Alert from '@mui/material/Alert';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import FormControl from '@mui/material/FormControl';
import FormHelperText from '@mui/material/FormHelperText';
import InputLabel from '@mui/material/InputLabel';
import Link from '@mui/material/Link';
import OutlinedInput from '@mui/material/OutlinedInput';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import { Eye as EyeIcon } from '@phosphor-icons/react/dist/ssr/Eye';
import { EyeSlash as EyeSlashIcon } from '@phosphor-icons/react/dist/ssr/EyeSlash';
import { Controller, useForm } from 'react-hook-form';
import { z as zod } from 'zod';

import { paths } from '@/paths';
import { createClient as createSupabaseClient } from '@/lib/supabase/client';
import { DynamicLogo } from '@/components/core/logo';
import { toast } from '@/components/core/toaster';

const oAuthProviders = [
    { id: 'google', name: 'Google', logo: '/assets/logo-google.svg' },
    { id: 'discord', name: 'Discord', logo: '/assets/logo-discord.svg' },
];

const schema = zod.object({
    email: zod.string().min(1, { message: 'Email is required' }).email(),
    password: zod.string().min(1, { message: 'Password is required' }),
});

const defaultValues = { email: '', password: '' };

export function SignInForm() {
    const [supabaseClient] = React.useState(createSupabaseClient());

    const router = useRouter();

    const [showPassword, setShowPassword] = React.useState();

    const [isPending, setIsPending] = React.useState(false);

    const {
        control,
        handleSubmit,
        setError,
        formState: { errors },
    } = useForm({ defaultValues, resolver: zodResolver(schema) });

    const onAuth = React.useCallback(
        async (providerId) => {
            setIsPending(true);

            const redirectToUrl = new URL(paths.auth.supabase.callback.pkce, window.location.origin);
            redirectToUrl.searchParams.set('next', paths.dashboard.overview);

            const { data, error } = await supabaseClient.auth.signInWithOAuth({
                provider: providerId,
                options: { redirectTo: redirectToUrl.href },
            });

            if (error) {
                setIsPending(false);
                toast.error(error.message);
                return;
            }

            window.location.href = data.url;
        },
        [supabaseClient]
    );

    const onSubmit = React.useCallback(
        async (values) => {
            setIsPending(true);

            const { error } = await supabaseClient.auth.signInWithPassword({
                email: values.email,
                password: values.password,
            });

            if (error) {
                if (error.message.includes('Email not confirmed')) {
                    // You should resend the verification email.
                    // For the sake of simplicity, we will just redirect to the confirmation page.
                    const searchParams = new URLSearchParams({ email: values.email });
                    router.push(`${paths.auth.supabase.signUpConfirm}?${searchParams.toString()}`);
                } else {
                    setError('root', { type: 'server', message: error.message });
                    setIsPending(false);
                }
            } else {
                // UserProvider will handle Router refresh
                // After refresh, GuestGuard will handle the redirect
            }
        },
        [supabaseClient, router, setError]
    );

    return (
        <Stack spacing={4}>
            <div>
                <Box component={RouterLink} href={paths.home} sx={{ display: 'inline-block', fontSize: 0 }}>
                    <DynamicLogo colorDark="light" colorLight="dark" height={32} width={122} />
                </Box>
            </div>
            <Stack spacing={1}>
                <Typography variant="h5">Sign in</Typography>
                <Typography color="text.secondary" variant="body2">
                    Don&apos;t have an account?{' '}
                    <Link component={RouterLink} href={paths.auth.supabase.signUp} variant="subtitle2">
                        Sign up
                    </Link>
                </Typography>
            </Stack>
            <Stack spacing={3}>
                <Stack spacing={2}>
                    {oAuthProviders.map((provider) => (
                        <Button
                            color="secondary"
                            disabled={isPending}
                            endIcon={<Box alt="" component="img" height={24} src={provider.logo} width={24} />}
                            key={provider.id}
                            onClick={() => {
                                onAuth(provider.id).catch(() => {
                                    // noop
                                });
                            }}
                            variant="outlined"
                        >
                            Continue with {provider.name}
                        </Button>
                    ))}
                </Stack>
                <Divider>or</Divider>
                <Stack spacing={2}>
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <Stack spacing={2}>
                            <Controller
                                control={control}
                                name="email"
                                render={({ field }) => (
                                    <FormControl error={Boolean(errors.email)}>
                                        <InputLabel>Email address</InputLabel>
                                        <OutlinedInput {...field} type="email" />
                                        {errors.email ? <FormHelperText>{errors.email.message}</FormHelperText> : null}
                                    </FormControl>
                                )}
                            />
                            <Controller
                                control={control}
                                name="password"
                                render={({ field }) => (
                                    <FormControl error={Boolean(errors.password)}>
                                        <InputLabel>Password</InputLabel>
                                        <OutlinedInput
                                            {...field}
                                            endAdornment={
                                                showPassword ? (
                                                    <EyeIcon
                                                        cursor="pointer"
                                                        fontSize="var(--icon-fontSize-md)"
                                                        onClick={() => {
                                                            setShowPassword(false);
                                                        }}
                                                    />
                                                ) : (
                                                    <EyeSlashIcon
                                                        cursor="pointer"
                                                        fontSize="var(--icon-fontSize-md)"
                                                        onClick={() => {
                                                            setShowPassword(true);
                                                        }}
                                                    />
                                                )
                                            }
                                            type={showPassword ? 'text' : 'password'}
                                        />
                                        {errors.password ? (
                                            <FormHelperText>{errors.password.message}</FormHelperText>
                                        ) : null}
                                    </FormControl>
                                )}
                            />
                            {errors.root ? <Alert color="error">{errors.root.message}</Alert> : null}
                            <Button disabled={isPending} type="submit" variant="contained">
                                Sign in
                            </Button>
                        </Stack>
                    </form>
                    <div>
                        <Link component={RouterLink} href={paths.auth.supabase.resetPassword} variant="subtitle2">
                            Forgot password?
                        </Link>
                    </div>
                </Stack>
            </Stack>
        </Stack>
    );
}
