import HomePage from './home';

export default HomePage;
