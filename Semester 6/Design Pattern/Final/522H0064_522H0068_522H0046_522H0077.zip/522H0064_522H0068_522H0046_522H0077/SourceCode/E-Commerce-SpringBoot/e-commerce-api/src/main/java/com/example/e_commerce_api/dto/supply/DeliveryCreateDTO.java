package com.example.e_commerce_api.dto.supply;

public record DeliveryCreateDTO(
        String info
) {
}
