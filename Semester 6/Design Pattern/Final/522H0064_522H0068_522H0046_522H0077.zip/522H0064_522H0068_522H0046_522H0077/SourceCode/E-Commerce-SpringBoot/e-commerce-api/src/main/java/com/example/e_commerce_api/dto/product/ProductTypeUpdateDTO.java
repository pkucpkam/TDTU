package com.example.e_commerce_api.dto.product;

public record ProductTypeUpdateDTO(
        Integer id,
        String productTypeName
) {
}
