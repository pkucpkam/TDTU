namespace Chapter.State
{
    public enum Direction
    {
        Left = -1,
        Right = 1
    }
}