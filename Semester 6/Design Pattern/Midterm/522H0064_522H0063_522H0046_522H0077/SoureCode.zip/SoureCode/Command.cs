﻿namespace Chapter.Command
{
    public abstract class Command
    {
        public abstract void Execute();
    }
}