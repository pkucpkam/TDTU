namespace Chapter.Strategy
public class AbsoluteShield : IShieldBehaviour
{
    public float AbsorbDamage(float damage)
    {
        return 0f;  
    }
}
