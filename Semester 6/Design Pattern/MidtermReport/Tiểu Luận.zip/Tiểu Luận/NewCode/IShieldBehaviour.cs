namespace Chapter.Strategy
public interface IShieldBehaviour
{
    float AbsorbDamage(float damage); 
}
