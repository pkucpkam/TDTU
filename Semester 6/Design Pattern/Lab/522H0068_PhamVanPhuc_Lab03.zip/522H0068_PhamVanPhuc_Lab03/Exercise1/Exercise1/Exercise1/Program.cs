﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CaffeineBeverage myCoffee = new Coffee();
            CaffeineBeverage myTea = new Tea();

            // Pha chế cà phê
            Console.WriteLine("Making coffee...");
            myCoffee.PrepareRecipe();

            Console.WriteLine();

            // Pha chế trà
            Console.WriteLine("Making tea...");
            myTea.PrepareRecipe();
        }
    }
}
