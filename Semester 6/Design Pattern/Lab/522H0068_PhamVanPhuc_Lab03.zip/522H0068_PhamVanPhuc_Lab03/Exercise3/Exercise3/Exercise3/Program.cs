﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Order internationalOrder = new InternationalOrder();
            Order domesticOrder = new DomesticOrder();

            Console.WriteLine("Processing International Order:");
            internationalOrder.ProcessOrder();
            Console.WriteLine();

            Console.WriteLine("Processing Domestic Order:");
            domesticOrder.ProcessOrder();
        }
    }
}
