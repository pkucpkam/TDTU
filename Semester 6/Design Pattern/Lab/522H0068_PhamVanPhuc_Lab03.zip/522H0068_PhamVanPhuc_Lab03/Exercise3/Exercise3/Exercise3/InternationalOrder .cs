﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3
{
    public class InternationalOrder : Order
    {
        public override void CreateOrder()
        {
            Console.WriteLine("Creating international order");
        }

        public override void CheckPayment()
        {
            Console.WriteLine("Checking international payment");
        }

        public override void ShipOrder()
        {
            Console.WriteLine("Shipping order internationally");
        }
    }
}
