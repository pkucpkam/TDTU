﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3
{
    public abstract class Order
    {
        public void ProcessOrder()
        {
            CreateOrder();
            CheckPayment();
            ShipOrder();
        }

        public abstract void CreateOrder();
        public abstract void CheckPayment();
        public abstract void ShipOrder();
    }
}
