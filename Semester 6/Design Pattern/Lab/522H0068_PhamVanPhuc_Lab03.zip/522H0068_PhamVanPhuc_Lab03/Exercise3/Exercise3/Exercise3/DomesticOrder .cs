﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3
{
    public class DomesticOrder : Order
    {
        public override void CreateOrder()
        {
            Console.WriteLine("Creating domestic order");
        }

        public override void CheckPayment()
        {
            Console.WriteLine("Checking domestic payment");
        }

        public override void ShipOrder()
        {
            Console.WriteLine("Shipping order domestically");
        }
    }
}
