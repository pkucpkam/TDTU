﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    class StandardTriangle : Triangle
    {
        public StandardTriangle(int ax, int ay, int bx, int by) : base(ax, ay, bx, by) { }

        protected override void CalculatePointC()
        {
            cx = bx + 2;
            cy = by + 3;
        }

        protected override void DrawTriangle()
        {
            Console.WriteLine($"Drawing Regular Triangle with points ({ax},{ay}), ({bx},{by}), ({cx},{cy}):");
            Console.WriteLine("   *");
            Console.WriteLine("   ");
            Console.WriteLine(" *     *");
        }
    }
}
