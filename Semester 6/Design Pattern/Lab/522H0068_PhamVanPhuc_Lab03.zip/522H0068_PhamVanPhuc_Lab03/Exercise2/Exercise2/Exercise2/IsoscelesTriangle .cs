﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    class IsoscelesTriangle : Triangle
    {
        public IsoscelesTriangle(int ax, int ay, int bx, int by) : base(ax, ay, bx, by) { }

        protected override void CalculatePointC()
        {
            int mx = (ax + bx) / 2;
            int my = ay - 3;
            cx = mx;
            cy = my;
        }

        protected override void DrawTriangle()
        {
            Console.WriteLine($"Drawing Isosceles Triangle with points ({ax},{ay}), ({bx},{by}), ({cx},{cy}):");
            Console.WriteLine("   *");
            Console.WriteLine("       ");
            Console.WriteLine(" *   *");
        }
    }

}
