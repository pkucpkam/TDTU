﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    class EquilateralTriangle : Triangle
    {
        public EquilateralTriangle(int ax, int ay, int bx, int by) : base(ax, ay, bx, by) { }

        protected override void CalculatePointC()
        {
            int dx = bx - ax;
            int dy = by - ay;
            cx = ax + dy;  
            cy = ay - dx;
        }

        protected override void DrawTriangle()
        {
            Console.WriteLine($"Drawing Equilateral Triangle with points ({ax},{ay}), ({bx},{by}), ({cx},{cy}):");
            Console.WriteLine("      *");
            Console.WriteLine("         ");
            Console.WriteLine("  *      *");
        }
    }
}
