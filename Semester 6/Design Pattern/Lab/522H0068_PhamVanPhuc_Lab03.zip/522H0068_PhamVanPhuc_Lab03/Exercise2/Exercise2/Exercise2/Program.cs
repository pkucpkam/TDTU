﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Các điểm cố định A và B
            int ax = 0, ay = 0;
            int bx = 5, by = 0;

            // Tạo các đối tượng tam giác và vẽ chúng
            Triangle equilateral = new EquilateralTriangle(ax, ay, bx, by);
            equilateral.Draw();

            Console.WriteLine();

            Triangle right = new RightTriangle(ax, ay, bx, by);
            right.Draw();

            Console.WriteLine();

            Triangle isosceles = new IsoscelesTriangle(ax, ay, bx, by);
            isosceles.Draw();

            Console.WriteLine();

            Triangle scalene = new StandardTriangle(ax, ay, bx, by);
            scalene.Draw();
        }
    }
}
