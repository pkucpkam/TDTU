﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    class RightTriangle : Triangle
    {
        public RightTriangle(int ax, int ay, int bx, int by) : base(ax, ay, bx, by) { }

        protected override void CalculatePointC()
        {
            cx = bx;
            cy = ay;
        }

        protected override void DrawTriangle()
        {
            Console.WriteLine($"Drawing Right Triangle with points ({ax},{ay}), ({bx},{by}), ({cx},{cy}):");
            Console.WriteLine("*");
            Console.WriteLine(" ");
            Console.WriteLine("*   *");
        }
    }
}
