﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    public abstract class Triangle
    {
        protected int ax, ay, bx, by, cx, cy;

        // Constructor để xác định hai điểm cố định A và B
        public Triangle(int ax, int ay, int bx, int by)
        {
            this.ax = ax;
            this.ay = ay;
            this.bx = bx;
            this.by = by;
        }

        // Phương thức template
        public void Draw()
        {
            CalculatePointC(); // Tính toán điểm C tùy vào loại tam giác
            DrawTriangle();    // Vẽ tam giác
        }

        // Phương thức tính toán điểm C, cần được cài đặt trong lớp con
        protected abstract void CalculatePointC();

        // Phương thức vẽ tam giác
        protected abstract void DrawTriangle();
    }
}
