﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Exercise1
{
    public partial class Form1 : Form
    {
        private string currentFilePath = string.Empty;

        public Form1()
        {
            InitializeComponent();
            newToolStripMenuItem.Click += New_Click;
            openToolStripMenuItem.Click += Open_Click;
            saveToolStripMenuItem.Click += Save_Click;
            exitToolStripMenuItem.Click += Exit_Click;
            copyToolStripMenuItem.Click += Copy_Click;
            pasteToolStripMenuItem.Click += Paste_Click;
            deleteToolStripMenuItem.Click += Delete_Click;

            toolStripButtonNew.Click += New_Click;
            toolStripButtonOpen.Click += Open_Click;
            toolStripButtonSave.Click += Save_Click;
            toolStripButtonCopy.Click += Copy_Click;
            toolStripButtonPaste.Click += Paste_Click;
        }

        private void New_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            currentFilePath = string.Empty;
            this.Text = "Simple Notepad - New Document";
        }

        private void Open_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    textBox1.Text = File.ReadAllText(openFileDialog.FileName);
                    currentFilePath = openFileDialog.FileName;
                    this.Text = $"Simple Notepad - {Path.GetFileName(currentFilePath)}";
                }
            }
        }

        private void Save_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(currentFilePath))
            {
                using (SaveFileDialog saveFileDialog = new SaveFileDialog())
                {
                    saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        File.WriteAllText(saveFileDialog.FileName, textBox1.Text);
                        currentFilePath = saveFileDialog.FileName;
                        this.Text = $"Simple Notepad - {Path.GetFileName(currentFilePath)}";
                    }
                }
            }
            else
            {
                File.WriteAllText(currentFilePath, textBox1.Text);
            }
        }

        private void Copy_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectionLength > 0)
                Clipboard.SetText(textBox1.SelectedText);
        }

        private void Paste_Click(object sender, EventArgs e)
        {
            if (Clipboard.ContainsText())
                textBox1.SelectedText = Clipboard.GetText();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectionLength > 0)
                textBox1.SelectedText = string.Empty;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}