﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    internal class SortApp
    {
        public static void Main(string[] args)
        {
            SortedList test = new SortedList();

            test.Add(1);
            test.Add(5);
            test.Add(3);
            test.Add(9);
            test.Add(4);

            test.SetSortStrategy(new QuickSortStrategy());
            test.SortList();
            test.PrintList();

            test.SetSortStrategy(new InsertionSortStrategy());
            test.SortList();
            test.PrintList();

            test.SetSortStrategy(new SelectionSortStrategy());
            test.SortList();
            test.PrintList();
        }
    }
}
