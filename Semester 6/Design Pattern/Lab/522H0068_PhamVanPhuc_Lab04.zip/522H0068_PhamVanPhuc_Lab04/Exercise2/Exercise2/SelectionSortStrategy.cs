﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    public class SelectionSortStrategy : ISortStrategy
    {
        public void Sort(List<int> list)
        {
            list.Sort((x, y) => y.CompareTo(x));  // Sắp xếp giảm dần
            Console.WriteLine("List sorted with SelectionSort (descending order).");
        }
    }
}
