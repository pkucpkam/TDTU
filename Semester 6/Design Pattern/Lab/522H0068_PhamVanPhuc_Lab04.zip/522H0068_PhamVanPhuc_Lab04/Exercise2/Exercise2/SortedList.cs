﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    public class SortedList
    {
        private List<int> list = new List<int>(); 
        private ISortStrategy sortStrategy;

        public void SetSortStrategy(ISortStrategy strategy)
        {
            sortStrategy = strategy;
        }

        public void Add(int number)
        {
            list.Add(number);
        }

        public void SortList()
        {
            if (sortStrategy != null)
            {
                sortStrategy.Sort(list);
            }
            else
            {
                Console.WriteLine("No sorting strategy is set.");
            }
        }

        public void PrintList()
        {
            foreach (var item in list)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();
        }
    }
}
