﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1
{
    public class ShapeFactory
    {
        public IShape CreateShape(int shape, int style)
        {
            if (style == 2) 
            {
                switch (shape)
                {
                    case 1:
                        return new SolidCircle();
                    case 2:
                        return new SolidSquare();
                    case 3:
                        return new SolidRectangle();
                    default:
                        throw new ArgumentException("Invalid shape type");
                }
            }
            else 
            {
                switch (shape)
                {
                    case 1:
                        return new Circle();
                    case 2:
                        return new Square();
                    case 3:
                        return new Rectangle();
                    default:
                        throw new ArgumentException("Invalid shape type");
                }
            }
        }
    }
}
