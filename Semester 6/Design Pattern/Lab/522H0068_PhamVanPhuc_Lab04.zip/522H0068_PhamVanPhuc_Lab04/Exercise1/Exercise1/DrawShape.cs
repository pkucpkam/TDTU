﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1
{
    public class DrawShape
    {
        private ShapeFactory _shapeFactory;

        public DrawShape()
        {
            _shapeFactory = new ShapeFactory();
        }

        public void Draw(int shape, int style)
        {
            IShape shapeObj = _shapeFactory.CreateShape(shape, style);
            shapeObj.Draw();
        }
    }

}
