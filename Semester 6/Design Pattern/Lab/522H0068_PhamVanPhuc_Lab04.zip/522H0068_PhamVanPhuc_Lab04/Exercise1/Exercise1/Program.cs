﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            DrawShape drawShape = new DrawShape();

            Console.WriteLine("Non-solid Shapes:");
            drawShape.Draw(1, 1);  
            drawShape.Draw(2, 1);  
            drawShape.Draw(3, 1);  

            Console.WriteLine("\nSolid Shapes:");
            drawShape.Draw(1, 2); 
            drawShape.Draw(2, 2);  
            drawShape.Draw(3, 2);  
        }
    }
}
