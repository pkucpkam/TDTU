﻿using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise4
{
    public class Square : IShape
    {
        private DashStyle dashStyle;

        public Square(DashStyle dashStyle)
        {
            this.dashStyle = dashStyle;
        }

        public void Draw(int x, int y, Graphics g)
        {
            using (Pen pen = new Pen(Color.Black, 2) { DashStyle = dashStyle })
            {
                g.DrawRectangle(pen, x - 25, y - 25, 50, 50);  // Vẽ viền
            }
        }
    }
}
