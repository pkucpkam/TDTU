﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise4
{
    public partial class Form1 : Form
    {
        private int selectedShape = 1;  // 1: Circle, 2: Square, 3: Rectangle
        private int selectedStyle = 1;  // 1: Regular, 2: Solid
        private DashStyle selectedDashStyle = DashStyle.Solid;  // Kiểu nét (liền, đứt)
        private List<ShapeDrawing> drawings = new List<ShapeDrawing>();
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBoxShapes_SelectedValueChanged(object sender, EventArgs e)
        {
            switch (comboBoxShapes.SelectedIndex)
            {
                case 0: // Circle
                    selectedShape = 1;
                    break;
                case 1: // Square
                    selectedShape = 2;
                    break;
                case 2: // Rectangle
                    selectedShape = 3;
                    break;
            }
        }

        private void comboFillShapes_SelectedValueChanged(object sender, EventArgs e)
        {
            switch (comboFillShapes.SelectedIndex)
            {
                case 0: // Solid
                    selectedStyle = 2;
                    break;
                case 1: // Regular
                    selectedStyle = 1;
                    break;
            }
        }

        private void comboStrokeShapes_SelectedValueChanged(object sender, EventArgs e)
        {
            switch (comboStrokeShapes.SelectedIndex)
            {
                case 0: // Solid Line
                    selectedDashStyle = DashStyle.Solid;
                    break;
                case 1: // Dashed Line
                    selectedDashStyle = DashStyle.Dash;
                    break;
            }
        }

        private void panelDraw_MouseClick(object sender, MouseEventArgs e)
        {
            IShape shape = ShapeFactory.CreateShape(selectedShape, selectedStyle, selectedDashStyle);
            drawings.Add(new ShapeDrawing(shape, e.X, e.Y));
            panelDraw.Invalidate();  // Vẽ lại panel
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            drawings.Clear();
            panelDraw.Invalidate();  // Vẽ lại panel
        }

        private void panelDraw_Paint(object sender, PaintEventArgs e)
        {
            foreach (var drawing in drawings)
            {
                drawing.Shape.Draw(drawing.X, drawing.Y, e.Graphics);
            }
        }
    }
}
