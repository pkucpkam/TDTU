﻿using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise4
{
    public static class ShapeFactory
    {
        public static IShape CreateShape(int shape, int style, DashStyle dashStyle)
        {
            if (style == 2)  
            {
                if (shape == 1) return new SolidCircle(dashStyle);
                if (shape == 2) return new SolidSquare(dashStyle);
                return new SolidRectangle(dashStyle);
            }
            else  
            {
                if (shape == 1) return new Circle(dashStyle);
                if (shape == 2) return new Square(dashStyle);
                return new Rectangle(dashStyle);
            }
        }
    }
}
