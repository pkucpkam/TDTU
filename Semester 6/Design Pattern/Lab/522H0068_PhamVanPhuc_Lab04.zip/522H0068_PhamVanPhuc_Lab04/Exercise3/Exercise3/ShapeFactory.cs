﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3
{
    public static class ShapeFactory
    {
        public static IShape CreateShape(int shape, int style)
        {
            if (style == 2)
            {
                if (shape == 1)
                    return new SolidCircle();
                else if (shape == 2)
                    return new SolidSquare();
                else
                    return new SolidRectangle();
            }
            else
            {
                if (shape == 1)
                    return new Circle();
                else if (shape == 2)
                    return new Square();
                else
                    return new Rectangle();
            }
        }
    }
}
