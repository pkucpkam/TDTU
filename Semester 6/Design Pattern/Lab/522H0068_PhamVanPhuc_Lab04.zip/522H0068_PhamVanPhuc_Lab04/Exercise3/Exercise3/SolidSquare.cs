﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3
{
    public class SolidSquare : IShape
    {
        public void Draw(int x, int y, Graphics g)
        {
            g.FillRectangle(Brushes.Black, x - 25, y - 25, 50, 50); // Fill (Solid)
        }
    }
}
