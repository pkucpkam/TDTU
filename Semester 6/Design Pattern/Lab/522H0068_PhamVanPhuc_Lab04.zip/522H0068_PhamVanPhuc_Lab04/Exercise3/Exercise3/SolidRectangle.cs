﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3
{
    public class SolidRectangle : IShape
    {
        public void Draw(int x, int y, Graphics g)
        {
            g.FillRectangle(Brushes.Black, x - 40, y - 20, 80, 40); // Fill (Solid)
        }
    }
}
