﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise3
{
    public partial class Form1 : Form
    {
        private int selectedShape = 1;  
        private int selectedStyle = 2;
        private List<ShapeDrawing> drawings = new List<ShapeDrawing>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBoxShapes_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }


        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            IShape shape = ShapeFactory.CreateShape(selectedShape, selectedStyle);
            shape.Draw(e.X, e.Y, this.CreateGraphics());
        }

        private void buttonClear_MouseClick(object sender, MouseEventArgs e)
        {
            drawings.Clear();  
            panelDraw.Invalidate();
        }

        private void panelDraw_MouseClick(object sender, MouseEventArgs e)
        {
            IShape shape = ShapeFactory.CreateShape(selectedShape, selectedStyle);
            drawings.Add(new ShapeDrawing(shape, e.X, e.Y));  
            panelDraw.Invalidate();
        }

        private void panelDraw_Paint(object sender, PaintEventArgs e)
        {
            foreach (var drawing in drawings)
            {
                drawing.Shape.Draw(drawing.X, drawing.Y, e.Graphics);
            }
        }

        private void comboBoxShapes_SelectedValueChanged(object sender, EventArgs e)
        {
            switch (comboBoxShapes.SelectedIndex)
            {
                case 0: 
                    selectedShape = 1;
                    break;
                case 1: 
                    selectedShape = 2;
                    break;
                case 2: 
                    selectedShape = 3;
                    break;
                default:
                    selectedShape = 1; 
                    break;
            }
        }

        private void radioButtonSolid_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonSolid.Checked)
                selectedStyle = 2;
            else
                selectedStyle = 1;
        }
    }
   
}
