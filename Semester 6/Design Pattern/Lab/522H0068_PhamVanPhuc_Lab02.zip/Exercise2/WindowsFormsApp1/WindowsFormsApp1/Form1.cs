﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            // Kiểm tra số thực
            Validator numberValidator = new Validator(new NumberValidation());
            bool isNumberValid = numberValidator.Validate(doubleTB.Text);

            // Kiểm tra số nguyên
            Validator intValidator = new Validator(new IntegerValidation());
            bool isIntValid = intValidator.Validate(intTB.Text);

            // Kiểm tra chuỗi
            Validator stringValidator = new Validator(new StringValidation());
            bool isStringValid = stringValidator.Validate(stringTB.Text); // Kiểm tra email

            // Kiểm tra email
            Validator emailValidator = new Validator(new EmailValidation());
            bool isEmailValid = emailValidator.Validate(emailTB.Text);

            // Kiểm tra ngày tháng
            Validator dateValidator = new Validator(new DateValidation());
            bool isDateValid = dateValidator.Validate(dateTB.Text);

            // Hiển thị kết quả
            resultTxt.Text = $"Số thực hợp lệ: {(isNumberValid ? "Hợp lệ" : "Không hợp lệ")}\n" +
                             $"Số nguyên hợp lệ: {(isIntValid ? "Hợp lệ" : "Không hợp lệ")}\n" +
                             $"Chuỗi hợp lệ: {(isStringValid ? "Hợp lệ" : "Không hợp lệ")}\n" +
                             $"Email hợp lệ: {(isEmailValid ? "Hợp lệ" : "Không hợp lệ")}\n" +
                             $"Ngày tháng hợp lệ: {(isDateValid ? "Hợp lệ" : "Không hợp lệ")}";
        }
    }
}
