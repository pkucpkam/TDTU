﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Validator
    {
        private IValidationStrategy _validationStrategy;

        public Validator(IValidationStrategy validationStrategy)
        {
            _validationStrategy = validationStrategy;
        }

        public void SetValidationStrategy(IValidationStrategy validationStrategy)
        {
            _validationStrategy = validationStrategy;
        }

        public bool Validate(string input)
        {
            return _validationStrategy.Validate(input);
        }
    }

}
