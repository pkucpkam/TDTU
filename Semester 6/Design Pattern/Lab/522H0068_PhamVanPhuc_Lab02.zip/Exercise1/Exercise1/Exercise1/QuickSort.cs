﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1
{
    public class QuickSort : ISortStrategy
    {
        public void Sort(List<int> numbers)
        {
            QuickSortRecursive(numbers, 0, numbers.Count - 1);
        }

        private void QuickSortRecursive(List<int> numbers, int low, int high)
        {
            if (low < high)
            {
                int pi = Partition(numbers, low, high);
                QuickSortRecursive(numbers, low, pi - 1);
                QuickSortRecursive(numbers, pi + 1, high);
            }
        }

        private int Partition(List<int> numbers, int low, int high)
        {
            int pivot = numbers[high];
            int i = low - 1;
            for (int j = low; j < high; j++)
            {
                if (numbers[j] <= pivot)
                {
                    i++;
                    int temp = numbers[i];
                    numbers[i] = numbers[j];
                    numbers[j] = temp;
                }
            }
            int temp1 = numbers[i + 1];
            numbers[i + 1] = numbers[high];
            numbers[high] = temp1;
            return i + 1;
        }
    }

}
