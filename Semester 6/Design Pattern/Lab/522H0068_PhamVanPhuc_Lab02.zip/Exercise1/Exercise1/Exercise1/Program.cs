﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = new List<int> { 64, 34, 25, 12, 22, 11, 90 };

            Console.WriteLine("Original List:");
            PrintList(numbers);

            // Sử dụng BubbleSort
            Sorter sorter = new Sorter(new BubbleSort());
            sorter.SortNumbers(numbers);
            Console.WriteLine("\nSorted using BubbleSort:");
            PrintList(numbers);

            // Sử dụng SelectionSort
            numbers = new List<int> { 64, 34, 25, 12, 22, 11, 90 };
            sorter.SetSortStrategy(new SelectionSort());
            sorter.SortNumbers(numbers);
            Console.WriteLine("\nSorted using SelectionSort:");
            PrintList(numbers);

            // Sử dụng QuickSort
            numbers = new List<int> { 64, 34, 25, 12, 22, 11, 90 };
            sorter.SetSortStrategy(new QuickSort());
            sorter.SortNumbers(numbers);
            Console.WriteLine("\nSorted using QuickSort:");
            PrintList(numbers);
        }

        static void PrintList(List<int> numbers)
        {
            foreach (int num in numbers)
            {
                Console.Write(num + " ");
            }
            Console.WriteLine();
        }
    }
}
