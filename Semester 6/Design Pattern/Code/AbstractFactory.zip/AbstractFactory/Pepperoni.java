public interface Pepperoni {
    String toString();
}
