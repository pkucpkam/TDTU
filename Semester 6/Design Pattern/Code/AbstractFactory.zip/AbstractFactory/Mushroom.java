
public class Mushroom implements Veggies {
    public String toString() {
        return "Mushrooms";
    }

}
