public class ThickCrustDough implements Dough{
    public String toString() {
        return "Thin Crust Dough";
    }
}
