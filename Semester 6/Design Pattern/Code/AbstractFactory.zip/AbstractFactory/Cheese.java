public interface Cheese {
    String toString();
}
