
public class MozzarellaChesse implements Cheese {
    public String toString() {
        return "Shredded Mozzarella";
    }

}
