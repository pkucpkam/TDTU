public interface Clams {
    String toString();
}
