public interface Veggies {
    String toString();
}
