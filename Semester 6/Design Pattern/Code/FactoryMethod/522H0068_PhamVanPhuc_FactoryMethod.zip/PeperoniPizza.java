public class PeperoniPizza extends Pizza {
    public PeperoniPizza() {
        name = "Peperoni Pizza";
    }
}
