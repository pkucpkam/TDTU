class CheesePizza extends Pizza {
    public CheesePizza() {
        name = "Cheese Pizza";
    }
}