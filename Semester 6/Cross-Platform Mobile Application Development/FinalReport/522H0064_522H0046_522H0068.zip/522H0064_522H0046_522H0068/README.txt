# Group member information
- 522H0068 - Pham Van Phuc - Class 22H50202
- 522H0046 - Pham Duy Khanh - Class 22H50202
- 522H0064 - Nguyen Huynh Anh Khoa - Class 22H50202
# Prerequisites
To build and run the application, ensure you have the following installed:
- Flutter SDK (version 3.7.0 or higher)
- Dart SDK (included with Flutter)
- Android Studio or Visual Studio Code with Flutter and Dart plugins
- Firebase CLI (for Firebase configuration)
- A Firebase project set up in the Firebase Console
- An Android/iOS emulator or physical device for testing

# Setup Instructions
1. Open the Source Code Directory:
   - Navigate to the directory containing the project's source code using a terminal or file explorer.
   - Example: `cd /path/to/project_directory`

2. Install Dependencies
   Run the following command to install all required packages:
   flutter pub get

3. Build and Run
   - Connect an emulator or physical device.
   - Run the application using:
     flutter run

# Running the Application
- The app supports login via Firebase Authentication.
- Use the provided test accounts to log in and evaluate the application:
  - Account 1: phucpham.1803@gmail.com / Password: Phucpham1803# / OTP for testing: 222222
  - Account 2 anhkhoa@gmail.com / Password: Phucpham1803* / OTP for testing: 111111
  - Account 3 duykhanh@mail.com / Password: Phucpham1803* / OTP for testing: 111111
- These accounts have pre-loaded data in Firebase for testing core and optional features.

# Optional Features (Extra Points)
The following optional features have been implemented using the Gemini API:
1. Marking Emails as Spam (OOPSpam):
   - Users can flag emails as spam, which are processed using an object-oriented approach and stored in a dedicated Firebase collection.
   - Access this feature via the email list view by selecting the "Mark as Spam" option.
2. Email Translation:
   - Emails can be translated into different languages using Gemini's translation capabilities.
   - Available in the email detail view under the "Translate" button.
3. Email Summarization:
   - Gemini generates concise summaries of email content.
   - Accessible in the email detail view via the "Summarize" button.
4. Suggested Short Replies:
   - Gemini provides quick reply suggestions based on email content.
   - Available in the email detail view under the "Suggest Reply" button.

# Notes for Evaluation
- Ensure a stable internet connection for Firebase and Gemini API interactions.
- Test the optional features with the provided accounts, as they are pre-configured with sample email data.

# Video presentation details: https://youtu.be/UDDYS077IBI 