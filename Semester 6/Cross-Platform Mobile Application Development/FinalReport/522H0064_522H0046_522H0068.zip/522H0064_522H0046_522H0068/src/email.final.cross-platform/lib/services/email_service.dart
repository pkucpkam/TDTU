// Flutter imports:
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

// Project imports:
import 'gemini_service.dart';
import 'notification_service.dart';

class EmailService extends GetxService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final NotificationService _notificationService = NotificationService();
  final GeminiService _geminiService = GeminiService();
  final RxInt unreadCount = 0.obs;
  bool isNotificationEnabled = false;
  DateTime? _initTime; // Lưu thời gian khởi tạo

  Future<void> init(String? currentUserId) async {
    if (currentUserId == null || currentUserId.isEmpty) {
      debugPrint(
          "Error: Cannot initialize EmailService, userId is null or empty");
      Get.snackbar('Error', 'User not logged in');
      return;
    }
    _initTime = DateTime.now(); // Lưu thời gian khởi tạo
    debugPrint(
        "EmailService initialized for user: $currentUserId at $_initTime");
    await _isNotificationEnabled();
    debugPrint("Notification enabled status: $isNotificationEnabled");
    listenForNewEmails(currentUserId);
  }

  Future<void> _isNotificationEnabled() async {
    final currentUser = FirebaseAuth.instance.currentUser?.uid;
    final userDoc = await _firestore.collection('users').doc(currentUser).get();
    if (userDoc.exists) {
      isNotificationEnabled = userDoc.data()?['isNotificationEnabled'] ?? false;
      debugPrint(
          "User document exists, isNotificationEnabled: $isNotificationEnabled");
    } else {
      // Nếu tài liệu người dùng không tồn tại, đặt giá trị mặc định
      debugPrint("User document does not exist, setting default value.");
    }
 
  }

  Future<String> getEmailSummary(String emailContent) async {
    return await _geminiService.summarizeEmail(emailContent);
  }

  Future<String> getEmailTranslate(String emailContent) async {
    return await _geminiService.translateEmail(emailContent);
  }

  Future<List<String>> getEmailQuickReplies(String emailContent) async {
    return await _geminiService.generateQuickReplies(emailContent);
  }

  Future<String> composeEmail(
      String subject, String keyPoints, String tone, String context) async {
    return await _geminiService.composeEmail(
        subject: subject, keyPoints: keyPoints, tone: tone, context: context);
  }

  void listenForNewEmails(String userId) {
    if (userId.isEmpty) {
      debugPrint("Error: userId is empty, cannot listen for emails");
      return;
    }
    debugPrint("Listening for new emails for user: $userId");
    _firestore
        .collection('users')
        .doc(userId)
        .collection('receiveMails')
        .where('unread', isEqualTo: true)
        .orderBy('time', descending: true)
        .snapshots()
        .listen((snapshot) {
      debugPrint(
          "Snapshot received with ${snapshot.docs.length} unread emails");
      unreadCount.value = snapshot.docs.length;

      for (var change in snapshot.docChanges) {
        debugPrint("Change detected: ${change.type}, Doc ID: ${change.doc.id}");
        if (change.type == DocumentChangeType.added ||
            change.type == DocumentChangeType.modified) {
          var emailData = change.doc.data();
          if (emailData == null) {
            debugPrint(
                "Error: Email data is null for doc ID: ${change.doc.id}");
            continue;
          }

          // Kiểm tra thời gian email
          String timeStr = emailData['time']?.toString() ?? '';
          if (timeStr.isEmpty) {
            debugPrint(
                "Error: Email time is empty for doc ID: ${change.doc.id}");
            continue;
          }

          DateTime? emailTime;
          try {
            emailTime =
                DateTime.parse(timeStr); // Chuyển chuỗi ISO8601 thành DateTime
          } catch (e) {
            debugPrint(
                "Error: Invalid time format for doc ID: ${change.doc.id}, time: $timeStr");
            continue;
          }

          // Chỉ hiển thị thông báo nếu email mới hơn hoặc bằng thời gian khởi tạo
          if (_initTime != null && emailTime.isAfter(_initTime!) ||
              emailTime.isAtSameMomentAs(_initTime!)) {
            String sender = emailData['sender']?.toString() ?? 'Unknown';
            String subject = emailData['subject']?.toString() ?? 'No Subject';
            String timestamp = DateFormat('dd/MM/yyyy HH:mm').format(emailTime);

            debugPrint(
                "New email detected - Sender: $sender, Subject: $subject, Time: $timestamp");

            debugPrint("Checking isNotificationEnabled: $isNotificationEnabled");

            if (isNotificationEnabled) {
              _notificationService.showEmailNotification(
                'New Email from $sender',
                '$subject - $timestamp',
              );
            } else {
              debugPrint("Notifications are disabled for this user.");
            }
          } else {
            debugPrint(
                "Skipped old email - Doc ID: ${change.doc.id}, Time: $timeStr");
          }
        }
      }
    }, onError: (error) {
      debugPrint("Error listening for emails: $error");
      Get.snackbar('Error', 'Failed to listen for emails: $error');
    });
  }
}
