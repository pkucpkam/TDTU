// Dart imports:
import 'dart:convert';
import 'dart:math';

// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;

// Project imports:
import 'package:final_project/components/custom_chip_input.dart';
import 'package:final_project/tabs/front_page.dart';

class ForwardMail extends StatefulWidget {
  final String mailId;
  final String userEmail;

  const ForwardMail({
    super.key,
    required this.mailId,
    required this.userEmail,
  });

  @override
  ForwardMailState createState() => ForwardMailState();
}

class ForwardMailState extends State<ForwardMail> {
  PlatformFile? file;
  bool entered = false;
  bool isSent = false;
  bool isSuccessfullySent = false;
  bool isCcBccExpanded = false;
  bool isSubjectFocused = false;
  bool isBodyFocused = false;
  bool isDraftSaved = false;
  String? fromValue;
  Map<String, dynamic>? originalMailData;
  List<Map<String, dynamic>> repliesData = [];
  bool isLoading = true;
  String? errorMessage;

  final FocusNode subjectFocusNode = FocusNode();
  final FocusNode bodyFocusNode = FocusNode();
  final quill.QuillController bodyController = quill.QuillController.basic();
  final ScrollController _scrollController = ScrollController();
  final String? currentUser = FirebaseAuth.instance.currentUser?.uid;
  final String? currentUserEmail = FirebaseAuth.instance.currentUser?.email;
  List<String> toEmails = [];
  List<String> ccEmails = [];
  List<String> bccEmails = [];
  final TextEditingController subjectController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadUserEmail();
    _loadOriginalMail();
    subjectFocusNode.addListener(() {
      setState(() {
        isSubjectFocused = subjectFocusNode.hasFocus;
      });
    });
  }

  Future<void> _loadUserEmail() async {
    setState(() {
      fromValue = currentUserEmail;
    });
  }

  Future<String?> _getCurrentUserAvatarUrl() async {
    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .get();
      if (userDoc.exists) {
        return userDoc.data()?['avatarUrl'] ?? 'assets/user.png';
      }
    } catch (e) {
      debugPrint('Lỗi khi lấy URL ảnh đại diện: $e');
    }
    return 'assets/user.png';
  }

  Future<void> _loadOriginalMail() async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection('mails')
          .doc(widget.mailId)
          .get();
      if (doc.exists && mounted) {
        final mailDataTemp = doc.data()!;
        final replyIds =
            (mailDataTemp['replies'] as List<dynamic>?)?.cast<String>() ?? [];
        List<Map<String, dynamic>> tempRepliesData = [];

        for (var replyId in replyIds) {
          final replyDoc = await FirebaseFirestore.instance
              .collection('repliesEmail')
              .doc(replyId)
              .get();
          if (replyDoc.exists) {
            tempRepliesData.add(replyDoc.data()!);
          }
        }

        setState(() {
          originalMailData = mailDataTemp;
          repliesData = tempRepliesData;
          subjectController.text = 'Fwd: ${originalMailData!['subject'] ?? ''}';
          isLoading = false;
        });
      } else {
        setState(() {
          errorMessage = 'Không tìm thấy email gốc';
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = 'Lỗi khi tải email gốc: $e';
        isLoading = false;
      });
    }
  }

  Future<String?> getUserName(String email) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email)
          .get();
      if (snapshot.docs.isNotEmpty) {
        final userData = snapshot.docs.first.data();
        final fullName = userData['fullName'] as String?;
        final lastName = userData['lastName'] as String?;
        String userName = '';
        if (fullName != null) userName += fullName;
        if (lastName != null) {
          userName += (userName.isNotEmpty ? ' ' : '') + lastName;
        }
        return userName.isNotEmpty ? userName : null;
      }
    } catch (e) {
      debugPrint('Lỗi khi lấy tên người dùng: $e');
    }
    return null;
  }

  Future<String?> _getReceiverId(String email) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email)
          .get();
      if (snapshot.docs.isNotEmpty) {
        return snapshot.docs.first.id;
      }
    } catch (e) {
      debugPrint('Lỗi khi lấy ID người nhận: $e');
    }
    return null;
  }

  Future<List<String>> _fetchEmailSuggestions(String query) async {
    if (query.isEmpty) return [];
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isGreaterThanOrEqualTo: query)
          .where('email', isLessThanOrEqualTo: '$query\uf8ff')
          .limit(10)
          .get();
      return snapshot.docs
          .map((doc) => doc['email'] as String)
          .where((email) => email != currentUserEmail)
          .toList();
    } catch (e) {
      debugPrint('Lỗi khi lấy gợi ý email: $e');
      return [];
    }
  }

  Future<void> saveDraft() async {
    if (isDraftSaved || isSuccessfullySent) {
      debugPrint('Bản nháp đã được lưu hoặc email đã gửi, bỏ qua.');
      return;
    }
    if (subjectController.text.isNotEmpty ||
        !bodyController.document.isEmpty() ||
        toEmails.isNotEmpty ||
        ccEmails.isNotEmpty ||
        bccEmails.isNotEmpty ||
        file != null) {
      if (currentUser == null) {
        debugPrint('Lỗi: Không tìm thấy người dùng đã xác thực.');
        return;
      }
      final draftId = FirebaseFirestore.instance.collection('drafts').doc().id;
      final draft = {
        'from': currentUserEmail,
        'to': toEmails.join(', '),
        'cc': ccEmails.join(', '),
        'bcc': bccEmails.join(', '),
        'subject': subjectController.text,
        'body': jsonEncode(bodyController.document.toDelta().toJson()),
        'attachment': file?.name,
        'time': DateTime.now().toIso8601String(),
        'mailId': draftId,
        'userId': currentUser,
        'isForward': true,
      };
      try {
        isDraftSaved = true;
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('drafts')
            .doc(draftId)
            .set(draft);
        await FirebaseFirestore.instance
            .collection('drafts')
            .doc(draftId)
            .set(draft);
        debugPrint('Đã lưu bản nháp với ID: $draftId');
      } catch (e) {
        debugPrint('Lỗi khi lưu bản nháp: $e');
        isDraftSaved = false;
      }
    }
  }

  Future<void> sendMail() async {
    if (toEmails.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
            'Please enter at least one recipient email',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.red[600],
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          elevation: 8,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          duration: const Duration(seconds: 3),
        ),
      );
      return;
    }

    final scaffoldMessenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    try {
      isSent = true;
      final mailId = FirebaseFirestore.instance.collection('mails').doc().id;
      final currentTime = DateTime.now();
      final subject =
          subjectController.text.replaceFirst(RegExp(r'^(Fwd: )'), '').trim();
      final senderName = await getUserName(currentUserEmail!);
      final allRecipients = {...toEmails, ...ccEmails, ...bccEmails}.toList();
      final receiverNames = <String, String?>{};
      final senderAvatarUrl = await _getCurrentUserAvatarUrl();
      for (var email in allRecipients) {
        receiverNames[email] = await getUserName(email);
      }

      final emailData = {
        'mailId': mailId,
        'sender': currentUserEmail,
        'senderName': senderName ?? 'Không xác định',
        'to': toEmails.join(', '),
        'toNames':
            toEmails.map((e) => receiverNames[e] ?? 'Unknown').join(', '),
        'cc': ccEmails.join(', '),
        'ccNames':
            ccEmails.map((e) => receiverNames[e] ?? 'Unknown').join(', '),
        'bcc': bccEmails.join(', '),
        'bccNames':
            bccEmails.map((e) => receiverNames[e] ?? 'Unknown').join(', '),
        'subject': subject,
        'text': jsonEncode(bodyController.document.toDelta().toJson()),
        'attachment': file?.name ,
        'time': currentTime.toIso8601String(),
        'isStarred': false,
        'unread': true,
        'isForward': true,
        'mailForwarded': widget.mailId,
        'color': getRandomColor().value,
        'senderAvatarUrl': senderAvatarUrl ?? 'assets/user.png',
      };

      final sentMailData = {
        'mailId': mailId,
        'receiver': toEmails.join(', '),
        'receiverNames':
            toEmails.map((e) => receiverNames[e] ?? 'Unknown').join(', '),
        'subject': subject,
        'text': jsonEncode(bodyController.document.toDelta().toJson()),
        'attachment': file?.name ?? 'Không có tệp đính kèm',
        'time': currentTime.toIso8601String(),
        'isStarred': false,
        'unread': false,
        'color': getRandomColor().value,
        'isTrash': false,
        'senderAvatarUrl': senderAvatarUrl ?? 'assets/user.png',
      };

      final receiveMailData = {
        'mailId': mailId,
        'sender': currentUserEmail,
        'senderName': senderName ?? 'Không xác định',
        'subject': subject,
        'text': jsonEncode(bodyController.document.toDelta().toJson()),
        'attachment': file?.name ,
        'time': currentTime.toIso8601String(),
        'isStarred': false,
        'unread': true,
        'color': getRandomColor().value,
        'isTrash': false,
        'senderAvatarUrl': senderAvatarUrl ?? 'assets/user.png',
      };

      await FirebaseFirestore.instance
          .collection('mails')
          .doc(mailId)
          .set(emailData);

      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('sentMails')
          .doc(mailId)
          .set(sentMailData);

      for (var email in allRecipients) {
        final receiverId = await _getReceiverId(email);
        if (receiverId != null) {
          await FirebaseFirestore.instance
              .collection('users')
              .doc(receiverId)
              .collection('receiveMails')
              .doc(mailId)
              .set({
            ...receiveMailData,
            'receiverName': receiverNames[email] ?? 'Không xác định',
            if (bccEmails.contains(email)) 'bcc': email,
          });
        }
      }

      isSuccessfullySent = true;
      setState(() {
        toEmails.clear();
        ccEmails.clear();
        bccEmails.clear();
        subjectController.clear();
        bodyController.clear();
        file = null;
        entered = false;
        isSent = false;
      });

      scaffoldMessenger.showSnackBar(
        SnackBar(
          content: const Text(
            'Forward successful',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.green[600],
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          elevation: 8,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          duration: const Duration(seconds: 2),
        ),
      );

      await Future.delayed(const Duration(seconds: 2));
      if (mounted) {
        navigator.pushReplacement(
          MaterialPageRoute(builder: (context) => const FrontPage()),
        );
      }
    } catch (e) {
      debugPrint('Lỗi khi gửi email chuyển tiếp: $e');
      scaffoldMessenger.showSnackBar(
        SnackBar(
          content: const Text(
            'Cannot forward email',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.red[600],
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          elevation: 8,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          duration: const Duration(seconds: 3),
        ),
      );
      if (mounted) {
        setState(() {
          isSent = false;
        });
      }
    }
  }

  Color getRandomColor() {
    final random = Random();
    return Color.fromARGB(
      255,
      random.nextInt(256),
      random.nextInt(256),
      random.nextInt(256),
    );
  }

  String parseQuillJsonToPlainText(String quillJson) {
    try {
      final List<dynamic> quillData = jsonDecode(quillJson);
      String plainText = quillData
          .where((element) => element['insert'] != null)
          .map((element) => element['insert'].toString())
          .join();
      return plainText.trim();
    } catch (e) {
      debugPrint('Lỗi khi phân tích Quill JSON: $e');
      return quillJson;
    }
  }

  Future<void> pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      setState(() {
        file = result.files.first;
        entered = true;
      });
    }
  }

  @override
  void dispose() {
    subjectFocusNode.dispose();
    bodyFocusNode.dispose();
    subjectController.dispose();
    bodyController.dispose();
    _scrollController.dispose();
    if (!isSuccessfullySent) {
      saveDraft();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    if (errorMessage != null) {
      return Scaffold(
        body: Center(child: Text(errorMessage!)),
      );
    }
    return PopScope(
      canPop: !isSent,
      onPopInvoked: (bool didPop) async {
        if (didPop || isSent || isSuccessfullySent) return;
        await saveDraft();
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.surface,
          iconTheme:
              IconThemeData(color: Theme.of(context).colorScheme.onSurface),
          title: Text(
            'Forward Email',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface,
              fontSize: 18,
              fontFamily: "Roboto",
            ),
          ),
          actions: [
            IconButton(
              icon: Icon(Icons.attach_file,
                  color: Theme.of(context).colorScheme.onSurface),
              onPressed: pickFile,
            ),
            IconButton(
              icon: Icon(Icons.send,
                  color: Theme.of(context).colorScheme.onSurface),
              onPressed: toEmails.isEmpty ? null : sendMail,
            ),
            PopupMenuButton<String>(
              offset: const Offset(0, 50),
              icon: Icon(Icons.more_vert,
                  color: Theme.of(context).colorScheme.onSurface),
              onSelected: (String value) async {
                if (value == '4') {
                  await saveDraft();
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: const Text(
                          'Saved as draft',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        backgroundColor: Colors.blue[600],
                        behavior: SnackBarBehavior.floating,
                        margin: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        elevation: 8,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        duration: const Duration(seconds: 3),
                      ),
                    );
                  }
                }
              },
              itemBuilder: (BuildContext context) {
                return [
                  const PopupMenuItem(value: '1', child: Text('Lên lịch')),
                  const PopupMenuItem(
                      value: '2', child: Text('Thêm từ danh bạ')),
                  const PopupMenuItem(value: '3', child: Text('Hủy')),
                  const PopupMenuItem(value: '4', child: Text('Lưu nháp')),
                ];
              },
            ),
          ],
          elevation: 0,
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 16,
            left: 16,
            right: 16,
            top: 16,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildFromField(),
              _buildDivider(),
              _buildToField(),
              _buildDivider(),
              if (isCcBccExpanded) _buildCcBccFields(),
              _buildSubjectField(),
              _buildDivider(),
              _buildBodyField(),
              _buildDivider(),
              const SizedBox(height: 16),
              _buildForwardedContent(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFromField() {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
            'From:',
            style: TextStyle(
                fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
          ),
        ),
        Expanded(
          child: Text(
            fromValue ?? 'Loading ...',
            style: TextStyle(
                fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
          ),
        ),
      ],
    );
  }

  Widget _buildToField() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
            'To:',
            style: TextStyle(
                fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
          ),
        ),
        Expanded(
          child: CustomChipInput(
            emails: toEmails,
            onChanged: (newEmails) {
              setState(() {
                toEmails = newEmails;
              });
            },
            fetchSuggestions: _fetchEmailSuggestions,
            suffixIcon: IconButton(
              icon: Icon(
                isCcBccExpanded ? Icons.arrow_drop_up : Icons.arrow_drop_down,
                color: Colors.grey[600],
              ),
              onPressed: () {
                setState(() {
                  isCcBccExpanded = !isCcBccExpanded;
                });
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCcBccFields() {
    return Column(
      children: [
        _buildFieldRow(
          label: 'Cc:',
          emails: ccEmails,
          onChanged: (newEmails) {
            setState(() {
              ccEmails = newEmails;
            });
          },
        ),
        _buildDivider(),
        _buildFieldRow(
          label: 'Bcc:',
          emails: bccEmails,
          onChanged: (newEmails) {
            setState(() {
              bccEmails = newEmails;
            });
          },
        ),
        _buildDivider(),
      ],
    );
  }

  Widget _buildSubjectField() {
    return TextField(
      controller: subjectController,
      focusNode: subjectFocusNode,
      cursorHeight: 22,
      style: TextStyle(
          fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
      decoration: InputDecoration(
        border: InputBorder.none,
        hintText: isSubjectFocused ? null : 'Subject',
        contentPadding: const EdgeInsets.all(20),
        hintStyle: TextStyle(fontSize: 18, color: Colors.grey[600]),
      ),
    );
  }

  Widget _buildBodyField() {
    return Column(
      children: [
        quill.QuillSimpleToolbar(
          config: const quill.QuillSimpleToolbarConfig(
            showBoldButton: true,
            showItalicButton: true,
            showUnderLineButton: true,
            showStrikeThrough: true,
            showFontFamily: true,
            showFontSize: true,
            showHeaderStyle: false,
            showListNumbers: false,
            showListBullets: true,
            showListCheck: false,
            showCodeBlock: true,
            showQuote: false,
            showIndent: false,
            showLink: false,
            showInlineCode: false,
            showClearFormat: true,
            showColorButton: true,
            showBackgroundColorButton: true,
            showUndo: false,
            showRedo: false,
            showClipboardCut: false,
            showClipboardCopy: false,
            showClipboardPaste: false,
            showAlignmentButtons: false,
            showDirection: false,
            showSearchButton: false,
            showSubscript: false,
            showSuperscript: false,
          ),
          controller: bodyController,
        ),
        Container(
          constraints: const BoxConstraints(minHeight: 200),
          padding: const EdgeInsets.all(20),
          child: quill.QuillEditor(
            scrollController: _scrollController,
            controller: bodyController,
            focusNode: bodyFocusNode,
            config: quill.QuillEditorConfig(
              placeholder: entered ? file!.name : 'Write your message ...',
              autoFocus: false,
              scrollable: true,
              padding: EdgeInsets.zero,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildForwardedContent() {
    return Card(
      elevation: 1,
      color: Theme.of(context).colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.grey.shade200),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Text(
                '---------- Forward Message ----------',
                style: TextStyle(
                  fontSize: 14,
                  color: Theme.of(context).colorScheme.onSurface,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'From: ${originalMailData?['sender'] ?? 'Không xác định'}\n'
              'Subject: ${originalMailData?['subject'] ?? 'Không có chủ đề'}\n'
              'Time: ${originalMailData?['time'] != null ? DateFormat('dd/MM/yyyy, hh:mm a').format(DateTime.parse(originalMailData!['time'])) : ''}',
              style: TextStyle(
                fontSize: 16,
                height: 1.5,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
            const SizedBox(height: 8),
            quill.QuillEditor(
              scrollController: ScrollController(),
              controller: quill.QuillController(
                document: quill.Document.fromJson(
                  jsonDecode(originalMailData?['text'] ?? '[{"insert":""}]'),
                ),
                selection: const TextSelection.collapsed(offset: 0),
              ),
              focusNode: FocusNode(canRequestFocus: false),
              config: const quill.QuillEditorConfig(
                autoFocus: false,
                scrollable: true,
                padding: EdgeInsets.zero,
              ),
            ),
            if (repliesData.isNotEmpty) ...[
              const SizedBox(height: 16),
              const Divider(color: Colors.grey, thickness: 1),
              const SizedBox(height: 8),
              Text(
                'Reply:',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
              ...repliesData.map((reply) {
                return Padding(
                  padding: const EdgeInsets.only(top: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'From: ${reply['from'] ?? 'Không xác định'}',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[800],
                        ),
                      ),
                      Text(
                        'Subject: ${reply['subject'] ?? 'Không có chủ đề'}',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[700],
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                      Text(
                        'Time: ${reply['time'] != null ? DateFormat('dd/MM/yyyy, hh:mm a').format(DateTime.parse(reply['time'])) : ''}',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[700],
                        ),
                      ),
                      const SizedBox(height: 8),
                      quill.QuillEditor(
                        scrollController: ScrollController(),
                        controller: quill.QuillController(
                          document: quill.Document.fromJson(
                            jsonDecode(reply['body'] ?? '[{"insert":""}]'),
                          ),
                          selection: const TextSelection.collapsed(offset: 0),
                        ),
                        focusNode: FocusNode(canRequestFocus: false),
                        config: const quill.QuillEditorConfig(
                          autoFocus: false,
                          scrollable: true,
                          padding: EdgeInsets.zero,
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildFieldRow({
    required String label,
    required List<String> emails,
    required ValueChanged<List<String>> onChanged,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
            label,
            style: const TextStyle(fontSize: 18, color: Colors.black),
          ),
        ),
        Expanded(
          child: CustomChipInput(
            emails: emails,
            onChanged: onChanged,
            fetchSuggestions: _fetchEmailSuggestions,
          ),
        ),
      ],
    );
  }

  Widget _buildDivider() {
    return const Divider(
      color: Colors.grey,
      height: 1,
      thickness: 0.3,
    );
  }
}
