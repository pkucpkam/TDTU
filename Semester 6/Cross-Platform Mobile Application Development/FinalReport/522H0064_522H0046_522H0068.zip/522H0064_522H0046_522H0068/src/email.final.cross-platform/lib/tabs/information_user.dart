// ignore_for_file: use_build_context_synchronously

// Dart imports:
import 'dart:io';

// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';

class InformationUser extends StatefulWidget {
  const InformationUser({super.key});

  @override
  State<InformationUser> createState() => _InformationUser();
}

class _InformationUser extends State<InformationUser> {
  final userUid = FirebaseAuth.instance.currentUser?.uid;
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _dobController = TextEditingController();
  final _phoneController = TextEditingController();
  String? avatarUrl;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _initializeUserData();
  }

  Future<void> _initializeUserData() async {
    setState(() => isLoading = true);
    try {
      await Future.wait([_loadUserAvatarUrl(), _loadUserData()]);
    } catch (e) {
      debugPrint('Error initializing user data: $e');
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _loadUserAvatarUrl() async {
    final user = FirebaseAuth.instance.currentUser;
    const defaultAvatar = 'assets/user.png';
    try {
      if (user != null) {
        final doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(userUid) // Fetch using UID
            .get();
        if (doc.exists) {
          setState(() {
            avatarUrl = doc.data()?['avatarUrl'] ?? defaultAvatar;
          });
        } else {
          debugPrint('Document does not exist.');
          setState(() {
            avatarUrl = defaultAvatar;
          });
        }
      } else {
        setState(() {
          avatarUrl = defaultAvatar;
        });
      }
    } catch (e) {
      debugPrint('Error loading avatar URL: $e');
      setState(() {
        avatarUrl = defaultAvatar;
      });
    }
  }

  Future<void> _loadUserData() async {
    final user = FirebaseAuth.instance.currentUser;
    try {
      if (user != null) {
        final doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(userUid) // Fetch using UID
            .get();
        if (doc.exists) {
          setState(() {
            _fullNameController.text = doc.data()?['fullName'] ?? '';
            _emailController.text = doc.data()?['email'] ?? '';
            _dobController.text = doc.data()?['dob'] ?? '';
            _phoneController.text = doc.data()?['phone'] ?? '';
          });
        } else {
          debugPrint('Document does not exist.');
        }
      }
    } catch (e) {
      debugPrint('Error loading user data: $e');
    }
  }

  Future<void> _saveProfile() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final updatedData = {
        'fullName': _fullNameController.text,
        'email': _emailController.text,
        'dob': _dobController.text,
        'phone': _phoneController.text,
      };
      try {
        final docRef =
            FirebaseFirestore.instance.collection('users').doc(user.uid);
        final doc = await docRef.get();
        if (doc.exists) {
          debugPrint('Updating document with ID: ${docRef.id}');
          await docRef.update(updatedData);
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("Profile updated successfully!")));
        } else {
          debugPrint('Document does not exist. Cannot update.');
        }
      } catch (e) {
        debugPrint('Error saving profile: $e');
      }
    }
  }

  Future<void> _updateAvatar() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      // Upload the new avatar to Firebase Storage and update Firestore
      // For simplicity, this part is omitted
      setState(() {
        avatarUrl = pickedFile.path; // Temporary local path
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(LineAwesomeIcons.arrow_left),
        ),
        title: const Text(
          'Information User',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Stack(
                      children: [
                        SizedBox(
                          width: 120,
                          height: 120,
                          child: CircleAvatar(
                            backgroundImage: avatarUrl != null &&
                                    avatarUrl!.startsWith('http')
                                ? CachedNetworkImageProvider(avatarUrl!)
                                : FileImage(File(avatarUrl!)) as ImageProvider,
                            radius: 20,
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: GestureDetector(
                            onTap: _updateAvatar,
                            child: Container(
                              width: 35,
                              height: 35,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Colors.white,
                              ),
                              child: const Icon(
                                LineAwesomeIcons.camera,
                                color: Colors.blueAccent,
                                size: 20,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),
                    Form(
                      child: Column(
                        children: [
                          TextFormField(
                            controller: _fullNameController,
                            decoration: InputDecoration(
                              label: const Text('Full Name'),
                              prefixIcon: const Icon(LineAwesomeIcons.user),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          TextFormField(
                            controller: _emailController,
                            decoration: InputDecoration(
                              label: const Text('Email'),
                              prefixIcon:
                                  const Icon(LineAwesomeIcons.envelope_1),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          TextFormField(
                            controller: _dobController,
                            readOnly: true,
                            onTap: () async {
                              DateTime? pickedDate = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(1900),
                                lastDate: DateTime.now(),
                              );
                              if (pickedDate != null) {
                                setState(() {
                                  _dobController.text =
                                      "${pickedDate.toLocal()}".split(' ')[0];
                                });
                              }
                            },
                            decoration: InputDecoration(
                              label: const Text('Birthday'),
                              prefixIcon:
                                  const Icon(LineAwesomeIcons.calendar_1),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          TextFormField(
                            controller: _phoneController,
                            decoration: InputDecoration(
                              label: const Text('Phone'),
                              prefixIcon: const Icon(LineAwesomeIcons.phone),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ),
                          const SizedBox(height: 30),
                          ElevatedButton(
                            onPressed: _saveProfile,
                            child: const Text('Save'),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
