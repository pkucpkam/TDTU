// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';

// Project imports:
import '../services/theme_controller.dart';

class SettingsMail extends StatefulWidget {
  const SettingsMail({super.key});

  @override
  SettingsMailState createState() => SettingsMailState();
}

class SettingsMailState extends State<SettingsMail> {
  bool _autoReplyEnabled = false;
  final _autoReplyContentController = TextEditingController();
  bool _isTwoFactorEnabled = false;
  bool _isNotificationEnabled = false;
  bool _isLoading = false;
  String? _errorMessage;

  final ThemeController _themeController = Get.find<ThemeController>();

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    setState(() {
      _isLoading = true;
    });
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        // Load auto reply settings
        final autoReplyDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .collection('settings')
            .doc('autoReply')
            .get();
        if (autoReplyDoc.exists) {
          final data = autoReplyDoc.data()!;
          _autoReplyEnabled = data['isAutoReply'] ?? false;
          _autoReplyContentController.text = data['autoReplyContent'] ?? '';
        }

        // Load two-step verification and notification settings
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();
        if (userDoc.exists) {
          _isTwoFactorEnabled = userDoc.data()!['isTwoFactorEnabled'] ?? false;
          _isNotificationEnabled =
              userDoc.data()!['isNotificationEnabled'] ?? false;
        }
      } catch (e) {
        setState(() {
          _errorMessage = 'Lỗi khi tải cài đặt: $e';
        });
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _saveSettings() async {
    if (!_autoReplyEnabled &&
        _autoReplyContentController.text.isEmpty &&
        _isTwoFactorEnabled ==
            (await FirebaseFirestore.instance
                    .collection('users')
                    .doc(FirebaseAuth.instance.currentUser?.uid)
                    .get())
                .data()?['isTwoFactorEnabled'] &&
        _isNotificationEnabled ==
            (await FirebaseFirestore.instance
                    .collection('users')
                    .doc(FirebaseAuth.instance.currentUser?.uid)
                    .get())
                .data()?['isNotificationEnabled']) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Không có thay đổi để lưu')),
      );
      return;
    }
    if (_autoReplyEnabled && _autoReplyContentController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter auto reply content')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        // Save auto reply settings
        await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .collection('settings')
            .doc('autoReply')
            .set({
          'isAutoReply': _autoReplyEnabled,
          'autoReplyContent': _autoReplyContentController.text,
          'updatedAt': FieldValue.serverTimestamp(),
        });

        // Save two-step verification and notification settings
        await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
          'isTwoFactorEnabled': _isTwoFactorEnabled,
          'isNotificationEnabled': _isNotificationEnabled,
        }, SetOptions(merge: true));

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Save settings successfully')),
          );
        }
      } catch (e) {
        setState(() {
          _errorMessage = 'Lỗi khi lưu cài đặt: $e';
        });
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  @override
  void dispose() {
    _autoReplyContentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDarkMode ? Colors.white : Colors.black;
    final cardColor = isDarkMode ? Colors.grey[800] : Colors.grey[100];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: isDarkMode ? Colors.grey[900] : Colors.white,
        foregroundColor: textColor,
        elevation: 0,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Card(
                      color: cardColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 2,
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Theme',
                              style: TextStyle(
                                color: textColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                            const SizedBox(height: 16),
                            ListTile(
                              leading: Icon(
                                Icons.brightness_6,
                                color: textColor,
                              ),
                              title: Text(
                                'Theme Mode',
                                style: TextStyle(color: textColor),
                              ),
                              subtitle: Text(
                                'Toggle between light and dark mode',
                                style: TextStyle(
                                  color: textColor.withOpacity(0.7),
                                ),
                              ),
                              trailing: IconButton(
                                onPressed: () {
                                  _themeController.toggleTheme();
                                  setState(
                                      () {}); // Update UI to reflect theme change
                                },
                                icon: Icon(
                                  isDarkMode
                                      ? LineAwesomeIcons.sun
                                      : LineAwesomeIcons.moon,
                                  color: Theme.of(context).iconTheme.color,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Card(
                      color: cardColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 2,
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Security',
                              style: TextStyle(
                                color: textColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                            const SizedBox(height: 16),
                            ListTile(
                              leading: Icon(
                                Icons.security,
                                color: textColor,
                              ),
                              title: Text(
                                '2 Factor Authentication',
                                style: TextStyle(color: textColor),
                              ),
                              subtitle: Text(
                                'Enhance your account security with 2FA',
                                style: TextStyle(
                                  color: textColor.withOpacity(0.7),
                                ),
                              ),
                              trailing: Switch(
                                value: _isTwoFactorEnabled,
                                onChanged: (value) {
                                  setState(() {
                                    _isTwoFactorEnabled = value;
                                  });
                                },
                                activeColor: Colors.blue,
                                activeTrackColor: Colors.blue.withOpacity(0.5),
                                inactiveThumbColor: isDarkMode
                                    ? Colors.grey[300]
                                    : Colors.grey[600],
                                inactiveTrackColor: isDarkMode
                                    ? Colors.grey[700]
                                    : Colors.grey[300],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Card(
                      color: cardColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 2,
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Notifications',
                              style: TextStyle(
                                color: textColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                            const SizedBox(height: 16),
                            ListTile(
                              leading: Icon(
                                Icons.notifications,
                                color: textColor,
                              ),
                              title: Text(
                                'Turn on Notifications',
                                style: TextStyle(color: textColor),
                              ),
                              subtitle: Text(
                                'Receive notifications for new emails',
                                style: TextStyle(
                                  color: textColor.withOpacity(0.7),
                                ),
                              ),
                              trailing: Switch(
                                value: _isNotificationEnabled,
                                onChanged: (value) {
                                  setState(() {
                                    _isNotificationEnabled = value;
                                  });
                                },
                                activeColor: Colors.blue,
                                activeTrackColor: Colors.blue.withOpacity(0.5),
                                inactiveThumbColor: isDarkMode
                                    ? Colors.grey[300]
                                    : Colors.grey[600],
                                inactiveTrackColor: isDarkMode
                                    ? Colors.grey[700]
                                    : Colors.grey[300],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Card(
                      color: cardColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 2,
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Auto Reply',
                              style: TextStyle(
                                color: textColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                            const SizedBox(height: 16),
                            ListTile(
                              leading: Icon(
                                Icons.reply,
                                color: textColor,
                              ),
                              title: Text(
                                'Turn on Auto Reply',
                                style: TextStyle(color: textColor),
                              ),
                              subtitle: Text(
                                'Auto reply to new emails',
                                style: TextStyle(
                                  color: textColor.withOpacity(0.7),
                                ),
                              ),
                              trailing: Switch(
                                value: _autoReplyEnabled,
                                onChanged: (value) {
                                  setState(() {
                                    _autoReplyEnabled = value;
                                  });
                                },
                                activeColor: Colors.blue,
                                activeTrackColor: Colors.blue.withOpacity(0.5),
                                inactiveThumbColor: isDarkMode
                                    ? Colors.grey[300]
                                    : Colors.grey[600],
                                inactiveTrackColor: isDarkMode
                                    ? Colors.grey[700]
                                    : Colors.grey[300],
                              ),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'Content to Auto Reply',
                              style: TextStyle(
                                color: textColor,
                                fontWeight: FontWeight.w500,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 8),
                            TextField(
                              controller: _autoReplyContentController,
                              enabled: _autoReplyEnabled,
                              maxLines: 5,
                              decoration: InputDecoration(
                                hintText: 'Enter your auto reply content',
                                hintStyle: TextStyle(
                                    color: textColor.withOpacity(0.7)),
                                border: const OutlineInputBorder(),
                                filled: true,
                                fillColor: isDarkMode
                                    ? Colors.grey[800]
                                    : Colors.grey[100],
                              ),
                              style: TextStyle(color: textColor),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    if (_errorMessage != null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16.0),
                        child: Text(
                          _errorMessage!,
                          style: const TextStyle(
                            color: Colors.red,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    Center(
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _saveSettings,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 32,
                            vertical: 12,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              )
                            : const Text(
                                'Save Settings',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
