// Flutter imports:
import 'package:flutter/material.dart';

class CustomChipInput extends StatefulWidget {
  final List<String> emails;
  final ValueChanged<List<String>> onChanged;
  final Future<List<String>> Function(String) fetchSuggestions;
  final Widget? suffixIcon;

  const CustomChipInput({
    super.key,
    required this.emails,
    required this.onChanged,
    required this.fetchSuggestions,
    this.suffixIcon,
  });

  @override
  _CustomChipInputState createState() => _CustomChipInputState();
}

class _CustomChipInputState extends State<CustomChipInput> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  List<String> _suggestions = [];
  bool _showSuggestions = false;

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(() {
      if (!_focusNode.hasFocus) {
        setState(() {
          _showSuggestions = false;
          _controller.clear();
        });
      }
    });
  }

  void _updateSuggestions(String query) async {
    if (query.isEmpty) {
      setState(() {
        _suggestions = [];
        _showSuggestions = false;
      });
      return;
    }
    final suggestions = await widget.fetchSuggestions(query);
    if (mounted) {
      setState(() {
        _suggestions = suggestions;
        _showSuggestions = suggestions.isNotEmpty;
      });
    }
  }

  void _addEmail(String email) {
    if (!widget.emails.contains(email)) {
      final updatedEmails = List<String>.from(widget.emails)..add(email);
      widget.onChanged(updatedEmails);
    }
    setState(() {
      _controller.clear();
      _showSuggestions = false;
    });
    // Đảm bảo focus được giữ lại sau khi chọn email
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  void _removeEmail(String email) {
    final updatedEmails = List<String>.from(widget.emails)..remove(email);
    widget.onChanged(updatedEmails);
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (widget.emails.isNotEmpty) const SizedBox(height: 8.0),
        // Hiển thị các chip (email đã chọn) trong Wrap
        Wrap(
          spacing: 8.0,
          children: widget.emails.map((email) {
            return Chip(
              label: Text(email),
              deleteIcon: const Icon(Icons.close, size: 18),
              onDeleted: () => _removeEmail(email),
              backgroundColor: Colors.blue.shade100,
              labelStyle: const TextStyle(fontSize: 16),
              padding: const EdgeInsets.symmetric(horizontal: 8),
            );
          }).toList(),
        ),
        // TextField để nhập email mới
        TextField(
          controller: _controller,
          focusNode: _focusNode,
          style: const TextStyle(fontSize: 18),
          decoration: InputDecoration(
            border: InputBorder.none,
            suffixIcon: widget.suffixIcon,
            contentPadding: const EdgeInsets.symmetric(vertical: 20),
          ),
          onChanged: _updateSuggestions,
          onSubmitted: (value) {
            // Nếu người dùng nhấn Enter, thêm email nếu hợp lệ
            if (value.trim().isNotEmpty &&
                !widget.emails.contains(value.trim())) {
              _addEmail(value.trim());
            }
          },
        ),
        // Hiển thị gợi ý bên dưới
        if (_showSuggestions)
          Container(
            constraints: const BoxConstraints(maxHeight: 200),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(4),
            ),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _suggestions.length,
              itemBuilder: (context, index) {
                final suggestion = _suggestions[index];
                return ListTile(
                  title: Text(suggestion),
                  onTap: () {
                    _addEmail(suggestion);
                  },
                );
              },
            ),
          ),
      ],
    );
  }
}
