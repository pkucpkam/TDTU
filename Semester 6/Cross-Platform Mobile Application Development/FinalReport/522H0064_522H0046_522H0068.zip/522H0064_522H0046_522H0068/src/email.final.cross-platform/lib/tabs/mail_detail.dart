// Dart imports:
import 'dart:convert';
import 'dart:io';

// Flutter imports:
import 'package:final_project/tabs/reply_all_page.dart';
import 'package:flutter/material.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;
import 'package:flutter_quill/quill_delta.dart' as quill;
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:open_file/open_file.dart';

// Project imports:
import 'package:final_project/models/reply_mode.dart';
import 'package:final_project/services/email_service.dart';
import 'package:final_project/tabs/forward_mail.dart';
import 'package:final_project/tabs/reply_screen.dart';

// Constants
const String _defaultSenderName = 'Người gửi không xác định';
const String _defaultEmail = 'Không có email';
const String _defaultReceiver = 'Không có người nhận';
const String _defaultSubject = 'Không có chủ đề';
const String _defaultContent = 'Không có nội dung';

class MailDetail extends StatefulWidget {
  final String mailId;

  const MailDetail({
    super.key,
    required this.mailId,
  });

  @override
  MailDetailState createState() => MailDetailState();
}

class MailDetailState extends State<MailDetail> {
  // State variables
  late bool isStarred;
  final String? userName = FirebaseAuth.instance.currentUser?.uid;
  final String? userEmail = FirebaseAuth.instance.currentUser?.email;
  Map<String, dynamic>? mailData;
  List<Map<String, dynamic>> repliesData = [];
  Map<String, dynamic>? forwardedMailData;
  List<Map<String, dynamic>> forwardedRepliesData = [];
  bool isLoading = true;
  String? errorMessage;
  String? summary;
  bool isSummarizing = false;
  bool isTranslating = false;

  @override
  void initState() {
    super.initState();
    _loadMailData();
  }

  // Data loading methods
  Future<void> _loadMailData() async {
    try {
      final doc = await _fetchMailDocument();
      if (!doc.exists) {
        _handleError('Email not found');
        return;
      }

      final mailDataTemp = doc.data() as Map<String, dynamic>;
      final replies = await _fetchReplies(mailDataTemp);
      final forwardedData = await _fetchForwardedMail(mailDataTemp);

      _updateStateWithMailData(mailDataTemp, replies, forwardedData);
    } catch (e) {
      _handleError('Error: $e');
    }
  }

  Future<DocumentSnapshot> _fetchMailDocument() async {
    return await FirebaseFirestore.instance
        .collection('mails')
        .doc(widget.mailId)
        .get();
  }

  Future<List<Map<String, dynamic>>> _fetchReplies(
      Map<String, dynamic> mailData) async {
    final replyIds =
        (mailData['replies'] as List<dynamic>?)?.cast<String>() ?? [];
    List<Map<String, dynamic>> tempRepliesData = [];

    for (var replyId in replyIds) {
      final replyDoc = await FirebaseFirestore.instance
          .collection('repliesEmail')
          .doc(replyId)
          .get();
      if (replyDoc.exists) {
        var replyData = replyDoc.data() as Map<String, dynamic>;
        String? replyAvatarUrl;
        try {
          final replySender = replyData['from'];
          if (replySender != null) {
            final userSnapshot = await FirebaseFirestore.instance
                .collection('users')
                .where('email', isEqualTo: replySender)
                .get();
            replyAvatarUrl = userSnapshot.docs.isNotEmpty
                ? userSnapshot.docs.first.data()['avatarUrl'] ??
                    'assets/user.png'
                : 'assets/user.png';
          } else {
            replyAvatarUrl = 'assets/user.png';
          }
        } catch (e) {
          replyAvatarUrl = 'assets/user.png';
        }
        replyData['avatarUrl'] = replyAvatarUrl;
        tempRepliesData.add(replyData);
      }
    }

    return tempRepliesData;
  }

  Future<Map<String, dynamic>?> _fetchForwardedMail(
      Map<String, dynamic> mailData) async {
    if (mailData['mailForwarded'] == null) return null;

    final forwardedDoc = await FirebaseFirestore.instance
        .collection('mails')
        .doc(mailData['mailForwarded'])
        .get();

    if (!forwardedDoc.exists) return null;

    final forwardedData = forwardedDoc.data() as Map<String, dynamic>;
    final forwardedReplies = await _fetchReplies(forwardedData);

    return {
      'mailData': forwardedData,
      'replies': forwardedReplies,
    };
  }

  void _updateStateWithMailData(
    Map<String, dynamic> mailDataTemp,
    List<Map<String, dynamic>> replies,
    Map<String, dynamic>? forwardedData,
  ) {
    setState(() {
      mailData = mailDataTemp;
      repliesData = replies;
      if (forwardedData != null) {
        forwardedMailData = forwardedData['mailData'];
        forwardedRepliesData = forwardedData['replies'];
      }
      isStarred = mailData!['isStarred'] ?? false;
      isLoading = false;
    });
  }

  void _handleError(String message) {
    setState(() {
      errorMessage = message;
      isLoading = false;
    });
  }

  // Star status methods
  Future<void> _toggleStarStatus() async {
    setState(() {
      isStarred = !isStarred;
    });

    try {
      await _updateStarStatus();
    } catch (e) {
      _handleStarError(e);
    }
  }

  Future<void> _updateStarStatus() async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(userName)
        .collection('receiveMails')
        .doc(widget.mailId)
        .update({'isStarred': isStarred});
  }

  void _handleStarError(dynamic error) {
    setState(() {
      isStarred = !isStarred;
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $error')),
      );
    }
  }

  // Email summarization methods
  Future<void> _summarizeEmail() async {
    if (mailData == null) return;

    setState(() {
      isSummarizing = true;
    });

    try {
      final emailService = Get.find<EmailService>();
      final emailContent = mailData!['text'] ?? '';
      final result = await emailService.getEmailSummary(emailContent);

      _showSummaryDialog(result);
    } catch (e) {
      _handleSummaryError(e);
    } finally {
      setState(() {
        isSummarizing = false;
      });
    }
  }

  Future<void> _toggleTranslate() async {
    if (mailData == null) return;

    setState(() {
      isTranslating = true;
    });

    try {
      final emailService = Get.find<EmailService>();
      final emailContent = mailData!['text'] ?? '';
      final result = await emailService.getEmailTranslate(emailContent);

      _showTranslateDialog(result);
    } catch (e) {
      handleTranslateError(e);
    } finally {
      setState(() {
        isTranslating = false;
      });
    }
  }

  void _showSummaryDialog(String? summary) {
    if (!mounted) return;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Summary Email'),
        content: SingleChildScrollView(
          child: Text(summary ?? 'Can not create summary'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  void _showTranslateDialog(String? summary) {
    if (!mounted) return;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Translate (en to vi)'),
        content: SingleChildScrollView(
          child: Text(summary ?? 'Can not create translation'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  void _handleSummaryError(dynamic error) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Error: $error')),
    );
  }

  void handleTranslateError(dynamic error) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Error: $error')),
    );
  }

  // UI Helper methods
  bool isMailSentMail() {
    return userEmail == mailData?['sender'];
  }

  Widget buildAttachments(List<dynamic>? attachments) {
    if (attachments == null || attachments.isEmpty) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: attachments
            .map((attachment) => buildAttachmentItem(attachment))
            .toList(),
      ),
    );
  }

  Widget buildAttachmentItem(Map<String, dynamic> attachment) {
    final name = attachment['name'] as String? ?? 'File untitled';
    final url = attachment['url'] as String?;
    final isImage = isImageFile(name);

    if (isImage && url != null) {
      return GestureDetector(
        onTap: () => _downloadAttachment(url, name),
        child: buildImageAttachment(url),
      );
    }

    return GestureDetector(
      onTap: () => _downloadAttachment(url, name),
      child: buildFileAttachment(name),
    );
  }

  Future<void> _downloadAttachment(String? url, String? fileName) async {
    if (url == null || fileName == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Can not download: Invalid URL or file name')),
      );
      return;
    }

    try {
      // Kiểm tra quyền lưu trữ
      bool hasPermission = await _requestStoragePermission();
      if (!hasPermission) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Permission denied: Storage access required')),
        );
        return;
      }

      // Hiển thị thông báo đang tải
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Downloading $fileName...')),
      );

      // Lấy thư mục lưu trữ
      final directory = await getApplicationDocumentsDirectory();
      final filePath = '${directory.path}/$fileName';

      // Tải tệp
      final dio = Dio();
      await dio.download(url, filePath);

      // Thông báo tải thành công
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Downloaded: $fileName')),
      );

      // Mở tệp
      final result = await OpenFile.open(filePath);
      if (result.type != ResultType.done) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Cannot open: ${result.message}')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi khi tải tệp: $e')),
      );
    }
  }

  Future<bool> _requestStoragePermission() async {
    if (Platform.isAndroid) {
      var status = await Permission.storage.status;
      if (!status.isGranted) {
        status = await Permission.storage.request();
      }
      return status.isGranted;
    }
    return true; // iOS không yêu cầu quyền lưu trữ riêng
  }

  bool isImageFile(String fileName) {
    final lowerName = fileName.toLowerCase();
    return lowerName.endsWith('.jpg') ||
        lowerName.endsWith('.jpeg') ||
        lowerName.endsWith('.png');
  }

  Widget buildImageAttachment(String url) {
    return SizedBox(
      width: 200,
      height: 200,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.network(
          url,
          width: 200,
          height: 200,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) => const Icon(
            Icons.broken_image,
            size: 50,
            color: Colors.grey,
          ),
          loadingBuilder: (context, child, loadingProgress) {
            if (loadingProgress == null) return child;
            return const Center(child: CircularProgressIndicator());
          },
        ),
      ),
    );
  }

  Widget buildFileAttachment(String name) {
    return Chip(
      avatar: Icon(
        Icons.attach_file,
        size: 18,
        color: Colors.grey[600],
      ),
      label: Text(
        name,
        style: const TextStyle(fontSize: 14),
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  Widget buildQuillContent(dynamic content) {
    try {
      final deltaJson = content is String ? jsonDecode(content) : content;
      final quill.Delta delta = quill.Delta.fromJson(deltaJson);

      final controller = quill.QuillController(
        document: quill.Document.fromDelta(delta),
        selection: const TextSelection.collapsed(offset: 0),
      );

      controller.readOnly = true; // Chế độ chỉ đọc

      return quill.QuillEditor(
        controller: controller,
        scrollController: ScrollController(),
        focusNode: FocusNode(
          skipTraversal: true,
          canRequestFocus: false
        ),
      );
    } catch (e) {
      return Text(
        'Lỗi hiển thị nội dung: $e',
        style: const TextStyle(fontSize: 16, color: Colors.red),
      );
    }
  }

  Widget buildOldAttachment(String? attachment) {
    if (attachment == null || attachment == 'No attachments') {
      return const SizedBox.shrink();
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: GestureDetector(
        onTap: () =>
            _downloadAttachment(attachment, attachment.split('/').last),
        child: Chip(
          avatar: Icon(
            Icons.attach_file,
            size: 18,
            color: Colors.grey[600],
          ),
          label: Text(
            attachment,
            style: const TextStyle(fontSize: 14),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (errorMessage != null) {
      return Scaffold(
        body: Center(child: Text(errorMessage!)),
      );
    }

    final senderName = mailData?['senderName'] ?? _defaultSenderName;
    final senderAvatarUrl = mailData?['senderAvatarUrl'] ?? 'assets/user.png';
    final senderEmail = mailData?['sender'] ?? _defaultEmail;
    final receiver = mailData?['to'] ?? _defaultReceiver;
    final subject = mailData?['subject'] ?? _defaultSubject;
    final text = mailData?['text'] ?? _defaultContent;
    final time = mailData?['time'] != null
        ? DateFormat('hh:mm a').format(DateTime.parse(mailData!['time']))
        : '';
    final fullDateTime = mailData?['time'] != null
        ? DateFormat('dd/MM/yyyy, hh:mm a')
            .format(DateTime.parse(mailData!['time']))
        : '';

    final replies = repliesData.map((reply) {
      return Reply(
        from: reply['from'] ?? _defaultSenderName,
        to: reply['to'] ?? _defaultReceiver,
        subject: reply['subject'] ?? _defaultSubject,
        body: reply['body'] ?? _defaultContent,
        time: reply['time'] != null
            ? DateFormat('hh:mm a').format(DateTime.parse(reply['time']))
            : '',
      );
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mail Detail'),
        actions: [
          IconButton(
            icon: Icon(
              isStarred ? Icons.star : Icons.star_border,
              color: isStarred ? Colors.yellow : null,
            ),
            onPressed: _toggleStarStatus,
          ),
          IconButton(
            icon: const Icon(Icons.translate_outlined),
            onPressed: _toggleTranslate,
          ),
          IconButton(
            icon: const Icon(Icons.summarize_outlined),
            onPressed: isSummarizing ? null : _summarizeEmail,
            tooltip: 'Summarize Email',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              subject,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const Divider(),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundImage: senderAvatarUrl.startsWith('http')
                      ? NetworkImage(senderAvatarUrl)
                      : AssetImage(senderAvatarUrl) as ImageProvider,
                  onBackgroundImageError: (error, stackTrace) =>
                      const AssetImage('assets/user.png'),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            isMailSentMail() ? "me" : senderName,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Text(time),
                        ],
                      ),
                      ExpansionTile(
                        tilePadding: EdgeInsets.zero,
                        title: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(
                              width:
                                  150.0, // Điều chỉnh chiều rộng theo nhu cầu
                              child: Text(
                                isMailSentMail() ? "To $receiver" : "To me",
                                style: TextStyle(
                                  color: Theme.of(context)
                                      .textTheme
                                      .bodyLarge
                                      ?.color,
                                  fontSize: 14.0,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            const SizedBox(width: 4),
                            const Icon(Icons.expand_more,
                                size: 20, color: Colors.grey),
                          ],
                        ),
                        trailing: const SizedBox.shrink(),
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8.0),
                            color: Theme.of(context).colorScheme.surface,
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'From: $senderName • $senderEmail',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color:
                                        Theme.of(context).colorScheme.onSurface,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'To: $receiver',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color:
                                        Theme.of(context).colorScheme.onSurface,
                                  ),
                                ),
                                if (mailData?['cc'] != null &&
                                    mailData!['cc'].toString().isNotEmpty)
                                  Row(
                                    children: [
                                      const SizedBox(height: 8),
                                      Text(
                                        'CC: ',
                                        style: TextStyle(
                                          fontSize: 14,
                                          color: Theme.of(context)
                                              .colorScheme
                                              .onSurface,
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          mailData!['cc'],
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Theme.of(context)
                                                .colorScheme
                                                .onSurface,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                if (mailData?['bcc'] != null &&
                                    mailData!['bcc'].toString().isNotEmpty &&
                                    (isMailSentMail() ||
                                        mailData!['bcc']
                                            .toString()
                                            .contains(userEmail!)))
                                  Container(
                                    padding: const EdgeInsets.only(top: 8),
                                    child: Column(
                                      children: [
                                        Row(
                                          children: [
                                            const SizedBox(height: 8),
                                            Text(
                                              'BCC: ',
                                              style: TextStyle(
                                                fontSize: 14,
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .onSurface,
                                              ),
                                            ),
                                            Expanded(
                                              child: Text(
                                                mailData!['bcc'],
                                                style: TextStyle(
                                                  fontSize: 14,
                                                  color: Theme.of(context)
                                                      .colorScheme
                                                      .onSurface,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                const SizedBox(height: 8),
                                Text(
                                  'Time: $fullDateTime',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color:
                                        Theme.of(context).colorScheme.onSurface,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Icon(
                                      Icons.lock,
                                      size: 16,
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurface
                                          .withOpacity(0.6),
                                    ),
                                    const SizedBox(width: 10),
                                    Text(
                                      'Standard encryption (TLS)',
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Theme.of(context)
                                            .colorScheme
                                            .onSurface
                                            .withOpacity(0.6),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 12),
                    buildQuillContent(text),
                    const SizedBox(height: 12),
                    buildAttachments(mailData?['attachments']),
                    buildOldAttachment(mailData?['attachment']),
                    if (forwardedMailData != null) ...[
                      const SizedBox(height: 16),
                      Card(
                        elevation: 1,
                        color: Colors.grey[50],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(color: Colors.grey.shade200),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Center(
                                child: Text(
                                  '---------- Forward Mails ----------',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey[700],
                                    fontStyle: FontStyle.italic,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'From: ${forwardedMailData?['sender'] ?? 'Không rõ'}\n'
                                'Subject: ${forwardedMailData?['subject'] ?? 'Không có chủ đề'}\n'
                                'Time: ${forwardedMailData?['time'] != null ? DateFormat('dd/MM/yyyy, hh:mm a').format(DateTime.parse(forwardedMailData!['time'])) : ''}\n\n',
                                style: TextStyle(
                                    fontSize: 16,
                                    height: 1.5,
                                    color: Colors.grey[800]),
                              ),
                              buildQuillContent(forwardedMailData?['text']),
                              buildAttachments(
                                  forwardedMailData?['attachments']),
                              buildOldAttachment(
                                  forwardedMailData?['attachment']),
                              if (forwardedRepliesData.isNotEmpty) ...[
                                const SizedBox(height: 16),
                                const Divider(color: Colors.grey, thickness: 1),
                                const SizedBox(height: 8),
                                Text(
                                  'Replies:',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey[800],
                                  ),
                                ),
                                ...forwardedRepliesData.map((reply) {
                                  return Padding(
                                    padding: const EdgeInsets.only(top: 16),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'From: ${reply['from'] ?? 'Không rõ'}',
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.grey[800],
                                          ),
                                        ),
                                        Text(
                                          'Subject: ${reply['subject'] ?? 'Không có chủ đề'}',
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.grey[700],
                                            fontStyle: FontStyle.italic,
                                          ),
                                        ),
                                        Text(
                                          'Time: ${reply['time'] != null ? DateFormat('dd/MM/yyyy, hh:mm a').format(DateTime.parse(reply['time'])) : ''}',
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.grey[700],
                                          ),
                                        ),
                                        const SizedBox(height: 8),
                                        buildQuillContent(reply['body']),
                                        buildAttachments(reply['attachments']),
                                      ],
                                    ),
                                  );
                                }),
                              ],
                            ],
                          ),
                        ),
                      ),
                    ],
                    if (replies.isNotEmpty)
                      ...replies.asMap().entries.map((entry) {
                        final index = entry.key;
                        final reply = entry.value;
                        final replyData = repliesData[index];
                        return Padding(
                          padding: const EdgeInsets.only(top: 16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Divider(color: Colors.grey, thickness: 1.0),
                              const SizedBox(height: 8),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    children: [
                                      replyData['avatarUrl'] != null
                                          ? CircleAvatar(
                                              radius: 20,
                                              backgroundImage: replyData[
                                                          'avatarUrl']
                                                      .startsWith('http')
                                                  ? NetworkImage(
                                                      replyData['avatarUrl'])
                                                  : AssetImage(replyData[
                                                          'avatarUrl'])
                                                      as ImageProvider,
                                              onBackgroundImageError:
                                                  (error, stackTrace) =>
                                                      const AssetImage(
                                                          'assets/user.png'),
                                            )
                                          : const SizedBox(
                                              width: 40,
                                              height: 40,
                                              child: CircularProgressIndicator(
                                                  strokeWidth: 2),
                                            ),
                                    ],
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Reply by: ${reply.from}',
                                          style: const TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          'Subject: ${reply.subject}',
                                          style: const TextStyle(
                                              fontSize: 14,
                                              fontStyle: FontStyle.italic),
                                        ),
                                        const Divider(
                                          color: Color.fromARGB(
                                              255, 189, 188, 188),
                                          thickness: 1,
                                        ),
                                        const SizedBox(height: 12),
                                        buildQuillContent(reply.body),
                                        buildAttachments(
                                            replyData['attachments']),
                                        const SizedBox(height: 12),
                                        Text(
                                          'Time: ${reply.time}',
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Theme.of(context)
                                                .textTheme
                                                .bodyLarge
                                                ?.color,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      }),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ReplyScreen(
                          mailId: widget.mailId,
                          initialTo: mailData?['sender'] ?? '',
                          initialSubject: subject,
                          initialBody: text,
                          userMail: mailData?['sender'] ?? '',
                          userMailRe: receiver,
                        ),
                      ),
                    );
                  },
                  icon: const Icon(
                    Icons.reply,
                    color: Colors.white,
                    size: 18,
                  ),
                  label: const Text(
                    'Reply',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 99, 168, 237),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    elevation: 2,
                    minimumSize: const Size(100, 40),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ReplyAllScreen(
                          mailId: widget.mailId,
                          initialTo: mailData?['sender'] ?? '',
                          initialSubject: subject,
                          initialBody: text,
                          userMail: mailData?['sender'] ?? '',
                          userMailRe: mailData?['receiver'] ?? '',
                          initialCc: mailData?['cc'],
                          initialBcc: mailData?['bcc'],
                        ),
                      ),
                    );
                  },
                  icon: const Icon(
                    Icons.reply_all,
                    color: Colors.white,
                    size: 18,
                  ),
                  label: const Text(
                    'Reply All',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 99, 168, 237),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    elevation: 2,
                    minimumSize: const Size(100, 40),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ForwardMail(
                          mailId: widget.mailId,
                          userEmail: mailData?['sender'] ?? '',
                        ),
                      ),
                    );
                  },
                  icon: const Icon(
                    Icons.forward,
                    color: Colors.white,
                    size: 18,
                  ),
                  label: const Text(
                    'Forward',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 100, 217, 106),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    elevation: 2,
                    minimumSize: const Size(100, 40),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
