// Package imports:
import 'package:flutter_gemini/flutter_gemini.dart';
import 'package:logging/logging.dart';

class GeminiService {
  static final GeminiService _instance = GeminiService._internal();
  factory GeminiService() => _instance;
  GeminiService._internal();

  final _gemini = Gemini.instance;
  final _logger = Logger('GeminiService');

  static const _defaultTemperature = 0.7;
  static const _defaultMaxOutputTokens = 150;
  static const _defaultTopP = 0.8;
  static const _defaultTopK = 40;

  static const _emailSummarizationPrompt = '''
You are an email summarization expert with over 20 years of experience in business communications and natural language processing. I will provide you with the content of an email. Please:

1️⃣ Read the email content carefully.
2️⃣ Identify the main topic, key points, request or action required, and important additional details.
3️⃣ Write a clear, concise summary (4-5 sentences maximum).
4️⃣ Make sure the language used is always polite, neutral, and professional. Absolutely no profanity, offensive, or inappropriate words.
5️⃣ The final output is a plain, easy-to-read paragraph.

Email content:
{emailContent}
''';

  static const _emailCompositionPrompt = '''
You are an expert email writer with extensive experience in professional communication. Please help compose an email with the following details:

Always generate in plain text.

Subject: {subject}
Key Points to Include: {keyPoints}
Tone: {tone}
Additional Context: {context}

Please write a professional, well-structured email that:
1. Has a clear and engaging subject line
2. Includes a proper greeting
3. Clearly communicates the main points
4. Has a professional closing
5. Maintains the specified tone throughout
''';

  static const _quickRepliesPrompt = '''
You are an expert in professional email communication. Based on the following email content, suggest 3-4 quick reply options that are:
1. Professional and appropriate
2. Varying in tone and formality
3. Concise (1-2 sentences each)
4. Action-oriented when needed

Email content:
{emailContent}
''';

  static const _spamDetectionPrompt = '''
You are an expert in email security and spam detection. Analyze the following email content and determine if it shows characteristics of spam or phishing. Consider:
1. Suspicious sender information
2. Urgent or threatening language
3. Requests for personal information
4. Suspicious links or attachments
5. Poor grammar or formatting
6. Unusual requests or offers

Email content:
{emailContent}

Please provide:
1. A spam probability score (0-100)
2. Key reasons for the assessment
3. Recommended action (safe to open, caution required, or likely spam)
''';

  static const _emailTranslationPrompt = '''
You are a professional translator with extensive experience in translating emails from English to Vietnamese. Please translate the following email content into Vietnamese while maintaining the original meaning and tone.

Email content:
{emailContent}
''';

  String? _validateEmailContent(String emailContent) {
    if (emailContent.isEmpty) {
      return 'Email content cannot be empty';
    }
    if (emailContent.length > 10000) {
      return 'Email content is too long (max 10000 characters)';
    }
    return null;
  }

  String _processResponse(dynamic response) {
    if (response == null) {
      return 'Unable to generate summary';
    }

    try {
      final content = response.content;
      if (content != null) {
        final parts = content.parts;
        if (parts != null && parts.isNotEmpty) {
          return parts.map((part) => part.text ?? '').join(' ').trim();
        }
      }
      return 'No content generated';
    } catch (e) {
      _logger.warning('Error processing response: $e');
      return 'Error processing response: $e';
    }
  }

  Future<String> summarizeEmail(String emailContent) async {
    final validationError = _validateEmailContent(emailContent);
    if (validationError != null) {
      _logger.warning('Invalid email content: $validationError');
      return validationError;
    }

    try {
      final prompt =
          _emailSummarizationPrompt.replaceAll('{emailContent}', emailContent);

      final response = await _gemini.text(
        prompt,
        generationConfig: GenerationConfig(
          temperature: _defaultTemperature,
          maxOutputTokens: _defaultMaxOutputTokens,
          topP: _defaultTopP,
          topK: _defaultTopK,
        ),
      );

      _logger.info('Response received from Gemini');
      return _processResponse(response);
    } catch (e) {
      _logger.severe('Error in summarizeEmail: $e');
      return 'Error generating summary: $e';
    }
  }

  Stream<String> streamSummarizeEmail(String emailContent) {
    final validationError = _validateEmailContent(emailContent);
    if (validationError != null) {
      _logger.warning('Invalid email content: $validationError');
      return Stream.value(validationError);
    }

    final prompt =
        _emailSummarizationPrompt.replaceAll('{emailContent}', emailContent);

    return _gemini
        .streamGenerateContent(
          prompt,
          generationConfig: GenerationConfig(
            temperature: _defaultTemperature,
            maxOutputTokens: _defaultMaxOutputTokens,
            topP: _defaultTopP,
            topK: _defaultTopK,
          ),
        )
        .map(_processResponse)
        .handleError((error) {
      _logger.severe('Error in streamSummarizeEmail: $error');
      return 'Error generating summary: $error';
    });
  }

  Future<String> composeEmail({
    required String subject,
    required String keyPoints,
    String tone = 'professional',
    String context = '',
  }) async {
    try {
      final prompt = _emailCompositionPrompt
          .replaceAll('{subject}', subject)
          .replaceAll('{keyPoints}', keyPoints)
          .replaceAll('{tone}', tone)
          .replaceAll('{context}', context);

      final response = await _gemini.text(
        prompt,
        generationConfig: GenerationConfig(
          temperature: _defaultTemperature,
          maxOutputTokens: 500,
          topP: _defaultTopP,
          topK: _defaultTopK,
        ),
      );

      _logger.info('Email composition response received');
      return _processResponse(response);
    } catch (e) {
      _logger.severe('Error in composeEmail: $e');
      return 'Error composing email: $e';
    }
  }

  Future<List<String>> generateQuickReplies(String emailContent) async {
    try {
      final validationError = _validateEmailContent(emailContent);
      if (validationError != null) {
        _logger.warning('Invalid email content: $validationError');
        return ['Error generating quick replies: $validationError'];
      }

      final prompt =
          _quickRepliesPrompt.replaceAll('{emailContent}', emailContent);

      final response = await _gemini.text(
        prompt,
        generationConfig: GenerationConfig(
          temperature: 0.8,
          maxOutputTokens: 300,
          topP: _defaultTopP,
          topK: _defaultTopK,
        ),
      );

      _logger.info('Quick replies response received');
      final processedResponse = _processResponse(response);

      return processedResponse
          .split('\n')
          .where((line) => line.trim().isNotEmpty)
          .map((line) => line.trim())
          .toList();
    } catch (e) {
      _logger.severe('Error in generateQuickReplies: $e');
      return ['Error generating quick replies: $e'];
    }
  }

  Future<String> translateEmail(String emailContent) async {
    final validationError = _validateEmailContent(emailContent);
    if (validationError != null) {
      _logger.warning('Invalid email content: $validationError');
      return validationError;
    }

    final prompt =
        _emailTranslationPrompt.replaceAll('{emailContent}', emailContent);

    try {
      final response = await _gemini.text(
        prompt,
        generationConfig: GenerationConfig(
          temperature: _defaultTemperature,
          maxOutputTokens: _defaultMaxOutputTokens,
          topP: _defaultTopP,
          topK: _defaultTopK,
        ),
      );
      return _processResponse(response);
    } catch (e) {
      _logger.severe('Error in translateEmail: $e');
      return 'Error translating email: $e';
    }
  }

  Future<Map<String, dynamic>> detectSpam(String emailContent) async {
    final validationError = _validateEmailContent(emailContent);
    if (validationError != null) {
      _logger.warning('Invalid email content: $validationError');
      return {
        'spamScore': 0,
        'assessment': validationError,
        'action': 'Invalid input',
        'isSpam': false,
      };
    }

    try {
      final prompt =
          _spamDetectionPrompt.replaceAll('{emailContent}', emailContent);

      final response = await _gemini.text(
        prompt,
        generationConfig: GenerationConfig(
          temperature: 0.3,
          maxOutputTokens: 400,
          topP: _defaultTopP,
          topK: _defaultTopK,
        ),
      );

      _logger.info('Spam detection response received');
      final processedResponse = _processResponse(response);

      final lines = processedResponse.split('\n');
      int spamScore = 0;
      String assessment = '';
      String action = '';

      for (final line in lines) {
        if (line.contains('spam probability score')) {
          final scoreMatch = RegExp(r'\d+').firstMatch(line);
          if (scoreMatch != null) {
            spamScore = int.parse(scoreMatch.group(0)!);
          }
        } else if (line.contains('Recommended action')) {
          action = line.split(':').last.trim();
        } else if (!line.contains('spam probability score') &&
            !line.contains('Recommended action')) {
          assessment += line.trim() + '\n';
        }
      }

      return {
        'spamScore': spamScore,
        'assessment': assessment.trim(),
        'action': action,
        'isSpam': spamScore >= 70,
      };
    } catch (e) {
      _logger.severe('Error in detectSpam: $e');
      return {
        'spamScore': 0,
        'assessment': 'Error analyzing email: $e',
        'action': 'Error occurred',
        'isSpam': false,
      };
    }
  }
}
