// Dart imports:
import 'dart:io' show File;

// Flutter imports:
import 'package:flutter/foundation.dart' show kDebugMode, kIsWeb, Uint8List;
import 'package:flutter/material.dart';

// Package imports:
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';

class UpdateProfileScreen extends StatefulWidget {
  const UpdateProfileScreen({super.key});

  @override
  State<UpdateProfileScreen> createState() => _UpdateProfileScreenState();
}

class _UpdateProfileScreenState extends State<UpdateProfileScreen> {
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _dobController = TextEditingController();
  final _phoneController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String? _avatarUrl;
  bool _isUploading = false;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final docRef =
          FirebaseFirestore.instance.collection('users').doc(user.uid);
      final doc = await docRef.get();

      if (!doc.exists) {
        await docRef.set({
          'fullName': '',
          'email': user.email ?? '',
          'dob': '',
          'phone': '',
          'avatarUrl': '',
        });
      }

      setState(() {
        _fullNameController.text = doc['fullName'] ?? '';
        _emailController.text = user.email ?? '';
        _dobController.text = doc['dob'] ?? '';
        _phoneController.text = doc['phone'] ?? '';
        _avatarUrl = doc['avatarUrl'];
      });
    }
  }

  Future<void> _saveProfile() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final updatedData = {
        'fullName': _fullNameController.text,
        'dob': _dobController.text,
        'phone': _phoneController.text,
        'avatarUrl': _avatarUrl ?? '',
      };
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .update(updatedData);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Profile updated successfully!")));
      Navigator.pop(context);
    }
  }

  Future<void> _pickImage() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.image,
        allowMultiple: false,
      );
      if (result == null || result.files.isEmpty) {
        if (!mounted) return;
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text("No image selected")));
        return;
      }

      final file = result.files.single;
      Uint8List? fileBytes = file.bytes;
      String? filePath = file.path;

      // Kiểm tra định dạng file
      final allowedExtensions = ['png', 'jpg', 'jpeg'];
      final fileExtension = file.extension?.toLowerCase();
      if (fileExtension == null || !allowedExtensions.contains(fileExtension)) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text("Only PNG, JPG, JPEG images are allowed")));
        return;
      }

      // Nếu bytes null và không phải web, thử đọc từ path
      if (fileBytes == null && filePath != null && !kIsWeb) {
        try {
          fileBytes = await File(filePath).readAsBytes();
        } catch (e) {
          if (kDebugMode) {}
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("Failed to read image file")));
          return;
        }
      }

      // Kiểm tra bytes cuối cùng
      if (fileBytes == null) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text("Unable to load image data. Please try again")));
        return;
      }

      // Kiểm tra kích thước file (giới hạn 5MB)
      const maxSizeInBytes = 5 * 1024 * 1024; // 5MB
      if (fileBytes.length > maxSizeInBytes) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Image size exceeds 5MB limit")));
        return;
      }

      setState(() {
        _isUploading = true;
      });

      await _uploadAvatar(fileBytes, file.name);
    } catch (e) {
      if (kDebugMode) {}
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Error picking image: $e")));
    } finally {
      if (mounted) {
        setState(() {
          _isUploading = false;
        });
      }
    }
  }

  Future<void> _uploadAvatar(Uint8List fileBytes, String fileName) async {
    const maxRetries = 3;
    int attempt = 0;

    while (attempt < maxRetries) {
      try {
        final user = FirebaseAuth.instance.currentUser;
        if (user == null) {
          throw Exception("No user signed in");
        }

        // Tạo reference với timestamp để tránh trùng tên
        final timestamp = DateTime.now().millisecondsSinceEpoch;
        final storageRef = FirebaseStorage.instance
            .ref()
            .child('avatars/${user.uid}/${timestamp}_$fileName');

        // Tải lên file
        final uploadTask = await storageRef.putData(fileBytes);
        final downloadUrl = await uploadTask.ref.getDownloadURL();

        // Cập nhật state và Firestore
        setState(() {
          _avatarUrl = downloadUrl;
        });

        await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .update({'avatarUrl': downloadUrl});

        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Avatar updated successfully!")));
        return; // Thoát nếu thành công
      } catch (e) {
        attempt++;
        if (kDebugMode) {}
        if (attempt == maxRetries) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Failed to upload avatar: $e")));
          return;
        }
        await Future.delayed(
            const Duration(seconds: 1)); // Đợi trước khi thử lại
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(LineAwesomeIcons.arrow_left),
        ),
        title: const Text(
          'Edit Profile',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Stack(
                  children: [
                    _isUploading
                        ? const SizedBox(
                            width: 120,
                            height: 120,
                            child: CircularProgressIndicator(),
                          )
                        : CircleAvatar(
                            backgroundImage: (_avatarUrl != null &&
                                    _avatarUrl!.isNotEmpty &&
                                    _avatarUrl!.startsWith('http'))
                                ? CachedNetworkImageProvider(_avatarUrl!)
                                : const AssetImage('assets/user.png')
                                    as ImageProvider,
                            radius: 60,
                          ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: GestureDetector(
                        onTap: _isUploading ? null : _pickImage,
                        child: Container(
                          width: 35,
                          height: 35,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: Colors.white,
                          ),
                          child: const Icon(
                            LineAwesomeIcons.camera,
                            color: Colors.blueAccent,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 50),
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _fullNameController,
                        decoration: InputDecoration(
                          label: const Text('Full Name'),
                          prefixIcon: const Icon(LineAwesomeIcons.user),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      TextFormField(
                        controller: _emailController,
                        enabled: false,
                        decoration: InputDecoration(
                          label: const Text('Email'),
                          prefixIcon: const Icon(LineAwesomeIcons.envelope_1),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      TextFormField(
                        controller: _dobController,
                        readOnly: true,
                        onTap: () async {
                          FocusScope.of(context).requestFocus(FocusNode());
                          DateTime? pickedDate = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(1900),
                            lastDate: DateTime.now(),
                          );
                          if (pickedDate != null) {
                            _dobController.text =
                                "${pickedDate.day.toString().padLeft(2, '0')}/${pickedDate.month.toString().padLeft(2, '0')}/${pickedDate.year}";
                          }
                        },
                        decoration: InputDecoration(
                          label: const Text('Birthday'),
                          prefixIcon: const Icon(LineAwesomeIcons.calendar_1),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      TextFormField(
                        controller: _phoneController,
                        keyboardType: TextInputType.phone,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your phone number';
                          }
                          
                          return null;
                        },
                        decoration: InputDecoration(
                          label: const Text('Phone'),
                          prefixIcon: const Icon(LineAwesomeIcons.phone),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () {
                            if (_formKey.currentState!.validate()) {
                              _saveProfile();
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blueAccent,
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          child: const Text(
                            'Save Profile',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
