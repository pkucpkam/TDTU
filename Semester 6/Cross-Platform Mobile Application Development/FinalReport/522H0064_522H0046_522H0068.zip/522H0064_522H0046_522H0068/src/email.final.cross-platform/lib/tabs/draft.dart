// Dart imports:
import 'dart:convert';
import 'dart:math';

// Flutter imports:
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_quill/flutter_quill.dart';
import 'package:intl/intl.dart';

// Project imports:
import 'package:final_project/components/bottom_nav.dart';
import 'package:final_project/components/data_search.dart';
import 'package:final_project/models/message_mode.dart';
import 'package:final_project/models/user_mode.dart' as user_models;
import 'package:final_project/tabs/compose.dart';
import 'package:final_project/tabs/drawer.dart';
import 'package:final_project/tabs/mails.dart';
import 'package:final_project/tabs/meet.dart';
import 'package:final_project/tabs/profile.dart';

class Draft extends StatefulWidget {
  const Draft({super.key});

  @override
  SentState createState() => SentState();
}

class SentState extends State<Draft> {
  List<Message> mails = [];
  List<String> messageID = [];
  final currentUser = FirebaseAuth.instance.currentUser?.uid;
  bool isShow = true;
  final ScrollController _scrollController = ScrollController();
  final GlobalKey<ScaffoldState> _globalKey = GlobalKey<ScaffoldState>();
  String _avatarUrl = 'assets/user.png';
  String currentUserName = '';
  bool _isLoadingAvatar = true;
  int _currentIndex = 0; // Tab Drafts

  @override
  void initState() {
    super.initState();
    handleScroll();
    loadDraftsFromFirebase();
    _loadUserInfo();
  }

  Future<void> _loadUserInfo() async {
    if (!mounted) return;

    setState(() {
      _isLoadingAvatar = true;
    });

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .get();

        if (mounted) {
          setState(() {
            _avatarUrl = doc.data()?['avatarUrl'] ?? 'assets/user.png';
            currentUserName =
                doc.data()?['fullName'] + " " + doc.data()?['lastName'] ??
                    'Người dùng';
            _isLoadingAvatar = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _avatarUrl = 'assets/user.png';
          _isLoadingAvatar = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Không thể tải thông tin người dùng'),
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  Future<void> loadDraftsFromFirebase() async {
    if (currentUser != null) {
      try {
        setState(() {
          mails.clear();
          messageID.clear();
        });
        final queryDrafts = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('drafts')
            .orderBy('time', descending: true)
            .get();

        for (var doc in queryDrafts.docs) {
          messageID.add(doc.id);
          final data = doc.data();

          final colorValue = data['color'] != null
              ? int.tryParse(data['color'].toString()) ?? getRandomColor().value
              : getRandomColor().value;

          // Chuyển đổi bodyJson thành văn bản thuần túy
          String content = 'No Content';
          if (data['bodyJson'] != null) {
            try {
              final jsonContent = jsonDecode(data['bodyJson']);
              content = Document.fromJson(jsonContent).toPlainText().trim();
              if (content.isEmpty) {
                content = 'No Content';
              }
            } catch (e) {
              debugPrint('Error parsing bodyJson: $e');
              content = 'No Content';
            }
          }

          final loadedMail = Message(
            sender: user_models.AppUser(
              id: mails.length,
              name: data['from'] ?? 'Unknown',
              imageUrl: Color(colorValue),
            ),
            reciever: data['to'] ?? '',
            subject: data['subject'] ?? 'No Subject',
            text: content, // Sử dụng content từ bodyJson
            time: DateFormat('hh:mm a').format(DateTime.parse(data['time'])),
            isStarred: data['isStarred'] ?? false,
          );

          setState(() {
            mails.add(loadedMail);
          });
        }
      } catch (e) {
        debugPrint('Error loading drafts: $e');
      }
    }
  }

  Future<bool> checkIfUserExists(String email) async {
    final userDoc =
        await FirebaseFirestore.instance.collection('users').doc(email).get();
    return userDoc.exists;
  }

  Future<void> navigateToCompose() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const Compose(
          isReply: false,
          isDraft: true,
        ),
      ),
    );

    if (result != null && result is Map<String, String>) {
      final userName = FirebaseAuth.instance.currentUser?.email ?? 'Anonymous';
      final currentTime = DateTime.now();

      final newMessage = Message(
        sender: user_models.AppUser(
          id: mails.length,
          name: userName,
          imageUrl: getRandomColor(),
        ),
        reciever: result['to'] ?? '',
        subject: result['subject'] ?? '',
        text: result['body'] ?? '',
        time: DateFormat('hh:mm a').format(currentTime),
        unread: true,
        isStarred: false,
      );

      setState(() {
        mails.add(newMessage);
      });

      final messageID = FirebaseFirestore.instance.collection('mails').doc().id;
      final senderMail = FirebaseAuth.instance.currentUser?.email ?? '';
      final receiverMail = newMessage.reciever.trim();

      await FirebaseFirestore.instance
          .collection('users')
          .doc(senderMail)
          .collection('mails')
          .doc(messageID)
          .set({
        'messageID': messageID,
        'sender': newMessage.sender.name,
        'receiver': newMessage.reciever,
        'subject': newMessage.subject,
        'text': newMessage.text,
        'time': currentTime.toIso8601String(),
        'isStarred': newMessage.isStarred,
        'unread': newMessage.unread,
        'color': getRandomColor().value,
        'replies': [],
      });

      final userExists = await checkIfUserExists(receiverMail);
      if (userExists) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(receiverMail)
            .collection('mails')
            .doc(messageID)
            .set({
          'messageID': messageID,
          'sender': newMessage.sender.name,
          'receiver': newMessage.reciever,
          'subject': newMessage.subject,
          'text': newMessage.text,
          'time': currentTime.toIso8601String(),
          'isStarred': newMessage.isStarred,
          'unread': newMessage.unread,
          'color': getRandomColor().value,
          'replies': [],
        });
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Mail account does not exist!')),
          );
        }
      }
    }
  }

  Color getRandomColor() {
    final random = Random();
    return Color.fromARGB(
      255,
      random.nextInt(256),
      random.nextInt(256),
      random.nextInt(256),
    );
  }

  void handleScroll() {
    _scrollController.addListener(() {
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        setState(() {
          isShow = false;
        });
      } else if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        setState(() {
          isShow = true;
        });
      }
    });
  }

  Future<void> deleteMailFromFirestore(String? threadID, int index) async {
    if (threadID != null) {
      try {
        // Xóa email khỏi Firestore (lưu ý: sửa collection từ 'mails' thành 'drafts')
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('drafts') // Sửa từ 'mails' thành 'drafts'
            .doc(threadID)
            .delete();

        await FirebaseFirestore.instance
            .collection('drafts')
            .doc(threadID)
            .delete();

        // Cập nhật danh sách giao diện
        setState(() {
          mails.removeAt(index);
          messageID.removeAt(index);
        });
      } catch (e) {
        debugPrint('Error deleting mail: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Failed to delete draft')),
          );
        }
      }
    }
  }

  Future<void> _showDeleteConfirmationDialog(
      BuildContext context, String? threadID, int index) async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Delete Draft'),
          content: const Text('Are you sure you want to delete this draft?'),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop(); // Đóng dialog
              },
            ),
            TextButton(
              child: const Text(
                'Delete',
                style: TextStyle(color: Colors.red),
              ),
              onPressed: () async {
                Navigator.of(context).pop(); // Đóng dialog
                await deleteMailFromFirestore(threadID, index); // Xóa email
              },
            ),
          ],
        );
      },
    );
  }

  void onTabTapped(int index) {
    if (index == _currentIndex) return; // Không làm gì nếu nhấn tab hiện tại
    if (index < 0 || index > 1) {
      return; // Bảo vệ chống chỉ số không hợp lệ
    }

    setState(() {
      _currentIndex = index;
    });

    // Điều hướng đến trang tương ứng
    Widget targetPage;
    switch (index) {
      case 0:
        targetPage = const Mails();
        break;
      case 1:
        targetPage = const Meet();
        break;
      default:
        return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => targetPage),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const Drawers(),
      key: _globalKey,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  Builder(
                    builder: (context) => IconButton(
                      icon: const Icon(Icons.menu, size: 28),
                      onPressed: () => Scaffold.of(context).openDrawer(),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      height: 40,
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 225, 224, 224),
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(24),
                        onTap: () {
                          if (currentUser != null) {
                            showSearch(
                              context: context,
                              delegate: Datasearch(currentUser: currentUser!),
                            );
                          }
                        },
                        child: const Row(
                          children: [
                            SizedBox(width: 12),
                            Icon(Icons.search,
                                color: Color.fromARGB(255, 55, 55, 55)),
                            SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Search in mail',
                                style: TextStyle(
                                    color: Color.fromARGB(255, 55, 55, 55),
                                    fontSize: 16),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  _buildAvatar(),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(left: 18, top: 8, bottom: 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Drafts',
                  style: TextStyle(color: Colors.grey, fontSize: 13),
                ),
              ),
            ),
            Expanded(
                child: mails.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.drafts,
                              size: 120,
                              color: Colors.grey[400],
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'Nothing in Drafts',
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        controller: _scrollController,
                        itemCount: mails.length,
                        itemBuilder: (context, index) {
                          final mail = mails[index];
                          return Card(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Container(
                                color: mail.unread
                                    ? Colors.grey.withAlpha(40)
                                    : Colors.white,
                                child: ListTile(
                                  contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 8),
                                  leading: UserAvatar(
                                    avatarUrl: _avatarUrl,
                                    radius: 20,
                                    assetFallback: 'assets/user.png',
                                  ),
                                  title: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Expanded(
                                        child: Text(
                                          "Draft mail",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                          ),
                                        ),
                                      ),
                                      Text(
                                        mail.time,
                                        style: const TextStyle(
                                          fontSize: 14,
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ],
                                  ),
                                  subtitle: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              mail.subject.isEmpty
                                                  ? '(No Subject)'
                                                  : mail.subject,
                                              style: TextStyle(
                                                fontWeight: mail.unread
                                                    ? FontWeight.bold
                                                    : FontWeight.w500,
                                                fontSize: 14,
                                                color: Theme.of(context)
                                                    .textTheme
                                                    .bodyLarge
                                                    ?.color,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                            const SizedBox(height: 4),
                                            Text(
                                              mail.text.isEmpty
                                                  ? '(No Content)'
                                                  : mail.text,
                                              style: const TextStyle(
                                                fontWeight: FontWeight.normal,
                                                fontSize: 13,
                                                color: Colors.grey,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ],
                                        ),
                                      ),
                                      IconButton(
                                        icon: Icon(
                                          mail.isStarred
                                              ? Icons.star
                                              : Icons.star_border,
                                          color: mail.isStarred
                                              ? Colors.amber
                                              : Colors.grey,
                                          size: 24,
                                        ),
                                        onPressed: () {
                                          setState(() {
                                            mail.isStarred = !mail.isStarred;
                                            // Cập nhật Firestore
                                            FirebaseFirestore.instance
                                                .collection('users')
                                                .doc(currentUser)
                                                .collection('drafts')
                                                .doc(messageID[index])
                                                .update({
                                              'isStarred': mail.isStarred
                                            });
                                          });
                                        },
                                      ),
                                      IconButton(
                                        icon: const Icon(
                                          Icons.delete_outline,
                                          color: Colors.grey,
                                          size: 24,
                                        ),
                                        onPressed: () {
                                          _showDeleteConfirmationDialog(
                                              context, messageID[index], index);
                                        },
                                      ),
                                    ],
                                  ),
                                  onTap: () => Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => Compose(
                                        initialFrom: mail.sender.name,
                                        initialTo: mail.reciever,
                                        initialSubject: mail.subject,
                                        initialBody:
                                            mail.text, // Đây là "No Content"
                                        isReply: false,
                                        isDraft: true,
                                        draftId: messageID[index],
                                      ),
                                    ),
                                  ).then(
                                    (_) => loadDraftsFromFirebase(),
                                  ),
                                ),
                              ));
                        },
                      )),
          ],
        ),
      ),
      floatingActionButton: isShow
          ? FloatingActionButton.extended(
              onPressed: navigateToCompose,
              label: const Text('Compose'),
              icon: const Icon(Icons.edit_outlined),
              foregroundColor: Colors.black,
              backgroundColor: const Color.fromARGB(255, 203, 236, 252),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
            )
          : null,
      bottomNavigationBar: BottomNavigation(
        currentIndex: _currentIndex,
      ),
    );
  }

  Widget _buildAvatar() {
    if (_isLoadingAvatar) {
      return Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.grey.shade300, width: 2),
        ),
        child: const SizedBox(
          width: 40,
          height: 40,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      );
    }

    return GestureDetector(
      onTap: () {
        showDialog(
          context: context,
          builder: (context) => AccountSwitcher(
            mainName: currentUserName,
            mainEmail:
                FirebaseAuth.instance.currentUser?.email ?? 'user@example.com',
            mainAvatarUrl: _avatarUrl,
            otherAccounts: const [],
            onManageAccount: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ProfileScreen(),
                ),
              );
            },
            onAddAccount: () {},
            onManageDevice: () {},
            storagePercent: 0.75,
            storageText: '75% used',
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.grey.shade300, width: 2),
        ),
        child: UserAvatar(avatarUrl: _avatarUrl),
      ),
    );
  }
}
