// ignore: unused_import

// Flutter imports:
import 'package:flutter/material.dart';

class AppUser {
  int id;
  String name;
  Color imageUrl; // Giữ nguyên để tương thích với code cũ
  String? avatarUrl; // Thêm trường mới cho URL ảnh thực sự

  AppUser({
    required this.id,
    required this.name,
    required this.imageUrl,
    this.avatarUrl, // Có thể null nếu không có URL
  });

  factory AppUser.fromFirestore(Map<String, dynamic> data) {
    int colorValue = data['imageUrl'] ?? 4293227496;

    return AppUser(
      id: data['id'] ?? 0,
      name: data['fullName'] ?? 'Unknown',
      imageUrl: Color(colorValue),
      avatarUrl: data['avatarUrl'] ?? 'assets/user.png', // Lấy từ Firestore
    );
  }
}
