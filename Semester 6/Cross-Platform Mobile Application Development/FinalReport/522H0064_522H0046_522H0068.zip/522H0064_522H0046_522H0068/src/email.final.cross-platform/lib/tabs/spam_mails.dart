// ignore_for_file: use_build_context_synchronously

// Dart imports:
import 'dart:convert';
import 'dart:math';

// Flutter imports:
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:logging/logging.dart';

// Project imports:
import 'package:final_project/components/account_switcher.dart';
import 'package:final_project/components/bottom_nav.dart';
import 'package:final_project/components/data_search.dart';
import 'package:final_project/models/message_mode.dart';
import 'package:final_project/models/reply_mode.dart';
import 'package:final_project/models/user_mode.dart' as user_models;
import 'package:final_project/tabs/compose.dart';
import 'package:final_project/tabs/drawer.dart';
import 'package:final_project/tabs/mail_detail.dart';
import 'package:final_project/tabs/profile.dart';

final _logger = Logger('SpamMails');

class SpamMails extends StatefulWidget {
  const SpamMails({super.key});

  @override
  State<SpamMails> createState() => _SpamMailsState();
}

class _SpamMailsState extends State<SpamMails> {
  List<String> selectedMessageIDs = [];
  bool? isStarred = false;
  List<Message> mails = [];
  final currentUser = FirebaseAuth.instance.currentUser?.uid;
  bool isShow = true;
  final ScrollController _scrollController = ScrollController();
  final GlobalKey<ScaffoldState> _globalKey = GlobalKey<ScaffoldState>();
  String _avatarUrl = 'assets/user.png';
  String currentUserName = '';
  bool _isLoadingAvatar = true;
  final int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    handleScroll();
    loadMailsFromFirebase();
    _loadUserInfo();
  }

  Future<void> _loadUserInfo() async {
    if (!mounted) return;

    setState(() {
      _isLoadingAvatar = true;
    });

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .get();

        if (mounted) {
          setState(() {
            _avatarUrl = doc.data()?['avatarUrl'] ?? 'assets/user.png';
            currentUserName =
                doc.data()?['fullName'] + " " + doc.data()?['lastName'] ??
                    'Người dùng';
            _isLoadingAvatar = false;
          });
        }
      }
    } catch (e) {
      _logger.severe('Lỗi khi tải thông tin người dùng: $e');
      if (mounted) {
        setState(() {
          _avatarUrl = 'assets/user.png';
          _isLoadingAvatar = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Không thể tải thông tin người dùng'),
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  Future<void> loadMailsFromFirebase() async {
    if (currentUser != null) {
      try {
        _logger.info('Bắt đầu tải email spam cho người dùng: $currentUser');

        final inboxQuery = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('spamMails')
            .orderBy('time', descending: true)
            .get();

        setState(() {
          mails.clear();
        });

        for (var doc in inboxQuery.docs) {
          final data = doc.data();
          if (data['text'] == null || data['text'] == '') {
            _logger.warning(
                'Cảnh báo: Trường "text" trống hoặc null cho ID email: ${doc.id}');
          }

          // Xử lý giá trị màu
          Color senderColor;
          final colorValue = data['color']?.toString();
          if (colorValue != null && colorValue.startsWith('0x')) {
            try {
              senderColor = Color(int.parse(colorValue));
            } catch (e) {
              _logger.warning('Lỗi parse màu $colorValue: $e');
              senderColor = Colors.blueGrey; // Màu mặc định
            }
          } else if (colorValue != null && _isNamedColor(colorValue)) {
            senderColor =
                _getColorFromName(colorValue); // Chuyển tên màu thành Color
          } else {
            _logger.warning('Giá trị màu không hợp lệ: $colorValue');
            senderColor = Colors.blueGrey; // Màu mặc định
          }

          List<Reply> replyList = [];
          if (data['replies'] != null) {
            for (var reply in data['replies']) {
              replyList.add(
                Reply(
                  body: reply['body'] ?? 'Không có nội dung',
                  from: reply['from'] ?? 'Người gửi không xác định',
                  subject: reply['subject'] ?? 'Không có chủ đề',
                  time: reply['time'] ?? '',
                  to: reply['to'] ?? 'Người nhận không xác định',
                ),
              );
            }
          }

          final loadedMail = Message(
            sender: user_models.AppUser(
              id: mails.length,
              name: data['senderName'] ?? data['sender'] ?? 'Không xác định',
              imageUrl: senderColor,
              avatarUrl: data['senderAvatarUrl'] ?? 'assets/user.png',
            ),
            reciever: data['receiver'] ?? 'Không có người nhận',
            subject: data['subject'] ?? 'Không có chủ đề',
            text:
                parseQuillJsonToPlainText(data['text'] ?? 'Không có nội dung'),
            time: DateFormat('hh:mm a').format(DateTime.parse(data['time'])),
            unread: data['unread'] ?? true,
            isStarred: data['isStarred'] ?? false,
            replies: replyList,
            threadID: doc.id,
            isSelected: false,
          );

          setState(() {
            mails.add(loadedMail);
          });
        }
        _logger.info('Đã tải thành công ${mails.length} email spam');
      } catch (e) {
        _logger.severe('Lỗi khi tải email: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Lỗi khi tải email: $e')),
          );
        }
      }
    }
  }

  bool _isNamedColor(String colorName) {
    final namedColors = {
      'blue': Colors.blue,
      'red': Colors.red,
      'green': Colors.green,
      'yellow': Colors.yellow,
      'black': Colors.black,
      'white': Colors.white,
      'grey': Colors.grey,
      'purple': Colors.purple,
      'orange': Colors.orange,
    };
    return namedColors.containsKey(colorName.toLowerCase());
  }

  Color _getColorFromName(String colorName) {
    final namedColors = {
      'blue': Colors.blue,
      'red': Colors.red,
      'green': Colors.green,
      'yellow': Colors.yellow,
      'black': Colors.black,
      'white': Colors.white,
      'grey': Colors.grey,
      'purple': Colors.purple,
      'orange': Colors.orange,
    };
    return namedColors[colorName.toLowerCase()] ?? Colors.blueGrey;
  }

  String parseQuillJsonToPlainText(String quillJson) {
    try {
      if (quillJson.isEmpty || !quillJson.startsWith('[')) {
        return quillJson;
      }
      final List<dynamic> quillData = jsonDecode(quillJson);
      String plainText = quillData
          .where((element) => element['insert'] != null)
          .map((element) => element['insert'].toString())
          .join();
      return plainText.trim();
    } catch (e) {
      _logger.warning('Lỗi parse Quill JSON: $e');
      return quillJson;
    }
  }

  Future<void> navigateToCompose() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => const Compose(
                isReply: false,
                isDraft: false,
              )),
    );

    if (result != null && result is Map<String, String>) {
      final user = FirebaseAuth.instance.currentUser;
      final userName = user?.displayName ?? user?.email ?? 'Người dùng';
      final currentTime = DateTime.now();
      final senderUID = user?.uid ?? '';

      _logger.info('Soạn email mới với senderName: $userName');

      final newMessage = Message(
        sender: user_models.AppUser(
          id: mails.length,
          name: userName,
          imageUrl: getRandomColor(),
        ),
        reciever: result['to'] ?? '',
        subject: result['subject'] ?? '',
        text: result['body'] ?? '',
        time: DateFormat('hh:mm a').format(currentTime),
        unread: true,
        isStarred: false,
      );

      final messageID = FirebaseFirestore.instance.collection('mails').doc().id;

      final receiverEmail = newMessage.reciever.trim();
      String? receiverUID;
      try {
        final querySnapshot = await FirebaseFirestore.instance
            .collection('users')
            .where('email', isEqualTo: receiverEmail)
            .get();

        if (querySnapshot.docs.isNotEmpty) {
          receiverUID = querySnapshot.docs.first.id;
        } else {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Tài khoản email không tồn tại!')),
            );
          }
          return;
        }
      } catch (e) {
        _logger.severe('Lỗi khi kiểm tra sự tồn tại của người nhận: $e');
        return;
      }

      try {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(senderUID)
            .collection('sentMails')
            .doc(messageID)
            .set({
          'messageID': messageID,
          'sender': senderUID,
          'senderName': userName,
          'receiver': newMessage.reciever,
          'subject': newMessage.subject,
          'text': newMessage.text,
          'time': currentTime.toIso8601String(),
          'isStarred': newMessage.isStarred,
          'unread': newMessage.unread,
          'isSpam': false,
          'color': getRandomColor().value.toString(),
          'replies': [],
          'labels': []
        });

        await FirebaseFirestore.instance
            .collection('users')
            .doc(receiverUID)
            .collection('receiveMails')
            .doc(messageID)
            .set({
          'messageID': messageID,
          'sender': senderUID,
          'senderName': userName,
          'receiver': newMessage.reciever,
          'subject': newMessage.subject,
          'text': newMessage.text,
          'time': currentTime.toIso8601String(),
          'isStarred': newMessage.isStarred,
          'unread': newMessage.unread,
          'isSpam': false,
          'color': getRandomColor().value.toString(),
          'replies': [],
          'labels': []
        });
        _logger.info('Đã lưu email mới với messageID: $messageID');
      } catch (e) {
        _logger.severe('Lỗi khi lưu email: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Không thể lưu email: $e')),
          );
        }
      }
    }
  }

  Color getRandomColor() {
    final random = Random();
    return Color.fromARGB(
      255,
      random.nextInt(256),
      random.nextInt(256),
      random.nextInt(256),
    );
  }

  void handleScroll() {
    _scrollController.addListener(() {
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        setState(() {
          isShow = false;
        });
      } else if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        setState(() {
          isShow = true;
        });
      }
    });
  }

  Future<void> deleteMailFromFirestore(String? threadID) async {
    if (threadID != null) {
      final index = mails.indexWhere((mail) => mail.threadID == threadID);
      if (index == -1) return;

      final mailToDelete = mails[index];

      setState(() {
        mails.removeAt(index);
      });

      try {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('receiveMails')
            .doc(threadID)
            .delete()
            .catchError(
                (e) => _logger.info('Email không có trong receiveMails: $e'));

        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('sentMails')
            .doc(threadID)
            .delete()
            .catchError(
                (e) => _logger.info('Email không có trong sentMails: $e'));
      } catch (e) {
        setState(() {
          mails.insert(index, mailToDelete);
        });
        _logger.severe('Lỗi khi xóa email: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Không thể xóa email: $e')),
          );
        }
      }
    }
  }

  Future<void> toggleisStarred(Message mail, int index) async {
    final threadID = mail.threadID;
    if (threadID == null) return;

    final originalState = mail.isStarred;

    setState(() {
      mail.isStarred = !originalState;
    });

    try {
      final mailType = await _getMailType(threadID);

      if (mailType == null) {
        _logger
            .warning('Không xác định được loại mail cho threadID: $threadID');
        return;
      }

      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection(mailType)
          .doc(threadID)
          .update({'isStarred': mail.isStarred});

      _logger.info('Đã cập nhật isStarred cho mail $threadID trong $mailType');
    } catch (e) {
      setState(() {
        mail.isStarred = originalState;
      });

      _logger.severe('Lỗi khi cập nhật trạng thái sao: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Không thể cập nhật trạng thái sao: $e'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.red,
            action: SnackBarAction(
              label: 'Thử lại',
              textColor: Colors.white,
              onPressed: () => toggleisStarred(mail, index),
            ),
          ),
        );
      }
    }
  }

  Future<void> toggleReadStatus(String threadID, bool currentStatus) async {
    final index = mails.indexWhere((mail) => mail.threadID == threadID);
    if (index == -1) return;

    final originalStatus = mails[index].unread;

    setState(() {
      mails[index].unread = !currentStatus;
    });

    try {
      final mailType = await _getMailType(threadID);

      if (mailType == null) {
        _logger
            .warning('Không xác định được loại mail cho threadID: $threadID');
        return;
      }

      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection(mailType)
          .doc(threadID)
          .update({'unread': !currentStatus});

      _logger.info(
          'Đã cập nhật trạng thái đọc của email $threadID trong $mailType');
    } catch (e) {
      setState(() {
        mails[index].unread = originalStatus;
      });

      _logger.severe('Lỗi khi cập nhật trạng thái đọc: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Không thể cập nhật trạng thái đọc: $e'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.red,
            action: SnackBarAction(
              label: 'Thử lại',
              textColor: Colors.white,
              onPressed: () => toggleReadStatus(threadID, currentStatus),
            ),
          ),
        );
      }
    }
  }

  Future<String?> _getMailType(String? threadID) async {
    if (threadID == null) return null;

    final userDocRef =
        FirebaseFirestore.instance.collection('users').doc(currentUser);

    final mailTypes = ['receiveMails', 'sentMails', 'drafts'];

    for (String type in mailTypes) {
      final mailDoc = await userDocRef.collection(type).doc(threadID).get();
      if (mailDoc.exists) {
        return type;
      }
    }
    return null;
  }

  Future<void> moveMailToTrash(String? threadID) async {
    if (threadID == null) return;

    final index = mails.indexWhere((mail) => mail.threadID == threadID);
    if (index == -1) return;

    final mailToMove = mails[index];

    setState(() {
      mails.removeAt(index);
    });

    try {
      final mailType = await _getMailType(threadID);

      if (mailType == null) {
        _logger
            .warning('Không xác định được loại mail cho threadID: $threadID');
        return;
      }

      final docRef = FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection(mailType)
          .doc(threadID);

      final mailDoc = await docRef.get();

      if (!mailDoc.exists) {
        _logger.warning('Email không tồn tại trong $mailType');
        return;
      }

      Map<String, dynamic> mailData = mailDoc.data()!;
      final filteredMailData = {
        'color': mailData['color'],
        'receiver': mailData['receiver'],
        'sender': mailData['sender'],
        'subject': mailData['subject'],
        'text': mailData['text'],
        'time': mailData['time'],
        'type': mailType,
      };

      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('trashMails')
          .doc(threadID)
          .set(filteredMailData);

      await docRef.update({'isTrash': true});

      _logger.info('Đã chuyển email $threadID từ $mailType sang thùng rác');
    } catch (e) {
      setState(() {
        mails.insert(index, mailToMove);
      });

      _logger.severe('Lỗi khi chuyển email sang thùng rác: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Không thể chuyển email sang thùng rác: $e'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> choseLabel(BuildContext context, String? threadID) async {
    if (!mounted) return;

    List<String> allLabels = [];
    List<String> selectedLabels = [];

    try {
      var snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .get();
      if (snapshot.exists) {
        allLabels = List<String>.from(snapshot.data()?['labels'] ?? []);
      }

      var mailDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('receiveMails')
          .doc(threadID)
          .get();

      if (!mailDoc.exists) {
        mailDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('sentMails')
            .doc(threadID)
            .get();
      }

      if (mailDoc.exists) {
        List<dynamic> labelsFromFirestore = mailDoc['labels'] ?? [];
        selectedLabels = List<String>.from(labelsFromFirestore);
      }
    } catch (e) {
      _logger.severe('Lỗi khi tải nhãn: $e');
      return;
    }

    if (!mounted) return;

    final BuildContext currentContext = context;
    showDialog(
      context: currentContext,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return AlertDialog(
              title: const Text(
                'Choose Labels',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              content: SingleChildScrollView(
                child: ListBody(
                  children: allLabels.map((label) {
                    return CheckboxListTile(
                      activeColor: Colors.blueAccent,
                      title: Text(label),
                      value: selectedLabels.contains(label),
                      onChanged: (bool? selected) {
                        setState(() {
                          if (selected == true) {
                            selectedLabels.add(label);
                          } else {
                            selectedLabels.remove(label);
                          }
                        });
                      },
                    );
                  }).toList(),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(ctx).pop();
                  },
                  child: const Text('Cancel',
                      style: TextStyle(color: Colors.black)),
                ),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  onPressed: () async {
                    try {
                      await FirebaseFirestore.instance
                          .collection('users')
                          .doc(currentUser)
                          .collection('receiveMails')
                          .doc(threadID)
                          .update({'labels': selectedLabels}).catchError((e) =>
                              _logger.info(
                                  'Email không có trong receiveMails: $e'));

                      await FirebaseFirestore.instance
                          .collection('users')
                          .doc(currentUser)
                          .collection('sentMails')
                          .doc(threadID)
                          .update({'labels': selectedLabels}).catchError((e) =>
                              _logger
                                  .info('Email không có trong sentMails: $e'));

                      await FirebaseFirestore.instance
                          .collection('users')
                          .doc(currentUser)
                          .collection('drafts')
                          .doc(threadID)
                          .update({'labels': selectedLabels}).catchError((e) =>
                              _logger.info('Email không có trong drafts: $e'));

                      if (!mounted) return;
                      Navigator.of(ctx).pop();
                    } catch (e) {
                      _logger.severe('Lỗi khi lưu nhãn: $e');
                      if (!mounted) return;
                      ScaffoldMessenger.of(currentContext).showSnackBar(
                        SnackBar(content: Text('Không thể lưu nhãn: $e')),
                      );
                    }
                  },
                  label: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> markAsNotSpam(String? threadID) async {
    if (threadID == null) return;

    final index = mails.indexWhere((mail) => mail.threadID == threadID);
    if (index == -1) return;

    final mailToUpdate = mails[index];

    setState(() {
      mails.removeAt(index);
    });

    try {
      final userDocRef =
          FirebaseFirestore.instance.collection('users').doc(currentUser);
      final spamMailDocRef = userDocRef.collection('spamMails').doc(threadID);

      // Lấy dữ liệu email từ spamMails
      final spamMailDoc = await spamMailDocRef.get();
      if (!spamMailDoc.exists) {
        _logger.warning(
            'Không tìm thấy email trong spamMails cho threadID: $threadID');
        return;
      }

      final mailData = spamMailDoc.data();
      if (mailData == null) {
        _logger.warning('Dữ liệu email rỗng cho threadID: $threadID');
        return;
      }

      // Sao chép sang receiveMails
      await userDocRef.collection('receiveMails').doc(threadID).set({
        ...mailData,
        'isSpam': false, // Đảm bảo trường isSpam được đặt thành false
      });

      // Xóa khỏi spamMails
      await spamMailDocRef.delete();

      _logger.info('Đã chuyển email $threadID từ spamMails sang receiveMails');
    } catch (e) {
      // Hoàn tác thay đổi giao diện nếu có lỗi
      setState(() {
        mails.insert(index, mailToUpdate);
      });

      _logger.severe('Lỗi khi chuyển email sang receiveMails: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Không thể chuyển email sang hộp thư đến: $e'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _showEmailAction(BuildContext parentContext, Message mail, int index) {
    showModalBottomSheet(
      context: parentContext,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (BuildContext bottomSheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(
                  mail.unread ? Icons.mark_email_read : Icons.mark_email_unread,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
                title: Text(mail.unread ? 'Mark as read' : 'Mark as unread'),
                onTap: () async {
                  await toggleReadStatus(mail.threadID!, mail.unread);
                  Navigator.pop(bottomSheetContext);
                },
              ),
              ListTile(
                leading: Icon(
                  mail.isStarred ? Icons.star : Icons.star_border,
                  color: mail.isStarred
                      ? Colors.yellow
                      : Theme.of(context).colorScheme.onSurface,
                ),
                title:
                    Text(mail.isStarred ? 'Mark as unstar' : 'Mark as starred'),
                onTap: () async {
                  await toggleisStarred(mail, index);
                  Navigator.pop(bottomSheetContext);
                },
              ),
              ListTile(
                leading: Icon(Icons.label_outline,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Label email'),
                onTap: () async {
                  Navigator.pop(bottomSheetContext);
                  await choseLabel(parentContext, mail.threadID);
                },
              ),
              ListTile(
                leading: Icon(Icons.move_to_inbox,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Mark as not spam'),
                onTap: () async {
                  await markAsNotSpam(mail.threadID);
                  Navigator.pop(bottomSheetContext);
                },
              ),
              ListTile(
                leading: Icon(Icons.delete_outline,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Move to Trash'),
                onTap: () async {
                  await moveMailToTrash(mail.threadID);
                  Navigator.pop(bottomSheetContext);
                },
              ),
              ListTile(
                leading: Icon(Icons.close,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Cancel'),
                onTap: () {
                  Navigator.pop(bottomSheetContext);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const Drawers(),
      key: _globalKey,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  Builder(
                    builder: (context) => IconButton(
                      icon: const Icon(Icons.menu, size: 28),
                      onPressed: () => Scaffold.of(context).openDrawer(),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      height: 40,
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 225, 224, 224),
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(24),
                        onTap: () {
                          if (currentUser != null) {
                            showSearch(
                              context: context,
                              delegate: Datasearch(currentUser: currentUser!),
                            );
                          }
                        },
                        child: const Row(
                          children: [
                            SizedBox(width: 12),
                            Icon(Icons.search,
                                color: Color.fromARGB(255, 55, 55, 55)),
                            SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Search in mail',
                                style: TextStyle(
                                    color: Color.fromARGB(255, 55, 55, 55),
                                    fontSize: 16),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  _buildAvatar(),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(left: 18, top: 8, bottom: 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Spam Emails',
                  style: TextStyle(color: Colors.grey, fontSize: 13),
                ),
              ),
            ),
            Expanded(
              child: mails.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.warning_amber_outlined,
                            size: 120,
                            color: Colors.grey[400],
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'No spam emails found',
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      controller: _scrollController,
                      itemCount: mails.length,
                      itemBuilder: (context, index) {
                        final mail = mails[index];
                        return Container(
                          color: mail.unread
                              ? Colors.grey.withAlpha(20)
                              : Colors.transparent,
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor:
                                  Colors.grey[300], // Màu nền mặc định
                              backgroundImage: mail.sender.avatarUrl != null &&
                                      mail.sender.avatarUrl!.isNotEmpty &&
                                      mail.sender.avatarUrl != 'assets/user.png'
                                  ? NetworkImage(mail.sender
                                      .avatarUrl!) // Sử dụng avatarUrl từ sender
                                  : const AssetImage('assets/user.png')
                                      as ImageProvider, // Hình mặc định
                              onBackgroundImageError: (error, stackTrace) =>
                                  const AssetImage(
                                      'assets/user.png'), // Xử lý lỗi tải hình
                              child: mail.sender.avatarUrl == null ||
                                      mail.sender.avatarUrl!.isEmpty ||
                                      mail.sender.avatarUrl == 'assets/user.png'
                                  ? Text(
                                      mail.sender.name.isNotEmpty
                                          ? mail.sender.name[0].toUpperCase()
                                          : '?',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: mail.unread
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                      ),
                                    )
                                  : null,
                            ),
                            title: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(
                                    mail.sender.name,
                                    style: TextStyle(
                                      fontWeight: mail.unread
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                    ),
                                  ),
                                ),
                                Text(
                                  mail.time,
                                  style: const TextStyle(
                                      fontSize: 12, color: Colors.grey),
                                ),
                              ],
                            ),
                            subtitle: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        mail.subject,
                                        style: TextStyle(
                                          fontWeight: mail.unread
                                              ? FontWeight.bold
                                              : FontWeight.normal,
                                          color: Theme.of(context)
                                              .textTheme
                                              .bodyLarge
                                              ?.color, // Sử dụng màu từ theme
                                        ),
                                      ),
                                      Text(
                                        parseQuillJsonToPlainText(mail.text),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  icon: Icon(
                                    mail.isStarred
                                        ? Icons.star
                                        : Icons.star_border,
                                    color: mail.isStarred
                                        ? Colors.yellow
                                        : Colors.grey,
                                  ),
                                  onPressed: () {
                                    toggleisStarred(mail, index);
                                  },
                                ),
                              ],
                            ),
                            onTap: () async {
                              if (!mounted) return;
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => MailDetail(
                                    mailId: mail.threadID!,
                                  ),
                                ),
                              );
                            },
                            onLongPress: () {
                              _showEmailAction(context, mail, index);
                            },
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      floatingActionButton: isShow
          ? FloatingActionButton.extended(
              onPressed: navigateToCompose,
              label: const Text('Compose'),
              icon: const Icon(Icons.edit_outlined),
              foregroundColor: Colors.black,
              backgroundColor: const Color.fromARGB(255, 203, 236, 252),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24)),
            )
          : null,
      bottomNavigationBar: BottomNavigation(
        currentIndex: _currentIndex,
      ),
    );
  }

  Widget _buildAvatar() {
    if (_isLoadingAvatar) {
      return Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.grey.shade300, width: 2),
        ),
        child: const SizedBox(
          width: 40,
          height: 40,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      );
    }

    return GestureDetector(
      onTap: () {
        showDialog(
          context: context,
          builder: (context) => AccountSwitcher(
            mainName: currentUserName,
            mainEmail:
                FirebaseAuth.instance.currentUser?.email ?? 'user@example.com',
            mainAvatarUrl: _avatarUrl,
            otherAccounts: const [],
            onManageAccount: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ProfileScreen(),
                ),
              );
            },
            onAddAccount: () {},
            onManageDevice: () {},
            storagePercent: 0.75,
            storageText: 'Used 75%',
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.grey.shade300, width: 2),
        ),
        child: UserAvatar(avatarUrl: _avatarUrl),
      ),
    );
  }
}
