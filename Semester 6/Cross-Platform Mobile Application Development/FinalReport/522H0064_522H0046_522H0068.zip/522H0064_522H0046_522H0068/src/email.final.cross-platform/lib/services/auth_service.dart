// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

// import 'package:google_sign_in/google_sign_in.dart';
// import 'dart:io' show Platform;

class AuthService {
  signInWithGoogle() async {
    final GoogleSignInAccount? gUser = await GoogleSignIn().signIn();

    final GoogleSignInAuthentication gAuth = await gUser!.authentication;

    final credential = GoogleAuthProvider.credential(
      accessToken: gAuth.accessToken,
      idToken: gAuth.idToken,
    );

    return await FirebaseAuth.instance.signInWithCredential(credential);
  }

  Future<void> enableTwoStepVerification(bool enable) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        throw Exception('Không có người dùng đăng nhập');
      }
      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'twoStepEnabled': enable,
      }, SetOptions(merge: true));
    } catch (e) {
      throw Exception('Lỗi cập nhật xác minh hai bước: $e');
    }
  }
  // final GoogleSignIn _googleSignIn = GoogleSignIn(
  //   scopes: [
  //     'email',
  //     'profile',
  //   ],
  // );

  // Future<UserCredential?> signInWithGoogle() async {
  //   try {
  //     // Trigger the authentication flow
  //     final GoogleSignInAccount? gUser = await _googleSignIn.signIn();

  //     // If user cancels the sign-in flow
  //     if (gUser == null) {
  //       return null;
  //     }

  //     // Obtain the auth details from the request
  //     final GoogleSignInAuthentication gAuth = await gUser.authentication;

  //     // Create a new credential
  //     final credential = GoogleAuthProvider.credential(
  //       accessToken: gAuth.accessToken,
  //       idToken: gAuth.idToken,
  //     );

  //     // Sign in to Firebase with the Google credential
  //     final userCredential = await FirebaseAuth.instance.signInWithCredential(credential);

  //     // For iOS, we need to ensure the user is signed in
  //     if (Platform.isIOS) {
  //       await _googleSignIn.signInSilently();
  //     }

  //     return userCredential;
  //   } catch (e) {
  //     print('Error during Google sign in: $e');
  //     // If there's an error, try to sign out to clear any partial state
  //     await _googleSignIn.signOut();
  //     rethrow;
  //   }
  // }

  Future<void> signOut() async {
    // await _googleSignIn.signOut();
    await FirebaseAuth.instance.signOut();
  }
}
