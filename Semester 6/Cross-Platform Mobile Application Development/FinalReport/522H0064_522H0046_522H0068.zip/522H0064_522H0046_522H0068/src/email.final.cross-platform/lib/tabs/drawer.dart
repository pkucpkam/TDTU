// ignore_for_file: use_build_context_synchronously

// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Project imports:
import 'package:final_project/models/message_mode.dart';
import 'package:final_project/models/user_mode.dart' as my_models;
import 'package:final_project/pages/setting_mail.dart';
import 'package:final_project/tabs/draft.dart';
import 'package:final_project/tabs/front_page.dart';
import 'package:final_project/tabs/label_emails.dart';
import 'package:final_project/tabs/sent_mails.dart';
import 'package:final_project/tabs/spam_mails.dart';
import 'package:final_project/tabs/starred_page.dart';
import 'package:final_project/tabs/trash.dart';
import 'package:final_project/tabs/unread_mails.dart';

class Drawers extends StatefulWidget {
  const Drawers({super.key});
  @override
  DrawersState createState() => DrawersState();
}

class DrawersState extends State<Drawers> {
  bool isExpanded = false;
  final _newLabelNameController = TextEditingController();
  final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
  List<String> _labels = [];
  List<Message>? _cachedStarredMails;
  DateTime? _lastFetchTime;
  final _cacheDuration = const Duration(minutes: 5);
  String currentUser = FirebaseAuth.instance.currentUser?.uid ?? '';

  @override
  void initState() {
    super.initState();
    _loadCachedData();
    _fetchLabels();
  }

  Future<void> _loadCachedData() async {
    final prefs = await SharedPreferences.getInstance();
    _lastFetchTime =
        DateTime.tryParse(prefs.getString('last_fetch_time') ?? '');
  }

  Future<String?> getUserName() async {
    final userMail = FirebaseAuth.instance.currentUser?.uid;
    if (userMail == null) return null;
    try {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(userMail)
          .get();
      final data = doc.data() ?? {};
      final name = data['fullName'] ?? '';
      return name;
    } catch (e, stack) {
      debugPrint('Error fetching user name: $e\n$stack');
      return null;
    }
  }

  Future<List<Message>> fetchStarredMails(String? userMail) async {
    if (_cachedStarredMails != null &&
        _lastFetchTime != null &&
        DateTime.now().difference(_lastFetchTime!) < _cacheDuration) {
      return _cachedStarredMails!;
    }

    List<Message> starredMails = [];
    try {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(userMail)
          .collection('mails')
          .where('isStarred', isEqualTo: true)
          .get();

      for (var doc in querySnapshot.docs) {
        final data = doc.data();
        starredMails.add(
          Message(
            threadID: doc.id,
            sender: my_models.AppUser(
              id: starredMails.length,
              name: data['sender'] ?? 'Unknown',
              imageUrl: data['color'] != null
                  ? Color(int.tryParse(data['color'].toString()) ?? 0xFF000000)
                  : const Color(0xFF000000),
            ),
            reciever: data['receiver'] ?? 'No Receiver',
            subject: data['subject'] ?? 'No Subject',
            text: data['text'] ?? 'No Content',
            time: DateFormat('hh:mm a').format(
                DateTime.parse(data['time'] ?? DateTime.now().toString())),
            unread: data['unread'] ?? true,
            isStarred: data['isStarred'] ?? false,
          ),
        );
      }
      _cachedStarredMails = starredMails;
      _lastFetchTime = DateTime.now();
    } catch (e, stack) {
      debugPrint('Error fetching starred mails: $e\n$stack');
    }
    return starredMails;
  }

  Future<void> _fetchLabels() async {
    final userMail = FirebaseAuth.instance.currentUser?.uid;
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(userMail)
          .get();

      if (snapshot.exists) {
        setState(() {
          _labels = List<String>.from(snapshot.get('labels') ?? []);
        });
      } else {
        setState(() {
          _labels = [];
        });
      }
    } catch (e, stack) {
      debugPrint('Error fetching labels: $e\n$stack');
      setState(() {
        _labels = [];
      });
    }
  }

  Future<void> _addLabel() async {
    if (_newLabelNameController.text.isNotEmpty) {
      String labelName = _newLabelNameController.text;

      try {
        DocumentReference userDoc =
            FirebaseFirestore.instance.collection('users').doc(currentUser);

        await userDoc.set({
          'labels': FieldValue.arrayUnion([labelName])
        }, SetOptions(merge: true));

        // Lấy lại danh sách labels đã cập nhật
        await _fetchLabels();

        if (!mounted) return;
        setState(() {
          _newLabelNameController.clear();
        });

        if (!mounted) return;
        Navigator.of(context).pop();
      } catch (e, stack) {
        debugPrint('Error adding label: $e\n$stack');
      }
    }
  }

  Future<void> updateLabelFirestore(String oldLabel, String newLabel) async {
    final userMail = FirebaseAuth.instance.currentUser?.uid;
    if (userMail == null) {
      throw Exception('User not logged in');
    }

    try {
      // Lấy tài liệu người dùng
      final userDocRef =
          FirebaseFirestore.instance.collection('users').doc(userMail);
      final userDoc = await userDocRef.get();

      if (!userDoc.exists) {
        throw Exception('User document does not exist');
      }

      // Cập nhật mảng labels trong tài liệu người dùng
      final currentLabels = List<String>.from(userDoc.get('labels') ?? []);
      if (currentLabels.contains(oldLabel)) {
        final updatedLabels = currentLabels
            .map((label) => label == oldLabel ? newLabel : label)
            .toList();
        await userDocRef.update({'labels': updatedLabels});
      }

      // Danh sách các collection chứa email
      const collections = ['sentMails', 'receiveMails', 'drafts', 'spamMails'];

      // Cập nhật labels trong tất cả email liên quan
      for (var collection in collections) {
        final emailSnapshot = await FirebaseFirestore.instance
            .collection('users')
            .doc(userMail)
            .collection(collection)
            .where('labels', arrayContains: oldLabel)
            .get();

        for (var emailDoc in emailSnapshot.docs) {
          final labels = List<String>.from(emailDoc['labels'] ?? []);
          final updatedLabels = labels
              .map((label) => label == oldLabel ? newLabel : label)
              .toList();
          await emailDoc.reference.update({'labels': updatedLabels});
        }
      }
    } catch (e, stack) {
      debugPrint('Error updating label: $e\n$stack');
      rethrow;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final primaryColor = Theme.of(context).primaryColor;
    final textColor = isDarkMode ? Colors.white : Colors.black;
    final iconColor = isDarkMode ? Colors.white70 : Colors.black87;

    return Drawer(
      child: Container(
        decoration: BoxDecoration(
          color: isDarkMode ? const Color(0xFF1A1A1A) : Colors.white,
        ),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(20, 50, 20, 10),
              child: FutureBuilder<String?>(
                future: getUserName(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Row(
                      children: [
                        SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              isDarkMode
                                  ? Colors.white70
                                  : Theme.of(context).primaryColor,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          'Loading...',
                          style: TextStyle(
                            color: textColor.withOpacity(0.7),
                            fontFamily: 'Roboto',
                            fontSize: 16,
                          ),
                        ),
                      ],
                    );
                  }
                  if (snapshot.hasError) {
                    return Text(
                      'Error loading email',
                      style: TextStyle(
                        color: textColor,
                        fontFamily: 'Roboto',
                        fontSize: 16,
                      ),
                    );
                  }
                  final email = snapshot.data;
                  return Text(
                    (email != null && email.isNotEmpty) ? email : 'No Mailbox',
                    style: TextStyle(
                      color: textColor,
                      fontFamily: 'Roboto',
                      fontSize: 22.0,
                      fontWeight: FontWeight.w500,
                    ),
                  );
                },
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 10.0),
              child: Center(
                child: SizedBox(
                  child: Divider(
                    height: 1,
                    indent: 30,
                    endIndent: 30,
                    thickness: 1,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            _buildDrawerItem(
              icon: Icons.inbox_outlined,
              title: 'Inbox',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (ctx) => const FrontPage()),
              ),
              iconColor: iconColor,
              textColor: textColor,
            ),
            _buildDrawerItem(
              icon: Icons.star_border,
              title: 'Starred',
              onTap: () async {
                final userMail = FirebaseAuth.instance.currentUser?.uid;
                List<Message> starredMails = await fetchStarredMails(userMail);
                if (!mounted) return;
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (ctx) => StarredPage(starredMails: starredMails),
                  ),
                );
              },
              iconColor: iconColor,
              textColor: textColor,
            ),
            _buildDrawerItem(
              icon: Icons.access_time,
              title: 'Unread',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const Unread()),
              ),
              iconColor: iconColor,
              textColor: textColor,
            ),
            _buildDrawerItem(
              icon: Icons.send_outlined,
              title: 'Sent',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Sent()),
                );
              },
              iconColor: iconColor,
              textColor: textColor,
            ),
            _buildDrawerItem(
              icon: Icons.insert_drive_file_outlined,
              title: 'Drafts',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (ctx) => const Draft()),
              ),
              iconColor: iconColor,
              textColor: textColor,
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 10.0),
              child: Center(
                child: SizedBox(
                  child: Divider(
                    height: 1,
                    indent: 30,
                    endIndent: 30,
                    thickness: 1,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            ExpansionTile(
              trailing: Icon(
                isExpanded ? Icons.expand_less : Icons.expand_more,
                color: iconColor,
              ),
              title: Text(
                isExpanded ? 'Less' : 'More',
                style: TextStyle(
                  color: textColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
              onExpansionChanged: (expand) {
                setState(() {
                  isExpanded = expand;
                });
              },
              children: [
                _buildDrawerItem(
                  icon: Icons.label_important_outline,
                  title: 'Important',
                  onTap: () {},
                  iconColor: iconColor,
                  textColor: textColor,
                ),
                _buildDrawerItem(
                  icon: Icons.schedule_send_outlined,
                  title: 'Scheduled',
                  onTap: () {},
                  iconColor: iconColor,
                  textColor: textColor,
                ),
                _buildDrawerItem(
                  icon: Icons.mail_outline,
                  title: 'All Mail',
                  onTap: () {},
                  iconColor: iconColor,
                  textColor: textColor,
                ),
                _buildDrawerItem(
                  icon: Icons.error_outline,
                  title: 'Spam',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const SpamMails(),
                      ),
                    );
                  },
                  iconColor: iconColor,
                  textColor: textColor,
                ),
                _buildDrawerItem(
                  icon: Icons.delete_outline,
                  title: 'Trash',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const TrashScreen(),
                      ),
                    );
                  },
                  iconColor: iconColor,
                  textColor: textColor,
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 10.0),
                  child: Center(
                    child: SizedBox(
                      child: Divider(
                        height: 1,
                        indent: 30,
                        endIndent: 30,
                        thickness: 1,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ),
                _buildDrawerItem(
                  icon: Icons.settings_outlined,
                  title: 'Settings',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const SettingsMail(),
                      ),
                    );
                  },
                  iconColor: iconColor,
                  textColor: textColor,
                ),
              ],
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 10.0),
              child: Center(
                child: SizedBox(
                  child: Divider(
                    height: 1,
                    indent: 30,
                    endIndent: 30,
                    thickness: 1,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            ListTile(
              trailing: const Icon(Icons.add, color: Colors.grey),
              title: Text(
                'Labels',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: textColor,
                ),
              ),
              onTap: () {
                showDialog(
                  context: context,
                  builder: (ctx) {
                    return AlertDialog(
                      title: Text(
                        'New label',
                        style: TextStyle(color: textColor),
                      ),
                      content: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          TextField(
                            controller: _newLabelNameController,
                            decoration: InputDecoration(
                              hintText: 'Please enter a new label name',
                              border: const OutlineInputBorder(),
                              hintStyle:
                                  TextStyle(color: textColor.withOpacity(0.7)),
                            ),
                            style: TextStyle(color: textColor),
                          ),
                        ],
                      ),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: Text(
                            'Cancel',
                            style: TextStyle(color: textColor),
                          ),
                        ),
                        ElevatedButton(
                          onPressed: _addLabel,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: primaryColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: const Text(
                            'Create',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
            ..._labels.map((label) {
              return _buildDrawerItem(
                icon: Icons.label,
                title: label,
                onTap: () async {
                  try {
                    final userMail = FirebaseAuth.instance.currentUser?.uid;
                    await FirebaseFirestore.instance
                        .collection('users')
                        .doc(userMail)
                        .collection('mails')
                        .where('labels', arrayContains: label)
                        .get();

                    if (!mounted) return;
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => LabeledMails(labelName: label),
                      ),
                    );
                  } catch (e, stack) {
                    debugPrint('Error opening label emails: $e\n$stack');
                  }
                },
                trailing: IconButton(
                  icon: Icon(
                    LineAwesomeIcons.vertical_ellipsis,
                    color: iconColor,
                    size: 20,
                  ),
                  tooltip: 'Edit Label',
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (ctx) {
                        String newLabel = label;
                        TextEditingController controller =
                            TextEditingController(text: label);

                        return AlertDialog(
                          title: Text(
                            'Edit Label',
                            style: TextStyle(color: textColor),
                          ),
                          content: TextField(
                            controller: controller,
                            decoration: InputDecoration(
                              labelText: 'Label Name',
                              labelStyle: TextStyle(color: textColor),
                            ),
                            style: TextStyle(color: textColor),
                            onChanged: (value) {
                              newLabel = value;
                            },
                          ),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.of(ctx).pop();
                              },
                              child: Text(
                                'Cancel',
                                style: TextStyle(color: textColor),
                              ),
                            ),
                            ElevatedButton(
                              onPressed: () async {
                                if (newLabel != label) {
                                  try {
                                    await updateLabelFirestore(label, newLabel);
                                    if (!mounted) return;
                                    Navigator.of(context).pop();

                                    setState(() {
                                      _labels = _labels
                                          .map((lbl) =>
                                              lbl == label ? newLabel : lbl)
                                          .toList();
                                    });

                                    if (!mounted) return;
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(const SnackBar(
                                      content:
                                          Text('Label updated successfully'),
                                    ));
                                  } catch (e) {
                                    if (!mounted) return;
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(SnackBar(
                                      content:
                                          Text('Failed to update label: $e'),
                                    ));
                                  }
                                } else {
                                  if (!mounted) return;
                                  Navigator.of(context).pop();
                                  if (!mounted) return;
                                  ScaffoldMessenger.of(context)
                                      .showSnackBar(const SnackBar(
                                    content: Text('Label name is the same.'),
                                  ));
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: primaryColor,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              child: const Text(
                                'Save',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              onPressed: () async {
                                try {
                                  final userMail =
                                      FirebaseAuth.instance.currentUser?.uid;

                                  // Update the 'labels' array in the user's document by removing the specified label
                                  await FirebaseFirestore.instance
                                      .collection('users')
                                      .doc(userMail)
                                      .update({
                                    'labels': FieldValue.arrayRemove([label])
                                  });

                                  if (!mounted) return;

                                  // Update the local state to remove the label
                                  setState(() {
                                    _labels.remove(label);
                                  });

                                  // Close the dialog or screen
                                  Navigator.of(context).pop();

                                  // Show success message
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                        content:
                                            Text('Label deleted successfully')),
                                  );
                                } catch (e) {
                                  if (!mounted) return;

                                  // Show error message
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                        content:
                                            Text('Failed to delete label: $e')),
                                  );
                                }
                              },
                              child: const Text(
                                'Delete',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ],
                        );
                      },
                    );
                  },
                ),
                iconColor: iconColor,
                textColor: textColor,
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    required Color iconColor,
    required Color textColor,
    Widget? trailing,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 30),
      leading: Icon(icon, color: iconColor),
      title: Text(
        title,
        style: TextStyle(
          color: textColor,
          fontWeight: FontWeight.w500,
        ),
      ),
      trailing: trailing,
      onTap: onTap,
      hoverColor: Colors.grey.withOpacity(0.1),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
    );
  }
}
