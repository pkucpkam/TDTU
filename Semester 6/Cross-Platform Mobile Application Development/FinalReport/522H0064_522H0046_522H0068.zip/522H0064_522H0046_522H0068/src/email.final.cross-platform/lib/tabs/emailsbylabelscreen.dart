// ignore_for_file: use_build_context_synchronously

// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';

// Project imports:
import 'package:final_project/models/message_mode.dart';
import 'package:final_project/models/user_mode.dart' as user_models;
import 'package:final_project/tabs/mail_page.dart';

class EmailsByLabelScreen extends StatefulWidget {
  final String label;

  const EmailsByLabelScreen({super.key, required this.label});

  @override
  State<EmailsByLabelScreen> createState() => _EmailsByLabelScreen();
}

class _EmailsByLabelScreen extends State<EmailsByLabelScreen> {
  final userMail = FirebaseAuth.instance.currentUser?.uid;
  List<Message> labelMails = [];
  List<Message> mails = [];

  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchLabelMails();
  }

  Future<void> choseLabel(BuildContext context, String? threadID) async {
    if (!mounted) return;
    final userMail = FirebaseAuth.instance.currentUser?.uid;
    List<String> allLabels = [];
    List<String> selectedLabels = [];

    try {
      var snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(userMail)
          .collection('labels')
          .get();
      allLabels =
          snapshot.docs.map((doc) => doc['labelName'] as String).toList();

      var mailDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(userMail)
          .collection('mails')
          .doc(threadID)
          .get();

      if (mailDoc.exists) {
        List<dynamic> labelsFromFirestore = mailDoc['labels'] ?? [];
        selectedLabels = List<String>.from(labelsFromFirestore);
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading labels: $e')),
      );
      return;
    }

    if (!mounted) return;
    final navigatorContext = context;
    showDialog(
      context: navigatorContext,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return AlertDialog(
              title: const Text(
                'Assign Labels to Email',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              content: SingleChildScrollView(
                child: ListBody(
                  children: allLabels.map((label) {
                    return CheckboxListTile(
                      activeColor: Colors.blueAccent,
                      title: Text(label),
                      value: selectedLabels.contains(label),
                      onChanged: (bool? selected) {
                        setState(() {
                          if (selected == true) {
                            selectedLabels.add(label);
                          } else {
                            selectedLabels.remove(label);
                          }
                        });
                      },
                    );
                  }).toList(),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(ctx).pop();
                  },
                  child: const Text('Cancel',
                      style: TextStyle(color: Colors.black)),
                ),
                ElevatedButton.icon(
                  onPressed: () async {
                    try {
                      await FirebaseFirestore.instance
                          .collection('users')
                          .doc(userMail)
                          .collection('mails')
                          .doc(threadID)
                          .update({
                        'labels': selectedLabels,
                      });

                      await fetchLabelMails();

                      if (!mounted) return;
                      final dialogContext = ctx;
                      Navigator.of(dialogContext).pop();
                    } catch (e) {
                      if (!mounted) return;
                      final snackbarContext = context;
                      ScaffoldMessenger.of(snackbarContext).showSnackBar(
                        SnackBar(content: Text('Error saving labels: $e')),
                      );
                    }
                  },
                  label: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> fetchLabelMails() async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(userMail)
          .collection('mails')
          .where('labels', arrayContains: widget.label)
          .get();

      final fetchedMails = snapshot.docs.map((doc) {
        final data = doc.data();
        final colorValue = data['color']?.toString() ?? '0xFF000000';
        return Message(
          threadID: doc.id,
          subject: data['subject'] ?? 'No Subject',
          text: data['text'] ?? '',
          sender: user_models.AppUser(
            id: doc.id.hashCode,
            name: data['sender'] ?? 'Unknown',
            imageUrl: Color(int.parse(colorValue)),
          ),
          time: DateFormat('hh:mm a').format(DateTime.parse(data['time'])),
          isStarred: data['isStarred'] ?? false,
          isSelected: false,
          unread: data['unread'] ?? false,
          reciever: data['receiver'],
        );
      }).toList();

      if (!mounted) return;
      setState(() {
        labelMails = fetchedMails;
        isLoading = false;
        mails.addAll(fetchedMails);
      });
    } catch (e) {
      if (!mounted) return;
      final snackbarContext = context;
      ScaffoldMessenger.of(snackbarContext).showSnackBar(
        SnackBar(content: Text('Failed to load mails for label: $e')),
      );
      setState(() {
        isLoading = false;
      });
    }
  }

  void toggleisStarred(Message mail) async {
    if (mail.threadID != null) {
      try {
        mail.isStarred = !mail.isStarred;

        await FirebaseFirestore.instance
            .collection('users')
            .doc(userMail)
            .collection('mails')
            .doc(mail.threadID)
            .update({'isStarred': mail.isStarred});

        if (!mounted) return;
        setState(() {});
      } catch (e) {
        if (!mounted) return;
        final snackbarContext = context;
        ScaffoldMessenger.of(snackbarContext).showSnackBar(
          SnackBar(content: Text("Failed to update isStarred: $e")),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mails with Label: ${widget.label}'),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : labelMails.isEmpty
              ? const Center(child: Text('No Mails with this Label'))
              : ListView.builder(
                  itemCount: labelMails.length,
                  itemBuilder: (context, index) {
                    final mail = labelMails[index];
                    return ListTile(
                      leading: SizedBox(
                        width: 120,
                        child: Row(
                          children: [
                            // Checkbox để chọn mail
                            Tooltip(
                              message: 'Select',
                              child: Checkbox(
                                value: mail.isSelected,
                                checkColor: Colors.black,
                                activeColor: Colors.grey,
                                onChanged: (bool? value) {
                                  setState(() {
                                    mail.isSelected = value ?? false;
                                  });
                                },
                              ),
                            ),
                            // Nút ngôi sao để đánh dấu mail
                            Tooltip(
                              message:
                                  mail.isStarred ? "Starred" : "Not starred",
                              child: IconButton(
                                icon: Icon(
                                  mail.isStarred
                                      ? Icons.star
                                      : Icons.star_border,
                                  color: mail.isStarred
                                      ? Colors.yellow
                                      : Colors.grey,
                                ),
                                onPressed: () {
                                  toggleisStarred(mail);
                                },
                              ),
                            ),
                            // Avatar của người gửi
                            CircleAvatar(
                              backgroundColor: mail.sender.imageUrl,
                              child: Text(
                                mail.sender.name[0],
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      title: Text(
                        mail.subject,
                        style: TextStyle(
                          fontWeight:
                              mail.unread ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                      subtitle: Text(mail.text),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Thời gian mail
                          Text(mail.time),
                          // Nút xóa, hiện khi mail được chọn
                          if (mail.isSelected)
                            Row(
                              children: [
                                IconButton(
                                  icon: const Icon(LineAwesomeIcons.trash,
                                      color: Colors.black),
                                  onPressed: () {
                                    // Thêm logic xóa mail ở đây
                                  },
                                ),
                                IconButton(
                                  icon: const Icon(LineAwesomeIcons.tag),
                                  onPressed: () {
                                    choseLabel(context, mails[index].threadID);
                                  },
                                ),
                              ],
                            ),
                        ],
                      ),
                      onTap: () {
                        // Điều hướng đến chi tiết mail
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => Gmail(
                              index: index,
                              user: mail.sender,
                              image: mail.sender.imageUrl,
                              time: mail.time,
                              text: mail.text,
                              subject: mail.subject,
                              isstarred: mail.isStarred,
                              replies: mail.replies,
                              account: mail.reciever,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
    );
  }
}
