// Flutter imports:

// Flutter imports:
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

// Package imports:
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_gemini/flutter_gemini.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_quill/flutter_quill.dart';
import 'package:get/get.dart';
import 'package:logging/logging.dart';

// Project imports:
import 'package:final_project/firebase_options.dart';
import 'package:final_project/pages/auth_page.dart';
import 'package:final_project/services/email_service.dart';
import 'services/theme_controller.dart';

// ignore: depend_on_referenced_packages

import 'package:overlay_support/overlay_support.dart'; // Thêm import này

void main() async {
  // Initialize logger
  Logger.root.level = Level.ALL;
  Logger.root.onRecord.listen((record) {
    debugPrint('${record.level.name}: ${record.time}: ${record.message}');
  });

  WidgetsFlutterBinding.ensureInitialized();
  if (kIsWeb) {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } else {
    await Firebase.initializeApp();
    await FirebaseAppCheck.instance.activate(
      androidProvider: AndroidProvider.playIntegrity,
    );
  }

  // Initialize Gemini
  Gemini.init(apiKey: 'AIzaSyDViryooJ-Rq3p8W7nzDmsJ1AxjZyI6SAg');

  Get.put(EmailService()); // Khởi tạo EmailService
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final ThemeController themeController = Get.put(ThemeController());
    Get.put(ThemeController());
    return OverlaySupport.global(
      // Wrap GetMaterialApp trong OverlaySupport.global
      child: Obx(() => GetMaterialApp(
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              scaffoldBackgroundColor: Colors.white,
              colorScheme: ColorScheme.fromSwatch()
                  .copyWith(surface: Colors.white)
                  .copyWith(surface: Colors.white),
              fontFamily: 'Roboto',
            ),
            darkTheme: ThemeData.dark().copyWith(),
            themeMode: themeController.themeMode.value,
            home: const AuthPage(),
            localizationsDelegates: const [
              // Thêm các localizations delegates nếu cần
              FlutterQuillLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
            ],
          )),
    );
  }
}
