// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:firebase_auth/firebase_auth.dart';

// Project imports:
import 'auth_page.dart';

class LogoutHandler {
  static Future<void> logout(BuildContext context) async {
    final navigator = Navigator.of(context);
    final scaffoldMessenger = ScaffoldMessenger.of(context);

    try {
      await FirebaseAuth.instance.signOut();
      if (navigator.mounted) {
        navigator.pushReplacement(
          MaterialPageRoute(builder: (ctx) => const AuthPage()),
        );
      }
    } catch (e) {
      debugPrint('Logout error: $e');
      if (scaffoldMessenger.mounted) {
        scaffoldMessenger.clearSnackBars();
        scaffoldMessenger.showSnackBar(
          const SnackBar(content: Text('Logout failed. Please try again.')),
        );
      }
    }
  }
}
