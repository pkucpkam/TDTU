// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LinkPhonePage extends StatefulWidget {
  const LinkPhonePage({super.key});

  @override
  LinkPhonePageState createState() => LinkPhonePageState();
}

class LinkPhonePageState extends State<LinkPhonePage> {
  final userMail = FirebaseAuth.instance.currentUser?.uid;
  final _phoneController = TextEditingController();
  final _otpController = TextEditingController();
  String? _verificationId;
  bool isTwoFactorEnabled = false; // Biến để kiểm tra trạng thái xác thực 2 lớp

  // Hàm gửi OTP
  Future<void> sendOTP() async {
    String phone = _phoneController.text.trim();
    if (!phone.startsWith('+')) {
      // Thêm mã quốc gia (ví dụ: +84 cho Việt Nam)
      phone =
          '+84 ${phone.substring(1)}'; // Xóa số 0 đầu tiên và thêm mã quốc gia
    }

    if (phone.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter a phone number")),
      );
      return;
    }

    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phone,
      verificationCompleted: (PhoneAuthCredential credential) async {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Phone verified automatically")),
        );
      },
      verificationFailed: (FirebaseAuthException e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Verification failed: ${e.message}")),
        );
      },
      codeSent: (String verificationId, int? resendToken) {
        setState(() {
          _verificationId = verificationId;
        });
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("OTP sent to $phone")),
        );
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        setState(() {
          _verificationId = verificationId;
        });
      },
    );
  }

  // Hàm liên kết số điện thoại
  Future<void> linkPhoneNumber() async {
    final otp = _otpController.text.trim();

    if (otp.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter the OTP")),
      );
      return;
    }

    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: _verificationId!,
        smsCode: otp,
      );

      User? currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser != null) {
        await currentUser.linkWithCredential(credential);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Phone number linked successfully")),
        );
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("No user signed in")),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to link phone number: $e")),
      );
    }
  }

  // Hàm để bật/tắt xác thực 2 lớp
  void toggleTwoFactor() {
    setState(() {
      isTwoFactorEnabled = !isTwoFactorEnabled;
    });

    // Lưu trạng thái bật/tắt 2FA vào Firestore
    saveTwoFactorStatus(isTwoFactorEnabled);
  }

  // Lưu trạng thái 2FA vào Firestore
  Future<void> saveTwoFactorStatus(bool status) async {
    User? currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser != null) {
      try {
        // Lưu vào Firestore
        await FirebaseFirestore.instance.collection('users').doc(userMail).set(
          {
            'isTwoFactorEnabled': status,
          },
          SetOptions(merge: true), // Merge với dữ liệu hiện có (nếu có)
        );
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to save 2FA status: $e")),
        );
      }
    }
  }

  // Lấy trạng thái 2FA từ Firestore khi người dùng đăng nhập
  Future<void> loadTwoFactorStatus() async {
    User? currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser != null) {
      try {
        DocumentSnapshot userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(userMail)
            .get();
        if (userDoc.exists) {
          setState(() {
            isTwoFactorEnabled = userDoc['isTwoFactorEnabled'] ?? false;
          });
        }
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to load 2FA status: $e")),
        );
      }
    }
  }

  @override
  void initState() {
    super.initState();
    loadTwoFactorStatus(); // Lấy trạng thái 2FA khi mở trang
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Link Phone Number")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Bật/tắt xác thực 2 lớp
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Enable 2-Factor Authentication'),
                Switch(
                  value: isTwoFactorEnabled,
                  onChanged: (value) {
                    toggleTwoFactor();
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Nhập số điện thoại
            TextField(
              controller: _phoneController,
              decoration: const InputDecoration(
                labelText: "Phone Number",
                prefixIcon: Icon(Icons.phone),
              ),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 16),

            // Gửi OTP
            ElevatedButton(
              onPressed: sendOTP,
              child: const Text("Send OTP"),
            ),
            const SizedBox(height: 16),

            // Nhập OTP

            TextField(
              controller: _otpController,
              decoration: const InputDecoration(
                labelText: "OTP",
                prefixIcon: Icon(Icons.lock),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 16),

            // Liên kết số điện thoại
            ElevatedButton(
              onPressed: linkPhoneNumber,
              child: const Text("Link Phone Number"),
            ),
          ],
        ),
      ),
    );
  }
}
