// Flutter imports:
import 'package:flutter/material.dart';

class MyTextField extends StatefulWidget {
  final TextEditingController controller;
  final String hintText;
  final bool obscureText;
  final bool isEmailField;
  final bool isDobField;
  final bool isPhoneField;

  const MyTextField({
    super.key,
    required this.controller,
    required this.hintText,
    required this.obscureText,
    this.isEmailField = false,
    this.isDobField = false,
    this.isPhoneField = false,
  });

  @override
  State<MyTextField> createState() => _MyTextFieldState();
}

class _MyTextFieldState extends State<MyTextField> {
  String _errorText = '';
  int _charCount = 0;
  final String _domainName = '@jager.com';

  bool _isEmailValid(String email) {
    final emailRegex = RegExp(
        r"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
    return emailRegex.hasMatch(email);
  }

  bool _isPhoneValid(String phone) {
    final phoneRegex = RegExp(r'^(0[3|5|7|8|9])+([0-9]{8})$');
    return phoneRegex.hasMatch(phone);
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (pickedDate != null) {
      setState(() {
        widget.controller.text =
            "${pickedDate.day}/${pickedDate.month}/${pickedDate.year}";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 25.0),
      child: TextField(
        controller: widget.controller,
        obscureText: widget.obscureText,
        readOnly: widget.isDobField,
        decoration: InputDecoration(
          hintText: widget.hintText,
          hintStyle: TextStyle(color: Colors.grey[500]),
          errorText: _errorText.isNotEmpty ? _errorText : null,
          errorBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Colors.black, width: 2.0)),
          focusedBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Colors.blueAccent, width: 2.0)),
          suffixIcon: widget.isDobField
              ? IconButton(
                  icon: const Icon(Icons.calendar_today),
                  onPressed: () => _selectDate(context),
                )
              : null,
          counterText: widget.isEmailField ? '$_charCount/100' : null,
          filled: true,
          fillColor: Colors.grey[200],
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(4),
            borderSide: const BorderSide(color: Colors.grey),
          ),
        ),
        keyboardType: widget.isEmailField
            ? TextInputType.emailAddress
            : widget.isPhoneField
                ? TextInputType.phone
                : TextInputType.text,
        textInputAction: TextInputAction.next,
        maxLength: widget.isEmailField ? 100 : null,
        onChanged: (value) {
          setState(() {
            if (widget.isEmailField) {
              _charCount = value.length;
              if (!value.endsWith('@jager.com')) {
                final baseEmail =
                    value.split('@')[0]; // Extract the part before '@'
                widget.controller.text = '$baseEmail$_domainName';
                widget.controller.selection = TextSelection.fromPosition(
                  TextPosition(offset: baseEmail.length),
                );
              }
              _errorText = value.isNotEmpty && !_isEmailValid(value)
                  ? 'Please enter a valid email address'
                  : '';
            } else if (widget.isPhoneField) {
              _errorText = value.isNotEmpty && !_isPhoneValid(value)
                  ? 'Please enter a valid Vietnamese phone number'
                  : '';
            }
          });
        },
        onTap: widget.isDobField ? () => _selectDate(context) : null,
      ),
    );
  }
}
