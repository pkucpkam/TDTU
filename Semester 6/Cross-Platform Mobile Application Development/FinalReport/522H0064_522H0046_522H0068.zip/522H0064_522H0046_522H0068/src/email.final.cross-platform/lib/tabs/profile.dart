// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';

// Project imports:
import 'package:final_project/pages/logout.dart';
import 'package:final_project/tabs/password_user.dart';
import '../services/theme_controller.dart';
import 'update_profile.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final userMail = FirebaseAuth.instance.currentUser?.uid;

  Future<Map<String, dynamic>> getUserProfile() async {
    if (userMail != null) {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(userMail)
          .get();
      final data = doc.data() ?? {};
      return {
        'fullName': data['fullName'] ?? '',
        'dob': data['dob'] ?? '',
        'email': data['email'] ?? '',
        'phone': data['phone'] ?? '',
        'avatarUrl': data['avatarUrl'] ?? '',
      };
    }
    return {
      'fullName': '',
      'dob': '',
      'email': '',
      'phone': '',
      'avatarUrl': '',
    };
  }

  @override
  Widget build(BuildContext context) {
    var isDarkMode =
        MediaQuery.of(context).platformBrightness == Brightness.dark;
    final ThemeController themeController = Get.find();

    return Scaffold(
      backgroundColor: isDarkMode
          ? const Color(0xFF181A20) // Richer dark background
          : Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(LineAwesomeIcons.angle_left),
        ),
        title: const Text(
          'Profile',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {
              themeController.toggleTheme();
            },
            icon: Icon(
              isDarkMode ? LineAwesomeIcons.sun : LineAwesomeIcons.moon,
              color: Theme.of(context).iconTheme.color,
            ),
          ),
        ],
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: getUserProfile(),
        builder: (context, snapshot) {
          debugPrint(
              'FutureBuilder snapshot: connectionState=${snapshot.connectionState}, hasData=${snapshot.hasData}, error=${snapshot.error}');
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData) {
            return const Center(child: Text('No data found'));
          }

          final userData = snapshot.data!;
          debugPrint('User data in builder: $userData');
          final fullName = userData['fullName'] ?? '';
          final email = userData['email'] ?? '';
          final avatarUrl = userData['avatarUrl'] ?? '';

          return SingleChildScrollView(
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: isDarkMode
                  ? BoxDecoration(
                      color: const Color(0xFF23262F),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          blurRadius: 16,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    )
                  : null,
              child: Column(
                children: [
                  Stack(
                      children: [
                      Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: isDarkMode
                              ? [
                                  BoxShadow(
                                    color: Colors.blueAccent.withOpacity(0.3),
                                    blurRadius: 24,
                                    spreadRadius: 2,
                                  ),
                                ]
                              : [],
                        ),
                        child: avatarUrl.isNotEmpty &&
                                avatarUrl.startsWith('http')
                            ? CachedNetworkImage(
                                imageUrl: avatarUrl,
                                imageBuilder: (context, imageProvider) =>
                                    CircleAvatar(
                                  backgroundImage: imageProvider,
                                  radius: 60,
                                ),
                                placeholder: (context, url) => const CircleAvatar(
                                  backgroundImage:
                                      AssetImage('assets/user.png'),
                                  radius: 60,
                                ),
                                errorWidget: (context, url, error) {
                                  debugPrint('Image load error: $error, URL: $url');
                                  return const CircleAvatar(
                                    backgroundImage:
                                        AssetImage('assets/user.png'),
                                    radius: 60,
                                  );
                                },
                                fit: BoxFit.cover,
                              )
                            : const CircleAvatar(
                                backgroundImage: AssetImage('assets/user.png'),
                                radius: 60,
                              ),
                      ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          width: 35,
                          height: 35,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: isDarkMode
                                ? Colors.blueGrey[900]
                                : Colors.white,
                            border: Border.all(
                              color: isDarkMode
                                  ? Colors.blueAccent
                                  : Colors.black12,
                              width: 1.5,
                            ),
                            boxShadow: isDarkMode
                                ? [
                                    BoxShadow(
                                      color: Colors.blueAccent.withOpacity(0.4),
                                      blurRadius: 8,
                                    ),
                                  ]
                                : [],
                          ),
                          child: Icon(
                            LineAwesomeIcons.alternate_pencil,
                            color: isDarkMode
                                ? Colors.blueAccent
                                : Colors.blueAccent,
                            size: 20,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    fullName,
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: isDarkMode
                          ? Colors.white.withOpacity(0.95)
                          : Theme.of(context).textTheme.bodyLarge?.color,
                    ),
                  ),
                  Text(
                    email,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                      color: isDarkMode
                          ? Colors.white70
                          : Theme.of(context).textTheme.bodyMedium?.color,
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: 200,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const UpdateProfileScreen(),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: isDarkMode
                            ? const Color(0xFF23262F)
                            : const Color.fromARGB(255, 200, 217, 219),
                        side: BorderSide.none,
                        shape: const StadiumBorder(),
                        elevation: isDarkMode ? 4 : 0,
                      ),
                      child: Text(
                        "Edit Profile",
                        style: TextStyle(
                          color: isDarkMode ? Colors.blueAccent : Colors.black,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                  Divider(
                      color:
                          isDarkMode ? Colors.blueGrey[700] : Colors.black12),
                  const SizedBox(height: 10),
                
                  ProfileMenuWidget(
                    title: "Change password",
                    icon: LineAwesomeIcons.lock,
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (builder) => const PasswordUser()));
                    },
                    isDarkMode: isDarkMode,
                  ),
                  ProfileMenuWidget(
                    title: "Log out",
                    icon: LineAwesomeIcons.exclamation_circle,
                    endIcon: false,
                    onPressed: () => LogoutHandler.logout(context),
                    isDarkMode: isDarkMode,
                    textColor: Colors.red,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class ProfileMenuWidget extends StatelessWidget {
  const ProfileMenuWidget({
    required this.title,
    required this.icon,
    required this.onPressed,
    this.endIcon = true,
    this.textColor,
    this.isDarkMode = false,
    super.key,
  });

  final String title;
  final IconData icon;
  final VoidCallback onPressed;
  final bool endIcon;
  final Color? textColor;
  final bool isDarkMode;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: isDarkMode
            ? const Color(0xFF23262F).withOpacity(0.8)
            : const Color.fromARGB(255, 128, 200, 208).withOpacity(0.08),
        borderRadius: BorderRadius.circular(16),
        boxShadow: isDarkMode
            ? [
                BoxShadow(
                  color: Colors.black.withOpacity(0.12),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ]
            : [],
      ),
      child: ListTile(
        onTap: onPressed,
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(100),
            color: isDarkMode
                ? Colors.blueAccent.withOpacity(0.15)
                : const Color.fromARGB(255, 128, 200, 208).withOpacity(0.2),
          ),
          child: Icon(icon, color: isDarkMode ? Colors.blueAccent : null),
        ),
        title: Text(
          title,
          style: TextStyle(
            color: textColor ??
                (isDarkMode
                    ? Colors.white.withOpacity(0.92)
                    : Theme.of(context).textTheme.bodyLarge?.color),
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
        trailing: endIcon
            ? Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  color: isDarkMode
                      ? Colors.blueAccent.withOpacity(0.12)
                      : const Color.fromARGB(255, 128, 200, 208)
                          .withOpacity(0.1),
                ),
                child: Icon(
                  LineAwesomeIcons.angle_right,
                  color: isDarkMode ? Colors.blueAccent : Colors.black,
                  size: 18,
                ),
              )
            : null,
      ),
    );
  }
}
