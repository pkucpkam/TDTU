// Dart imports:
import 'dart:convert';
import 'dart:io';
import 'dart:math';

// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_quill/flutter_quill.dart';
import 'package:http/http.dart' as http;

// Project imports:
import 'package:final_project/components/custom_chip_input.dart';
import 'package:final_project/tabs/front_page.dart';

class Compose extends StatefulWidget {
  final String? initialFrom;
  final String? initialTo;
  final String? initialSubject;
  final String? initialBody;
  final String? userMail;
  final String? userMailRe;
  final bool isReply;
  final bool isDraft;
  final String? draftId;
  final String? forwardedBody;

  const Compose({
    super.key,
    this.initialFrom,
    this.initialTo,
    this.initialSubject,
    this.initialBody,
    this.userMail,
    this.userMailRe,
    required this.isReply,
    required this.isDraft,
    this.draftId,
    this.forwardedBody,
  });

  @override
  ComposeState createState() => ComposeState();
}

class ComposeState extends State<Compose> {
  List<PlatformFile> files = [];
  bool isCcBccExpanded = false;
  String? fromValue;
  bool isSent = false;
  bool isSuccessfullySent = false;
  bool isSubjectFocused = false;
  bool isDraftSaved = false;
  final FocusNode subjectFocusNode = FocusNode();
  final FocusNode quillFocusNode = FocusNode();
  final String? currentUser = FirebaseAuth.instance.currentUser?.uid;
  final String? currentUserEmail = FirebaseAuth.instance.currentUser?.email;

  List<String> toEmails = [];
  List<String> ccEmails = [];
  List<String> bccEmails = [];

  // Quill Controller để quản lý nội dung rich text
  late QuillController quillController;

  @override
  void initState() {
    super.initState();
    _loadUserEmail();
    subjectFocusNode.addListener(() {
      setState(() {
        isSubjectFocused = subjectFocusNode.hasFocus;
      });
    });

    subjectFocusNode.addListener(() {
      if (!subjectFocusNode.hasFocus && !quillFocusNode.hasFocus) {
        quillFocusNode.requestFocus();
      }
    });
    fromController.text = widget.initialFrom ?? currentUserEmail ?? '';
    // Làm sạch danh sách người nhận
    toEmails = _parseEmails(widget.initialTo ?? '');
    subjectController.text = widget.initialSubject ?? '';

    // Khởi tạo QuillController
    if (widget.initialBody != null || widget.forwardedBody != null) {
      final initialContent = widget.initialBody ?? '';
      final forwardedContent = widget.forwardedBody != null
          ? '\n\n---------- Forwarded message ----------\n${widget.forwardedBody}'
          : '';
      quillController = QuillController(
        document: Document.fromJson(
          jsonDecode('[{"insert":"$initialContent$forwardedContent\\n"}]'),
        ),
        selection: const TextSelection.collapsed(offset: 0),
      );
    } else if (widget.isDraft) {
      quillController = QuillController.basic();
      _loadDraftData();
    } else {
      quillController = QuillController.basic();
    }
  }

  Future<String?> getUserName(String email) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email)
          .get();
      if (snapshot.docs.isNotEmpty) {
        final userData = snapshot.docs.first.data();
        final fullName = userData['fullName'] as String?;
        final lastName = userData['lastName'] as String?;
        String userName = '';
        if (fullName != null) userName += fullName;
        if (lastName != null) {
          userName += (userName.isNotEmpty ? ' ' : '') + lastName;
        }
        return userName.isNotEmpty ? userName : null;
      }
    } catch (e) {
      debugPrint('Error fetching user name: $e');
    }
    return null;
  }

  Future<void> _loadDraftData() async {
    try {
      if (currentUser != null && widget.draftId != null) {
        final doc = await FirebaseFirestore.instance
            .collection('drafts')
            .doc(widget.draftId)
            .get();
        if (doc.exists && mounted) {
          final data = doc.data()!;
          setState(() {
            fromController.text = data['from'] ?? currentUserEmail ?? '';
            toEmails = _parseEmails(data['to'] ?? '');
            ccEmails = _parseEmails(data['cc'] ?? '');
            bccEmails = _parseEmails(data['bcc'] ?? '');
            subjectController.text = data['subject'] ?? '';
            // Tải nội dung Quill từ JSON
            if (data['bodyJson'] != null) {
              quillController = QuillController(
                document: Document.fromJson(jsonDecode(data['bodyJson'])),
                selection: const TextSelection.collapsed(offset: 0),
              );
            }
            if (data['attachments'] != null) {
              files = (data['attachments'] as List<dynamic>)
                  .map((name) => PlatformFile(name: name, size: 0))
                  .toList();
            }
          });
        }
      }
    } catch (e) {
      debugPrint('Error loading draft: $e');
    }
  }

  Future<void> saveDraft() async {
    if (isDraftSaved || isSuccessfullySent) return;

    // Kiểm tra xem có nội dung hoặc các trường khác không
    final hasContent = quillController.document.toPlainText().trim().isNotEmpty;
    final hasRecipients =
        toEmails.isNotEmpty || ccEmails.isNotEmpty || bccEmails.isNotEmpty;

    // Chỉ lưu nếu có ít nhất một người nhận (To, Cc, hoặc Bcc) hoặc có nội dung/subject/tệp đính kèm
    if ((hasRecipients ||
            hasContent ||
            subjectController.text.isNotEmpty ||
            files.isNotEmpty) ||
        (toEmails.isNotEmpty || ccEmails.isNotEmpty || bccEmails.isNotEmpty)) {
      if (currentUser == null) return;

      final draftId = widget.draftId ??
          FirebaseFirestore.instance.collection('drafts').doc().id;
      final draft = {
        'from': currentUserEmail,
        'to': toEmails.join(', '),
        'cc': ccEmails.join(', '),
        'bcc': bccEmails.join(', '),
        'subject': subjectController.text,
        'bodyJson': jsonEncode(quillController.document.toDelta().toJson()),
        'attachments': files.map((f) => f.name).toList(),
        'time': DateTime.now().toIso8601String(),
        'mailId': draftId,
        'userId': currentUser,
      };

      try {
        isDraftSaved = true;
        debugPrint('Saving draft with data: $draft');
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('drafts')
            .doc(draftId)
            .set(draft);
        await FirebaseFirestore.instance
            .collection('drafts')
            .doc(draftId)
            .set(draft);
      } catch (e) {
        debugPrint('Error saving draft: $e');
        isDraftSaved = false;
      }
    } else {
      debugPrint('Draft not saved: No recipients provided');
    }
  }

  Future<void> _loadUserEmail() async {
    setState(() {
      fromValue = currentUserEmail;
    });
  }

  List<String> _parseEmails(String input) {
    return input
        .split(RegExp(r'[,\s]+'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
  }

  Future<List<String>> _fetchEmailSuggestions(String query) async {
    if (query.isEmpty) return [];
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isGreaterThanOrEqualTo: query)
          .where('email', isLessThanOrEqualTo: '$query\uf8ff')
          .limit(10)
          .get();
      return snapshot.docs
          .map((doc) => doc['email'] as String)
          .where((email) => email != currentUserEmail)
          .toList();
    } catch (e) {
      debugPrint('Error fetching suggestions: $e');
      return [];
    }
  }

  final TextEditingController fromController = TextEditingController();
  final TextEditingController subjectController = TextEditingController();

  Future<String?> _getReceiver(String email) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email)
          .get();
      if (snapshot.docs.isNotEmpty) {
        return snapshot.docs.first.id;
      }
    } catch (e) {
      debugPrint('Error fetching receiver: $e');
    }
    return null;
  }

  Future<Map<String, String>?> _uploadAttachment(
      String mailId, PlatformFile file) async {
    try {
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('attachments/$mailId/${file.name}');
      final uploadTask = storageRef.putFile(File(file.path!));
      final snapshot = await uploadTask;
      final downloadUrl = await snapshot.ref.getDownloadURL();
      return {'name': file.name, 'url': downloadUrl};
    } catch (e) {
      debugPrint('Error uploading file: $e');
      return null;
    }
  }

  Future<bool> checkSpam(String content) async {
    try {
      final response = await http.post(
        Uri.parse('https://api.oopspam.com/v1/spamdetection'),
        headers: {
          'Content-Type': 'application/json',
          'X-Api-Key': 'JO8cYsN3x6VJilb9KySCQX4j1jzoixRnJDH2SEjQ',
        },
        body: jsonEncode({'content': content}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['Details']['isContentSpam'] == 'spam';
      } else {
        debugPrint('Spam check API error: ${response.statusCode}');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Failed to check spam status'),
            backgroundColor: Colors.orange[600],
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            elevation: 8,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            duration: const Duration(seconds: 3),
          ),
        );
        return false;
      }
    } catch (e) {
      debugPrint('Error checking spam: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Error checking spam status'),
          backgroundColor: Colors.orange[600],
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          elevation: 8,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          duration: const Duration(seconds: 3),
        ),
      );
      return false;
    }
  }

  Future<void> sendMail() async {
    if (toEmails.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content:
              const Text('Please enter at least one valid recipient in To'),
          backgroundColor: Colors.red[600],
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          elevation: 8,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          duration: const Duration(seconds: 3),
        ),
      );
      return;
    }

    final scaffoldMessenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    try {
      isSent = true;
      final mailId = FirebaseFirestore.instance.collection('mails').doc().id;
      final currentTime = DateTime.now();
      final subject = widget.isReply || widget.forwardedBody != null
          ? subjectController.text
              .replaceFirst(RegExp(r'^(Re:|Fwd:)'), '')
              .trim()
          : subjectController.text;

      // Tải lên tất cả tệp đính kèm
      List<Map<String, String>> attachments = [];
      for (var file in files) {
        if (file.path != null) {
          final result = await _uploadAttachment(mailId, file);
          if (result != null) {
            attachments.add(result);
          }
        }
      }

      final senderName = await getUserName(fromValue!);
      // Thêm: Lấy avatarUrl của người gửi
      String? senderAvatarUrl;
      try {
        final senderDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .get();
        if (senderDoc.exists) {
          senderAvatarUrl =
              senderDoc.data()?['avatarUrl'] as String? ?? 'assets/user.png';
        } else {
          senderAvatarUrl = 'assets/user.png';
        }
      } catch (e) {
        debugPrint('Error fetching sender avatar: $e');
        senderAvatarUrl = 'assets/user.png';
      }

      final allRecipients = {...toEmails, ...ccEmails, ...bccEmails}.toList();
      final receiverNames = <String, String?>{};
      // Thêm: Lấy avatarUrl của người nhận

      // Kiểm tra spam nếu không phải reply hoặc forward
      bool isSpam = false;
      if (!widget.isReply && widget.forwardedBody == null) {
        final delta = quillController.document.toDelta().toJson();
        final content = delta.map((op) => op['insert']).join('').trim();
        isSpam = await checkSpam(content);
      }

      final emailData = {
        'mailId': mailId,
        'sender': fromValue,
        'senderName': senderName ?? 'Unknown',
        'senderAvatarUrl': senderAvatarUrl, // Thêm trường này
        'to': toEmails.join(', '),
        'toNames':
            toEmails.map((e) => receiverNames[e] ?? 'Unknown').join(', '),
        'cc': ccEmails.join(', '),
        'ccNames':
            ccEmails.map((e) => receiverNames[e] ?? 'Unknown').join(', '),
        'bcc': bccEmails.join(', '),
        'bccNames':
            bccEmails.map((e) => receiverNames[e] ?? 'Unknown').join(', '),
        'subject': subject,
        'text': jsonEncode(quillController.document.toDelta().toJson()),
        'attachments': attachments,
        'time': currentTime.toIso8601String(),
        'isStarred': false,
        'unread': true,
        'color': getRandomColor().value,
        'replies': [],
        'isForward': widget.forwardedBody != null,
        'mailForwarded': widget.forwardedBody != null ? widget.draftId : null,
        'isSpam': isSpam,
      };

      final sentMailData = {
        'mailId': mailId,
        'receiver': toEmails.join(', '),
        'receiverNames':
            toEmails.map((e) => receiverNames[e] ?? 'Unknown').join(', '),
        'senderAvatarUrl': senderAvatarUrl, // Thêm trường này
        'subject': subject,
        'text': jsonEncode(quillController.document.toDelta().toJson()),
        'attachments': attachments,
        'time': currentTime.toIso8601String(),
        'isStarred': false,
        'unread': false,
        'color': getRandomColor().value,
        'isTrash': false,
        'labels': [],
      };

      final receiveMailData = {
        'mailId': mailId,
        'sender': fromValue,
        'senderName': senderName ?? 'Unknown',
        'senderAvatarUrl': senderAvatarUrl, // Thêm trường này
        'subject': subject,
        'text': jsonEncode(quillController.document.toDelta().toJson()),
        'attachments': attachments,
        'time': currentTime.toIso8601String(),
        'isStarred': false,
        'unread': true,
        'color': getRandomColor().value,
        'isTrash': false,
        'labels': [],
        'isSpam': isSpam,
      };

      await FirebaseFirestore.instance
          .collection('mails')
          .doc(mailId)
          .set(emailData);

      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('sentMails')
          .doc(mailId)
          .set(sentMailData);

      // Lưu vào receiveMails hoặc spamMails dựa trên isSpam
      for (var email in allRecipients) {
        final receiverId = await _getReceiver(email);
        if (receiverId != null) {
          final collection = isSpam ? 'spamMails' : 'receiveMails';
          await FirebaseFirestore.instance
              .collection('users')
              .doc(receiverId)
              .collection(collection)
              .doc(mailId)
              .set({
            ...receiveMailData,
            'receiverName': receiverNames[email] ?? 'Unknown',
            if (bccEmails.contains(email)) 'bcc': email,
          });
        }
      }

      if (widget.draftId != null) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('drafts')
            .doc(widget.draftId)
            .delete();
        await FirebaseFirestore.instance
            .collection('drafts')
            .doc(widget.draftId)
            .delete();
      }

      if (widget.isReply) {
        final emailDataReply = {
          'from': fromValue,
          'fromName': senderName ?? 'Unknown',
          'senderAvatarUrl': senderAvatarUrl, // Thêm trường này
          'to': toEmails.join(', '),
          'toNames':
              toEmails.map((e) => receiverNames[e] ?? 'Unknown').join(', '),
          'subject': subject,
          'text': jsonEncode(quillController.document.toDelta().toJson()),
          'attachments': attachments,
          'time': currentTime.toIso8601String(),
        };

        final querySnapshot1 = await FirebaseFirestore.instance
            .collection('users')
            .doc(widget.userMail)
            .collection('receiveMails')
            .get();

        final querySnapshot2 = await FirebaseFirestore.instance
            .collection('users')
            .doc(widget.userMailRe)
            .collection('receiveMails')
            .get();

        for (var doc in querySnapshot1.docs) {
          final data = doc.data();
          final messageID = doc.id;
          if (data['subject'].trim().toLowerCase() ==
                  subject.trim().toLowerCase() &&
              data['sender'].trim().toLowerCase() ==
                  widget.userMail!.trim().toLowerCase()) {
            await FirebaseFirestore.instance
                .collection('users')
                .doc(widget.userMail)
                .collection('receiveMails')
                .doc(messageID)
                .update({
              'replies': FieldValue.arrayUnion([emailDataReply]),
            });
            break;
          }
        }

        for (var doc in querySnapshot2.docs) {
          final data = doc.data();
          final messageID = doc.id;
          if (data['subject'].trim().toLowerCase() ==
                  subject.trim().toLowerCase() &&
              data['receiver'].trim().toLowerCase() ==
                  widget.userMailRe!.trim().toLowerCase()) {
            await FirebaseFirestore.instance
                .collection('users')
                .doc(widget.userMailRe)
                .collection('receiveMails')
                .doc(messageID)
                .update({
              'replies': FieldValue.arrayUnion([emailDataReply]),
            });
            break;
          }
        }
      }

      isSuccessfullySent = true;
      setState(() {
        toEmails.clear();
        ccEmails.clear();
        bccEmails.clear();
        subjectController.clear();
        quillController.clear();
        files.clear();
        isSent = false;
      });

      scaffoldMessenger.showSnackBar(
        SnackBar(
          content: Text(isSpam
              ? 'Email sent but marked as spam'
              : 'Send mail successfully'),
          backgroundColor: isSpam ? Colors.orange[600] : Colors.green[600],
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          elevation: 8,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          duration: const Duration(seconds: 2),
        ),
      );

      if (mounted) {
        navigator.pushReplacement(
          MaterialPageRoute(builder: (context) => const FrontPage()),
        );
      }
    } catch (e) {
      scaffoldMessenger.showSnackBar(
        SnackBar(
          content: const Text('Failed to send email'),
          backgroundColor: Colors.red[600],
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          elevation: 8,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          duration: const Duration(seconds: 3),
        ),
      );
      if (mounted) {
        setState(() {
          isSent = false;
        });
      }
    }
  }

  Color getRandomColor() {
    final random = Random();
    return Color.fromARGB(
        255, random.nextInt(256), random.nextInt(256), random.nextInt(256));
  }

  Future<void> pickFile() async {
    debugPrint('pickFile: Starting file picker');
    try {
      FilePickerResult? result =
          await FilePicker.platform.pickFiles(allowMultiple: true);
      debugPrint(
          'pickFile: File picker result received: ${result?.files.length ?? 0} files');
      if (result != null) {
        if (mounted) {
          debugPrint(
              'pickFile: Widget is mounted, updating state with ${result.files.length} files');
          setState(() {
            files.addAll(result.files);
          });
        } else {
          debugPrint('pickFile: Widget is not mounted, skipping setState');
        }
      } else {
        debugPrint('pickFile: No files selected');
      }
    } catch (e, stackTrace) {
      debugPrint('pickFile: Error occurred: $e');
      debugPrint('pickFile: Stack trace: $stackTrace');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Failed to pick files'),
            backgroundColor: Colors.red[600],
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            elevation: 8,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  void removeFile(PlatformFile file) {
    setState(() {
      files.remove(file);
    });
  }

  @override
  void dispose() {
    subjectFocusNode.dispose();
    fromController.dispose();
    subjectController.dispose();
    quillFocusNode.dispose();
    quillController.dispose();
    if (!isSuccessfullySent && mounted) {
      saveDraft();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !isSent,
      onPopInvoked: (bool didPop) async {
        if (didPop || isSent || isSuccessfullySent) return;
        await saveDraft();
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor:
              Theme.of(context).colorScheme.surface, // Nền theo theme
          iconTheme: IconThemeData(
              color: Theme.of(context).colorScheme.onSurface), // Màu biểu tượng
          title: Text(
            'Compose',
            style: TextStyle(
              color:
                  Theme.of(context).colorScheme.onSurface, // Màu chữ theo theme
              fontSize: 18,
              fontFamily: "Roboto",
            ),
          ),
          actions: [
            IconButton(
              icon: Icon(
                Icons.attach_file,
                color: Theme.of(context).colorScheme.onSurface,
              ),
              onPressed: pickFile,
            ),
            IconButton(
              icon: Icon(
                Icons.send,
                color: toEmails.isEmpty
                    ? Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.4) // Nhạt khi vô hiệu
                    : Theme.of(context).colorScheme.onSurface,
              ),
              onPressed: toEmails.isEmpty ? null : sendMail,
            ),
            PopupMenuButton<String>(
              offset: const Offset(0, 50),
              icon: Icon(
                Icons.more_vert,
                color: Theme.of(context).colorScheme.onSurface,
              ),
              onSelected: (String value) async {
                if (value == '4') {
                  await saveDraft();
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          'Draft saved',
                          style: TextStyle(
                            color: Theme.of(context)
                                .colorScheme
                                .onSurface, // Màu chữ SnackBar
                          ),
                        ),
                        backgroundColor: Theme.of(context)
                            .colorScheme
                            .primary, // Màu nền SnackBar
                        behavior: SnackBarBehavior.floating,
                        margin: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        elevation: 8,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        duration: const Duration(seconds: 3),
                      ),
                    );
                  }
                }
              },
              itemBuilder: (BuildContext context) {
                return [
                  PopupMenuItem(
                    value: '1',
                    child: Text(
                      'Schedule sending',
                      style: TextStyle(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurface, // Màu chữ menu
                      ),
                    ),
                  ),
                  PopupMenuItem(
                    value: '2',
                    child: Text(
                      'Add from contacts',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                    ),
                  ),
                  PopupMenuItem(
                    value: '3',
                    child: Text(
                      'Cancel',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                    ),
                  ),
                  PopupMenuItem(
                    value: '4',
                    child: Text(
                      'Save draft',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                    ),
                  ),
                ];
              },
            ),
          ],
          elevation: 0,
          scrolledUnderElevation: 1, // Đổ bóng nhẹ khi cuộn
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.only(
              bottom: 48), // Thêm khoảng cách 8px phía dưới
          child: _buildQuillToolbar(),
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 16,
            left: 16,
            right: 16,
            top: 16,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildFromField(),
              _buildDivider(),
              _buildToField(),
              _buildDivider(),
              if (isCcBccExpanded) _buildCcBccFields(),
              _buildSubjectField(),
              _buildDivider(),
              _buildBodyField(),
              _buildAttachmentSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFromField() {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.all(20),
          child: Text('From:',
              style: TextStyle(
                  fontSize: 18,
                  color: Theme.of(context).colorScheme.onSurface)),
        ),
        Expanded(
          child: Text(
            fromValue ?? 'Loading...',
            style: TextStyle(
                fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
          ),
        ),
      ],
    );
  }

  Widget _buildToField() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
          child: Text(
            'To:',
            style: TextStyle(
              fontSize: 18,
              color: Theme.of(context).colorScheme.onSurface,
            ),
          ),
        ),
        Expanded(
          child: CustomChipInput(
            emails: toEmails,
            onChanged: (newEmails) {
              setState(() {
                toEmails = newEmails;
              });
            },
            fetchSuggestions: _fetchEmailSuggestions,
            suffixIcon: IconButton(
              icon: Icon(
                isCcBccExpanded ? Icons.arrow_drop_up : Icons.arrow_drop_down,
                color: Colors.grey[600],
              ),
              onPressed: () {
                setState(() {
                  isCcBccExpanded = !isCcBccExpanded;
                });
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCcBccFields() {
    return Column(
      children: [
        _buildFieldRow(
          label: 'Cc:',
          emails: ccEmails,
          onChanged: (newEmails) {
            setState(() {
              ccEmails = newEmails;
            });
          },
        ),
        _buildDivider(),
        _buildFieldRow(
          label: 'Bcc:',
          emails: bccEmails,
          onChanged: (newEmails) {
            setState(() {
              bccEmails = newEmails;
            });
          },
        ),
        _buildDivider(),
      ],
    );
  }

  Widget _buildSubjectField() {
    return TextField(
      controller: subjectController,
      focusNode: subjectFocusNode,
      cursorHeight: 22,
      style: TextStyle(
          fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
      decoration: InputDecoration(
        border: InputBorder.none,
        hintText: isSubjectFocused ? null : 'Subject',
        contentPadding: const EdgeInsets.all(20),
        hintStyle: TextStyle(
            fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
      ),
    );
  }

  Widget _buildQuillToolbar() {
    return QuillSimpleToolbar(
      controller: quillController,
      config: const QuillSimpleToolbarConfig(
        showBoldButton: true, // Giữ nút in đậm
        showItalicButton: true, // Giữ nút in nghiêng
        showUnderLineButton: true, // Giữ nút gạch chân
        showStrikeThrough: true,
        showFontFamily: true,
        showFontSize: true,
        showHeaderStyle: false,
        showListNumbers: false,
        showListBullets: true,
        showListCheck: false,
        showCodeBlock: true,
        showQuote: false,
        showIndent: false,
        showLink: false,
        showInlineCode: false,
        showClearFormat: true,
        showColorButton: true,
        showBackgroundColorButton: true,
        showUndo: false,
        showRedo: false,
        showClipboardCut: false,
        showClipboardCopy: false,
        showClipboardPaste: false,
        showAlignmentButtons: false,
        showDirection: false,
        showSearchButton: false,
        showSubscript: false,
        showSuperscript: false,
      ),
    );
  }

  Widget _buildBodyField() {
    return Container(
      constraints: const BoxConstraints(minHeight: 200),
      padding: const EdgeInsets.all(20),
      child: QuillEditor.basic(
        controller: quillController,
        focusNode: quillFocusNode,
        config: const QuillEditorConfig(
          placeholder: 'Compose your message here...',
          autoFocus: false,
        ),
      ),
    );
  }

  Widget _buildAttachmentSection() {
    if (files.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: files.map((file) {
          // Determine file type and corresponding icon
          final extension = file.extension?.toLowerCase();
          bool isImage =
              extension == 'jpg' || extension == 'jpeg' || extension == 'png';
          bool isPdf = extension == 'pdf';
          bool isDoc = extension == 'doc' || extension == 'docx';
          bool isExcel = extension == 'xls' || extension == 'xlsx';
          bool isZip = extension == 'zip' || extension == 'rar';

          // Select appropriate icon based on file type
          IconData fileIcon;
          if (isImage) {
            fileIcon = Icons.image;
          } else if (isPdf) {
            fileIcon = Icons.picture_as_pdf;
          } else if (isDoc) {
            fileIcon = Icons.description;
          } else if (isExcel) {
            fileIcon = Icons.table_chart;
          } else if (isZip) {
            fileIcon = Icons.archive;
          } else {
            fileIcon =
                Icons.insert_drive_file; // Default icon for unknown files
          }

          // Display images with a thumbnail, others with a chip
          return isImage && file.path != null
              ? SizedBox(
                  width: 100,
                  height: 100,
                  child: Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.file(
                          File(file.path!),
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => Icon(
                            fileIcon,
                            size: 50,
                            color: Theme.of(context).colorScheme.onSurface,
                          ),
                        ),
                      ),
                      Positioned(
                        right: 0,
                        top: 0,
                        child: GestureDetector(
                          onTap: () => removeFile(file),
                          child: Container(
                            color: Colors.black54,
                            child: const Icon(Icons.close,
                                size: 16, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              : Chip(
                  avatar: Icon(
                    fileIcon,
                    size: 18,
                    color: Colors.grey[600],
                  ),
                  label: Text(
                    file.name,
                    style: const TextStyle(fontSize: 14),
                    overflow: TextOverflow.ellipsis,
                  ),
                  deleteIcon: const Icon(Icons.close, size: 18),
                  onDeleted: () => removeFile(file),
                  backgroundColor: Colors.grey[100],
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                );
        }).toList(),
      ),
    );
  }

  Widget _buildFieldRow({
    required String label,
    required List<String> emails,
    required ValueChanged<List<String>> onChanged,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
            label,
            style: TextStyle(
                fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
          ),
        ),
        Expanded(
          child: CustomChipInput(
            emails: emails,
            onChanged: onChanged,
            fetchSuggestions: _fetchEmailSuggestions,
          ),
        ),
      ],
    );
  }

  Widget _buildDivider() {
    return Divider(
      color: Colors.grey[300],
      height: 1,
      thickness: 0.6,
    );
  }
}
