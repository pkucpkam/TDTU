// lib/services/notification_service.dart

// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:overlay_support/overlay_support.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  void showEmailNotification(String title, String body) {
    showSimpleNotification(
      Text(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
      subtitle: Text(
        body,
        style: const TextStyle(color: Colors.white70),
      ),
      background: Colors.blueAccent,
      duration: const Duration(seconds: 3),
      position: NotificationPosition.top,
      slideDismissDirection: DismissDirection.up,
    );
  }
}
