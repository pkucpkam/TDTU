// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:simple_icons/simple_icons.dart';

// Project imports:
import 'package:final_project/tabs/mails.dart';
import 'package:final_project/tabs/meet.dart';

class BottomNavigation extends StatelessWidget {
  final int currentIndex;

  const BottomNavigation({
    super.key,
    required this.currentIndex,
  });

  // Hàm lấy số email chưa đọc từ Firestore
  Future<int> _getUnreadCount() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return 0;

    try {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .collection('receiveMails')
          .where('unread', isEqualTo: true)
          .where('isTrash', isEqualTo: false)
          .get();
      return querySnapshot.docs.length;
    } catch (e) {
      debugPrint('Error fetching unread count: $e');
      return 0;
    }
  }

  // Hàm xử lý điều hướng
  void _onTabTapped(int index, BuildContext context) {
    if (index == currentIndex) return; // Không làm gì nếu nhấn tab hiện tại

    // Pop all routes until we reach the root
    while (Navigator.canPop(context)) {
      Navigator.pop(context);
    }

    // Push the new route
    Widget targetPage;
    switch (index) {
      case 0:
        targetPage = const Mails();
        break;
      case 1:
        targetPage = const Meet();
        break;
      default:
        return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => targetPage),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<int>(
      future: _getUnreadCount(),
      builder: (context, snapshot) {
        int unreadCount = snapshot.data ?? 0;
        if (snapshot.connectionState == ConnectionState.waiting) {
          unreadCount = 0; // Hiển thị 0 khi đang tải
        }

        return BottomNavigationBar(
          onTap: (index) => _onTabTapped(index, context),
          currentIndex: currentIndex,
          iconSize: 28,
          selectedFontSize: 12,
          unselectedFontSize: 12,
          selectedItemColor: Theme.of(context).colorScheme.onSurface, // Màu chữ khi được chọn
          unselectedItemColor: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
          items: [
            BottomNavigationBarItem(
              icon: Padding(
                padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0),
                child: Stack(
                  children: <Widget>[
                    const Icon(
                      Icons.mail,
                      size: 28,
                    ),
                    if (unreadCount > 0)
                      Positioned(
                        right: 0,
                        top: 0,
                        child: Container(
                          padding: const EdgeInsets.all(2),
                          decoration: const BoxDecoration(
                            color: Colors.red,
                            shape: BoxShape.circle,
                          ),
                          constraints: const BoxConstraints(
                            minWidth: 16,
                            minHeight: 16,
                          ),
                          child: Center(
                            child: Text(
                              '$unreadCount',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              label: 'Mail'
              ,
            ),
            const BottomNavigationBarItem(
              icon: Icon(
                SimpleIcons.googlemeet,
                size: 28,
              ),
              label: 'Meet',
            ),
          ],
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500),
          unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w400),
          elevation: 8,
        );
      },
    );
  }
}
