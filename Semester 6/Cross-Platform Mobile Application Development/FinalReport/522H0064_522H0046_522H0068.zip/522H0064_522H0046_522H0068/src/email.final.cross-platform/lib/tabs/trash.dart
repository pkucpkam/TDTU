// Dart imports:
import 'dart:convert';

// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

// Project imports:
import 'package:final_project/models/message_mode.dart';
import 'package:final_project/models/user_mode.dart' as my_models;
import 'package:final_project/tabs/mail_detail.dart';

class TrashScreen extends StatefulWidget {
  const TrashScreen({super.key});

  @override
  State<TrashScreen> createState() => _TrashScreenState();
}

class _TrashScreenState extends State<TrashScreen> {
  List<Message> trashedMails = [];
  final String? currentUser = FirebaseAuth.instance.currentUser?.uid;

  @override
  void initState() {
    super.initState();
    loadTrashedMails();
  }

  Future<void> loadTrashedMails() async {
    if (currentUser == null) {
      debugPrint('No user logged in');
      return;
    }

    try {
      // Danh sách các truy vấn từ cả hai collection
      final trashMailsQuery = FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('receiveMails')
          .where('isTrash', isEqualTo: true)
          .orderBy('time', descending: true)
          .get();

      final sentMailsQuery = FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('sentMails')
          .where('isTrash', isEqualTo: true)
          .orderBy('time', descending: true)
          .get();

      // Chờ cả hai truy vấn hoàn thành
      final results = await Future.wait([trashMailsQuery, sentMailsQuery]);

      setState(() {
        trashedMails.clear();
      });

      for (var querySnapshot in results) {
        for (var doc in querySnapshot.docs) {
          final data = doc.data();
          final colorValue = data['color'];
          Color senderColor;
          if (colorValue is int) {
            senderColor = Color(colorValue);
          } else if (colorValue is String && int.tryParse(colorValue) != null) {
            senderColor = Color(int.parse(colorValue));
          } else {
            senderColor = Colors.blueGrey;
          }

          // Lấy avatarUrl của người gửi
          String? avatarUrl;
          try {
            final senderEmail = data['sender'] ?? data['senderName'];
            if (senderEmail != null) {
              final userSnapshot = await FirebaseFirestore.instance
                  .collection('users')
                  .where('email', isEqualTo: senderEmail)
                  .get();
              if (userSnapshot.docs.isNotEmpty) {
                avatarUrl = userSnapshot.docs.first.data()['avatarUrl'] ??
                    'assets/user.png';
              } else {
                avatarUrl = 'assets/user.png';
              }
            } else {
              avatarUrl = 'assets/user.png';
            }
          } catch (e) {
            debugPrint('Error fetching avatarUrl: $e');
            avatarUrl = 'assets/user.png';
          }

          final mail = Message(
            sender: my_models.AppUser(
              id: trashedMails.length,
              name: data['senderName'] ?? 'Unknown',
              imageUrl: senderColor,
            ),
            reciever: data['receiver'] ?? 'No Receiver',
            subject: data['subject'] ?? 'No Subject',
            text: data['text'] ?? 'No Content',
            time: DateFormat('hh:mm a').format(DateTime.parse(data['time'])),
            unread: data['unread'] ?? true,
            isStarred: data['isStarred'] ?? false,
            threadID: doc.id,
            avatarUrl: avatarUrl, // Lưu avatarUrl vào Message
          );

          setState(() {
            trashedMails.add(mail);
          });
        }
      }
    } catch (e, stackTrace) {
      debugPrint('Error loading trashed mails: $e');
      debugPrint('Stack trace: $stackTrace');
    }
  }

  Future<void> restoreMail(String? threadID) async {
    if (threadID == null || currentUser == null) return;
    final index = trashedMails.indexWhere((mail) => mail.threadID == threadID);
    if (index == -1) return;

    final mailToRestore = trashedMails[index];

    // Optimistically update UI
    setState(() {
      trashedMails.removeAt(index);
    });

    try {
      // Get the type from trashMails
      final trashDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('trashMails')
          .doc(threadID)
          .get();

      if (!trashDoc.exists) {
        throw Exception('Trash document not found');
      }

      final String type = trashDoc.data()?['type'];

      // Update isTrash in the corresponding collection
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection(type)
          .doc(threadID)
          .update({'isTrash': false});

      // Delete from trashMails
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('trashMails')
          .doc(threadID)
          .delete();

      // Show success message
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Email restored successfully'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      // Revert UI if error occurs
      setState(() {
        trashedMails.insert(index, mailToRestore);
      });
      debugPrint('Error restoring mail: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to restore mail')),
        );
      }
    }
  }

  Future<void> deleteMailPermanently(String? threadID) async {
    if (threadID == null || currentUser == null) return;
    final index = trashedMails.indexWhere((mail) => mail.threadID == threadID);
    if (index == -1) return;

    final mailToDelete = trashedMails[index];

    setState(() {
      trashedMails.removeAt(index);
    });

    try {
      // Lấy type từ trashMails
      final trashDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('trashMails')
          .doc(threadID)
          .get();

      if (!trashDoc.exists) {
        throw Exception('Trash document not found');
      }

      final String type = trashDoc.data()?['type'];
      if (type != 'receiveMails' && type != 'sentMails') {
        throw Exception('Invalid mail type: $type');
      }

      // Kiểm tra trường isDelete trong collection tương ứng
      final mailDoc = await FirebaseFirestore.instance
          .collection('mails')
          .doc(threadID)
          .get();

      if (mailDoc.exists) {
        final mailData = mailDoc.data();
        if (mailData?['isDelete'] != true) {
          // Nếu chưa có isDelete hoặc isDelete là false, đánh dấu isDelete = true
          await FirebaseFirestore.instance
              .collection('mails')
              .doc(threadID)
              .update({'isDelete': true});
        } else {
          // Nếu đã có isDelete = true, xóa các replies trong repliesMails
          final repliesQuery = await FirebaseFirestore.instance
              .collection('repliesMails')
              .where('parentMailId', isEqualTo: threadID)
              .get();

          for (var replyDoc in repliesQuery.docs) {
            await FirebaseFirestore.instance
                .collection('repliesMails')
                .doc(replyDoc.id)
                .delete();
          }

          // Xóa email chính trong collection tương ứng
          await FirebaseFirestore.instance
              .collection('emails')
              .doc(threadID)
              .delete();
        }
      }

      // Xóa email trong collection tương ứng
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection(type)
          .doc(threadID)
          .delete();

      // Xóa email trong trashMails
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('trashMails')
          .doc(threadID)
          .delete();

      // Hiển thị SnackBar khi xóa thành công
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Deleted mail permanently'),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            elevation: 8,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      // Khôi phục UI nếu xảy ra lỗi
      setState(() {
        trashedMails.insert(index, mailToDelete);
      });
      debugPrint('Error deleting mail permanently: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Failed to delete mail permanently'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            elevation: 8,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  void _showTrashAction(BuildContext context, Message mail, int index) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (bottomSheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(Icons.restore,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Restore'),
                onTap: () async {
                  await restoreMail(mail.threadID);
                  Navigator.pop(bottomSheetContext);
                },
              ),
              ListTile(
                leading: Icon(Icons.delete_forever,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Delete Permanently'),
                onTap: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Delete Permanently'),
                      content: const Text(
                          'This email will be permanently deleted. Continue?'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(ctx, false),
                          child: const Text('Cancel'),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(ctx, true),
                          child: const Text(
                            'Delete',
                            style: TextStyle(color: Colors.red),
                          ),
                        ),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    await deleteMailPermanently(mail.threadID);
                    Navigator.pop(bottomSheetContext);
                  }
                },
              ),
              ListTile(
                leading: Icon(Icons.close,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Cancel'),
                onTap: () {
                  Navigator.pop(bottomSheetContext);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  String parseQuillJsonToPlainText(String quillJson) {
    try {
      // Giải mã chuỗi JSON thành List<dynamic>
      final List<dynamic> quillData = jsonDecode(quillJson);

      // Trích xuất nội dung từ các đoạn "insert"
      String plainText = quillData
          .where((element) =>
              element['insert'] != null) // Lọc các phần tử có "insert"
          .map((element) => element['insert'].toString()) // Lấy giá trị insert
          .join(); // Nối thành chuỗi

      // Xóa các ký tự xuống dòng hoặc khoảng trắng thừa nếu cần
      return plainText.trim();
    } catch (e) {
      debugPrint('Error parsing Quill JSON: $e');
      return quillJson; // Trả về chuỗi gốc nếu lỗi
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trash'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: trashedMails.isEmpty
            ? const Center(
                child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.delete, size: 100, color: Colors.grey),
                  SizedBox(width: 30),
                  Text(
                    'No emails in Trash',
                    style: TextStyle(fontSize: 20, color: Colors.grey),
                  ),
                ],
              ))
            : ListView.builder(
                itemCount: trashedMails.length,
                itemBuilder: (context, index) {
                  final mail = trashedMails[index];
                  return GestureDetector(
                    onLongPress: () => _showTrashAction(context, mail, index),
                    child: Container(
                      color: mail.unread
                          ? Colors.grey.withAlpha(20)
                          : Colors.transparent,
                      child: ListTile(
                        leading: mail.avatarUrl != null
                            ? CircleAvatar(
                                radius: 20,
                                backgroundImage:
                                    mail.avatarUrl!.startsWith('http')
                                        ? NetworkImage(mail.avatarUrl!)
                                        : AssetImage(mail.avatarUrl!)
                                            as ImageProvider,
                                onBackgroundImageError: (error, stackTrace) =>
                                    const AssetImage('assets/user.png'),
                              )
                            : const SizedBox(
                                width: 40,
                                height: 40,
                                child:
                                    CircularProgressIndicator(strokeWidth: 2),
                              ),
                        title: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                mail.sender.name,
                                style: TextStyle(
                                  fontWeight: mail.unread
                                      ? FontWeight.bold
                                      : FontWeight.normal,
                                ),
                              ),
                            ),
                            Text(
                              mail.time,
                              style: const TextStyle(
                                  fontSize: 12, color: Colors.grey),
                            ),
                          ],
                        ),
                        subtitle: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    mail.subject,
                                    style: TextStyle(
                                      fontWeight: mail.unread
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                      color: Theme.of(context)
                                          .textTheme
                                          .bodyLarge
                                          ?.color, // Sử dụng màu từ theme
                                    ),
                                  ),
                                  Text(
                                    parseQuillJsonToPlainText(mail.text),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => MailDetail(
                                mailId: mail.threadID!,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
