// ignore_for_file: use_build_context_synchronously

// Dart imports:
import 'dart:convert';
import 'dart:math';

// Flutter imports:
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:logging/logging.dart';

// Project imports:
import 'package:final_project/components/account_switcher.dart';
import 'package:final_project/components/bottom_nav.dart';
import 'package:final_project/components/data_search.dart';
import 'package:final_project/models/message_mode.dart';
import 'package:final_project/models/reply_mode.dart';
import 'package:final_project/models/user_mode.dart' as user_models;
import 'package:final_project/tabs/compose.dart';
import 'package:final_project/tabs/drawer.dart';
import 'package:final_project/tabs/mail_detail.dart';
import 'package:final_project/tabs/profile.dart';

final _logger = Logger('SentMails');

class Sent extends StatefulWidget {
  const Sent({super.key});

  @override
  State<Sent> createState() => _SentState();
}

class _SentState extends State<Sent> {
  List<String> selectedMessageIDs = [];
  bool? isStarred = false;
  List<Message> mails = [];
  List<String> messageID = [];
  final currentUser = FirebaseAuth.instance.currentUser?.uid;
  bool isShow = true;
  final ScrollController _scrollController = ScrollController();
  final GlobalKey<ScaffoldState> _globalKey = GlobalKey<ScaffoldState>();
  String _avatarUrl = 'assets/user.png';
  String currentUserName = '';
  bool _isLoadingAvatar = true;
  final int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    handleScroll();
    loadMailsFromFirebase();
    _loadUserInfo();
  }

  Future<void> _loadUserInfo() async {
    if (!mounted) return;

    setState(() {
      _isLoadingAvatar = true;
    });

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .get();

        if (mounted) {
          setState(() {
            _avatarUrl = doc.data()?['avatarUrl'] ?? 'assets/user.png';
            currentUserName =
                doc.data()?['fullName'] + " " + doc.data()?['lastName'] ??
                    'Người dùng';
            _isLoadingAvatar = false;
          });
        }
      }
    } catch (e) {
      _logger.severe('Lỗi khi tải thông tin người dùng: $e');
      if (mounted) {
        setState(() {
          _avatarUrl = 'assets/user.png';
          _isLoadingAvatar = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Không thể tải thông tin người dùng'),
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  Future<void> loadMailsFromFirebase() async {
    if (currentUser != null) {
      try {
        final queryMessageID = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('sentMails')
            .where('isTrash', isEqualTo: false)
            .orderBy('time', descending: true)
            .get();

        for (var doc in queryMessageID.docs) {
          messageID.add(doc.id);

          final data = doc.data();
          if (data['text'] == null || data['text'] == '') {
            _logger.warning(
                'Warning: "text" field is empty or null for message ID: ${doc.id}');
          }

          final colorValue = data['color']?.toString() ?? '0xFF000000';
          List<Reply> replyList = [];
          if (data['replies'] != null) {
            for (var reply in data['replies']) {
              replyList.add(
                Reply(
                  body: reply['body'] ?? 'No Content',
                  from: reply['from'] ?? 'Unknown Sender',
                  subject: reply['subject'] ?? 'No Subject',
                  time: reply['time'] ?? '',
                  to: reply['to'] ?? 'Unknown Receiver',
                ),
              );
            }
          }
          final loadedMail = Message(
            sender: user_models.AppUser(
              id: mails.length,
              name: "to: " + data['receiver'],
              imageUrl: Color(int.parse(colorValue)),
            ),
            reciever: data['receiver'] ?? 'No Reciever',
            subject: data['subject'] ?? 'No Subject',
            text: data['text'] ?? 'No Content',
            time: DateFormat('hh:mm a').format(DateTime.parse(data['time'])),
            unread: data['unread'] ?? true,
            isStarred: data['isStarred'] ?? false,
            replies: replyList,
            threadID: doc.id,
          );
          setState(() {
            mails.add(loadedMail);
          });
        }
      } catch (e) {
        _logger.severe('Error loading mails: $e');
      }
    }
  }

  Future<void> toggleReadStatus(
      String messageId, bool currentUnreadStatus) async {
    final index = mails.indexWhere((mail) => mail.threadID == messageId);
    if (index == -1) return;

    final mailToUpdate = mails[index];

    setState(() {
      mailToUpdate.unread = !currentUnreadStatus;
      mails[index] = mailToUpdate;
    });

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('sentMails')
          .doc(messageId)
          .update({'unread': !currentUnreadStatus});
      _logger.info(
          'Updated read status for message $messageId to ${!currentUnreadStatus}');
    } catch (e) {
      setState(() {
        mailToUpdate.unread = currentUnreadStatus;
        mails[index] = mailToUpdate;
      });
      _logger.severe('Error updating read status: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Không thể cập nhật trạng thái đọc: $e')),
        );
      }
    }
  }

  // Hàm moveMailToTrash (tái sử dụng từ trước)
  Future<void> moveMailToTrash(String? threadID) async {
    if (threadID == null) return;

    final index = mails.indexWhere((mail) => mail.threadID == threadID);
    if (index == -1) return;

    final mailToMove = mails[index];

    setState(() {
      mails.removeAt(index);
    });

    try {
      final docRef = FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection("sentMails")
          .doc(threadID);

      final mailDoc = await docRef.get();

      // Lấy dữ liệu mail và chỉ giữ các trường cần thiết
      Map<String, dynamic> mailData = mailDoc.data()!;
      final filteredMailData = {
        'color': mailData['color'] ?? 0xFF000000,
        'receiver': mailData['receiver'] ?? '',
        'sender': mailData['sender'] ?? '',
        'senderAvatarUrl': mailData['avatarUrl'] ?? '',
        'subject': mailData['subject'] ?? '',
        'text': mailData['text'] ?? '',
        'time': mailData['time'] ?? Timestamp.now().toDate().toIso8601String(),
        'type': "sentMails",
        'isTrash': true,
      };

      // Lưu vào collection 'trash' với các trường được lọc
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('trashMails')
          .doc(threadID)
          .set(filteredMailData);

      // Cập nhật collection gốc với isTrash
      await docRef.update({'isTrash': true});
    } catch (e) {
      setState(() {
        mails.insert(index, mailToMove);
      });

      _logger.severe('Lỗi khi chuyển email sang thùng rác: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Không thể chuyển email sang thùng rác: $e'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  // Hàm mới: Hiển thị bottom sheet với các hành động email
  void _showEmailAction(BuildContext parentContext, Message mail, int index) {
    showModalBottomSheet(
      context: parentContext,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (BuildContext bottomSheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(
                  mail.isStarred ? Icons.star : Icons.star_border,
                  color: mail.isStarred
                      ? Colors.yellow
                      : Theme.of(context).colorScheme.onSurface,
                ),
                title: Text(
                    mail.isStarred ? 'Mark as Unstarred' : 'Mark as Starred'),
                onTap: () async {
                  toggleisStarred(mail, index);
                  Navigator.pop(bottomSheetContext);
                },
              ),
              ListTile(
                leading: Icon(Icons.label_outline,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Label email'),
                onTap: () async {
                  Navigator.pop(bottomSheetContext);
                  await choseLabel(parentContext, mail.threadID);
                },
              ),
              ListTile(
                leading: Icon(Icons.delete_outline,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Move to Trash'),
                onTap: () async {
                  await moveMailToTrash(mail.threadID);
                  Navigator.pop(bottomSheetContext);
                },
              ),
              ListTile(
                leading: Icon(Icons.close,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Cancel'),
                onTap: () {
                  Navigator.pop(bottomSheetContext);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<bool> checkIfUserExists(String uid) async {
    final userDoc =
        await FirebaseFirestore.instance.collection('users').doc(uid).get();

    return userDoc.exists;
  }

  Future<void> navigateToCompose() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => const Compose(
                isReply: false,
                isDraft: false,
              )),
    );

    if (result != null && result is Map<String, String>) {
      // Lấy thông tin người gửi
      final userName = FirebaseAuth.instance.currentUser?.email ?? 'Anonymous';
      final currentTime = DateTime.now();

      final newMessage = Message(
        sender: user_models.AppUser(
          id: mails.length,
          name: userName,
          imageUrl: getRandomColor(),
        ),
        reciever: result['to'] ?? '',
        subject: result['subject'] ?? '',
        text: result['body'] ?? '',
        time: DateFormat('hh:mm a').format(currentTime),
        unread: true,
        isStarred: false,
      );

      setState(() {
        mails.add(newMessage);
      });

      // Tạo một messageID duy nhất
      final messageID = FirebaseFirestore.instance.collection('mails').doc().id;

      // Lấy UID của người nhận dựa trên email
      final receiverEmail = newMessage.reciever.trim();
      String? receiverUID;
      try {
        final querySnapshot = await FirebaseFirestore.instance
            .collection('users')
            .where('email', isEqualTo: receiverEmail)
            .get();

        if (querySnapshot.docs.isNotEmpty) {
          receiverUID = querySnapshot.docs.first.id;
        } else {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Mail account does not exist!')),
            );
          }
          return;
        }
      } catch (e) {
        return;
      }

      // Lưu mail vào collection 'mails' của cả người gửi và người nhận
      final senderUID = FirebaseAuth.instance.currentUser?.uid ?? '';

      // Lưu mail vào người gửi
      await FirebaseFirestore.instance
          .collection('users')
          .doc(senderUID) // Use UID instead of email
          .collection('mails')
          .doc(messageID) // Sử dụng messageID duy nhất
          .set({
        'messageID': messageID,
        'sender': newMessage.sender.name,
        'receiver': newMessage.reciever,
        'subject': newMessage.subject,
        'text': newMessage.text,
        'time': currentTime.toIso8601String(),
        'isStarred': newMessage.isStarred,
        'unread': newMessage.unread,
        'color': getRandomColor().toARGB32(),
        'replies': [], // Khởi tạo replies rỗng
        'labels': []
      });

      // Lưu mail vào người nhận
      await FirebaseFirestore.instance
          .collection('users')
          .doc(receiverUID) // Use UID for the receiver
          .collection('mails')
          .doc(messageID) // Sử dụng messageID duy nhất
          .set({
        'messageID': messageID,
        'sender': newMessage.sender.name,
        'receiver': newMessage.reciever,
        'subject': newMessage.subject,
        'text': newMessage.text,
        'time': currentTime.toIso8601String(),
        'isStarred': newMessage.isStarred,
        'unread': newMessage.unread,
        'color': getRandomColor().toARGB32(),
        'replies': [], // Khởi tạo replies rỗng
        'labels': []
      });
    }
  }

  Color getRandomColor() {
    final random = Random();
    return Color.fromARGB(
      255,
      random.nextInt(256),
      random.nextInt(256),
      random.nextInt(256),
    );
  }

  void handleScroll() async {
    _scrollController.addListener(() {
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        setState(() {
          isShow = false;
        });
      } else if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        setState(() {
          isShow = true;
        });
      }
    });
  }

  Future<void> loadisStarredStatus(String? threadID) async {
    if (threadID != null) {
      try {
        DocumentSnapshot mailDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('mails')
            .doc(threadID)
            .get();

        if (mailDoc.exists) {
          setState(() {
            isStarred = mailDoc['isStarred'] ?? false;
          });
        }
      } catch (e) {
        _logger.severe('Error loading isStarred status: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Failed to load isStarred status: $e")),
          );
        }
      }
    }
  }

  void toggleisStarred(Message mail, int index) async {
    if (mail.threadID != null) {
      mail.isStarred = !mail.isStarred;

      // Cập nhật Firestore
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('sentMails')
          .doc(mail.threadID)
          .update({'isStarred': mail.isStarred});

      // Cập nhật danh sách và UI
      setState(() {
        mails[index] = mail; // Cập nhật danh sách
      });
    }
  }

  Future<void> choseLabel(BuildContext context, String? threadID) async {
    if (!mounted) return;

    final currentUser = FirebaseAuth.instance.currentUser?.uid;
    List<String> allLabels = [];
    List<String> selectedLabels = [];

    try {
      var snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .get();
      if (snapshot.exists) {
        allLabels = List<String>.from(snapshot.data()?['labels'] ?? []);
      }

      var mailDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('mails')
          .doc(threadID)
          .get();

      if (mailDoc.exists) {
        List<dynamic> labelsFromFirestore = mailDoc['labels'] ?? [];
        selectedLabels = List<String>.from(labelsFromFirestore);
      }
    } catch (e) {
      _logger.severe('Error loading labels: $e');
      return;
    }

    if (!mounted) return;

    final BuildContext currentContext = context;
    showDialog(
      context: currentContext,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return AlertDialog(
              title: const Text(
                'Assign Labels to Email',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              content: SingleChildScrollView(
                child: ListBody(
                  children: allLabels.map((label) {
                    return CheckboxListTile(
                      activeColor: Colors.blueAccent,
                      title: Text(label),
                      value: selectedLabels.contains(label),
                      onChanged: (bool? selected) {
                        setState(() {
                          if (selected == true) {
                            selectedLabels.add(label);
                          } else {
                            selectedLabels.remove(label);
                          }
                        });
                      },
                    );
                  }).toList(),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(ctx).pop();
                  },
                  child: const Text('Cancel',
                      style: TextStyle(color: Colors.black)),
                ),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onPressed: () async {
                    try {
                      await FirebaseFirestore.instance
                          .collection('users')
                          .doc(currentUser)
                          .collection('mails')
                          .doc(threadID)
                          .update({
                        'labels': selectedLabels,
                      });
                      if (!mounted) return;
                      Navigator.of(ctx).pop();
                    } catch (e) {
                      _logger.severe('Error saving labels: $e');
                      if (!mounted) return;
                      ScaffoldMessenger.of(currentContext).showSnackBar(
                        SnackBar(content: Text('Failed to save labels: $e')),
                      );
                    }
                  },
                  label: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  String parseQuillJsonToPlainText(String quillJson) {
    try {
      // Giải mã chuỗi JSON thành List<dynamic>
      final List<dynamic> quillData = jsonDecode(quillJson);

      // Trích xuất nội dung từ các đoạn "insert"
      String plainText = quillData
          .where((element) =>
              element['insert'] != null) // Lọc các phần tử có "insert"
          .map((element) => element['insert'].toString()) // Lấy giá trị insert
          .join(); // Nối thành chuỗi

      // Xóa các ký tự xuống dòng hoặc khoảng trắng thừa nếu cần
      return plainText.trim();
    } catch (e) {
      debugPrint('Error parsing Quill JSON: $e');
      return quillJson; // Trả về chuỗi gốc nếu lỗi
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const Drawers(),
      key: _globalKey,
      body: SafeArea(
        child: Column(
          children: [
            // Custom AppBar with rounded search bar and avatar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  Builder(
                    builder: (context) => IconButton(
                      icon: const Icon(Icons.menu, size: 28),
                      onPressed: () => Scaffold.of(context).openDrawer(),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      height: 40,
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 225, 224, 224),
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(24),
                        onTap: () {
                          if (currentUser != null) {
                            showSearch(
                              context: context,
                              delegate: Datasearch(currentUser: currentUser!),
                            );
                          }
                        },
                        child: const Row(
                          children: [
                            SizedBox(width: 12),
                            Icon(Icons.search,
                                color: Color.fromARGB(255, 55, 55, 55)),
                            SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Search in mail',
                                style: TextStyle(
                                    color: Color.fromARGB(255, 55, 55, 55),
                                    fontSize: 16),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  _buildAvatar(),
                ],
              ),
            ),
            // Sent label
            const Padding(
              padding: EdgeInsets.only(left: 18, top: 8, bottom: 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Sent',
                  style: TextStyle(color: Colors.grey, fontSize: 13),
                ),
              ),
            ),
            // Email list
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                itemCount: mails.length,
                itemBuilder: (context, index) {
                  final mail = mails[index];
                  return Container(
                    color: mail.unread
                        ? Colors.grey.withAlpha(20)
                        : Colors.transparent,
                    child: ListTile(
                      leading: _isLoadingAvatar
                          ? const SizedBox(
                              width: 40,
                              height: 40,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : UserAvatar(avatarUrl: _avatarUrl),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              mail.sender.name,
                              style: const TextStyle(
                                  fontWeight: FontWeight.normal),
                            ),
                          ),
                          Text(
                            mail.time,
                            style: const TextStyle(
                                fontSize: 12, color: Colors.grey),
                          ),
                        ],
                      ),
                      subtitle: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  mail.subject,
                                  style: TextStyle(
                                    fontWeight: mail.unread
                                        ? FontWeight.bold
                                        : FontWeight.normal,
                                    color: Theme.of(context)
                                        .textTheme
                                        .bodyLarge
                                        ?.color, // Sử dụng màu từ theme
                                  ),
                                ),
                                Text(
                                  parseQuillJsonToPlainText(mail.text),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: Icon(
                              mail.isStarred ? Icons.star : Icons.star_border,
                              color:
                                  mail.isStarred ? Colors.yellow : Colors.grey,
                            ),
                            onPressed: () {
                              toggleisStarred(mail, index);
                            },
                          ),
                        ],
                      ),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => MailDetail(
                            mailId: mail.threadID!,
                          ),
                        ),
                      ),
                      onLongPress: () {
                        _showEmailAction(context, mail, index);
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: isShow
          ? FloatingActionButton.extended(
              onPressed: navigateToCompose,
              label: const Text('Compose'),
              icon: const Icon(Icons.edit_outlined),
              foregroundColor: Colors.black,
              backgroundColor: const Color.fromARGB(255, 203, 236, 252),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24)),
            )
          : null,
      bottomNavigationBar: BottomNavigation(
        currentIndex: _currentIndex,
      ),
    );
  }

  Widget _buildAvatar() {
    if (_isLoadingAvatar) {
      return Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.grey.shade300, width: 2),
        ),
        child: const SizedBox(
          width: 40,
          height: 40,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      );
    }

    return GestureDetector(
      onTap: () {
        showDialog(
          context: context,
          builder: (context) => AccountSwitcher(
            mainName: currentUserName,
            mainEmail:
                FirebaseAuth.instance.currentUser?.email ?? 'user@example.com',
            mainAvatarUrl: _avatarUrl,
            otherAccounts: const [],
            onManageAccount: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ProfileScreen(),
                ),
              );
            },
            onAddAccount: () {},
            onManageDevice: () {},
            storagePercent: 0.75,
            storageText: '75% used',
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.grey.shade300, width: 2),
        ),
        child: UserAvatar(avatarUrl: _avatarUrl),
      ),
    );
  }
}
