// Dart imports:
import 'dart:ui' as ui;

// Flutter imports:
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:intl/intl.dart';
import 'package:simple_icons/simple_icons.dart';

class ControllerKeys {
  static const password = 'password';
  static const confirmPassword = 'confirmPassword';
  static const email = 'email';
  static const fullName = 'fullName';
  static const lastName = 'lastName';
  static const dob = 'dob';
  static const phone = 'phone';
}

class RegisterPage extends StatefulWidget {
  final Function()? onTap;
  const RegisterPage({super.key, required this.onTap});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final Map<String, TextEditingController> _controllers = {
    ControllerKeys.email: TextEditingController(),
    ControllerKeys.fullName: TextEditingController(),
    ControllerKeys.lastName: TextEditingController(),
    ControllerKeys.dob: TextEditingController(),
    ControllerKeys.phone: TextEditingController(),
    ControllerKeys.password: TextEditingController(),
    ControllerKeys.confirmPassword: TextEditingController(),
  };
  String? _errorMessage;
  bool _isPasswordVisible = false;
  bool _isConfirmPasswordVisible = false;
  TextEditingController getController(String key) {
    return _controllers[key]!;
  }

  @override
  void dispose() {
    for (var controller in _controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  String generateAvatar(String fullName) {
    return fullName.isNotEmpty ? fullName.trim()[0].toUpperCase() : 'A';
  }

  Future<String> uploadAvatar(String fullName) async {
    if (fullName.isEmpty) {
      if (kDebugMode) debugPrint("Error: Empty fullName");
      return "";
    }

    try {
      final avatarLetter = generateAvatar(fullName);
      if (kDebugMode) debugPrint("Avatar letter: $avatarLetter");

      final pictureRecorder = ui.PictureRecorder();
      final canvas = Canvas(pictureRecorder);
      const size = 100.0;
      canvas.drawRect(const Rect.fromLTWH(0, 0, size, size),
          Paint()..color = Colors.blueAccent);

      final textPainter = TextPainter(
        text: TextSpan(
          text: avatarLetter,
          style: const TextStyle(
              color: Colors.white, fontSize: 40, fontWeight: FontWeight.bold),
        ),
        textDirection: ui.TextDirection.ltr,
      )..layout(maxWidth: size);


      textPainter.paint(
          canvas,
          Offset(
              (size - textPainter.width) / 2, (size - textPainter.height) / 2));

      final img = await pictureRecorder
          .endRecording()
          .toImage(size.toInt(), size.toInt());
      final byteData = await img.toByteData(format: ui.ImageByteFormat.png);
      final pngBytes = byteData!.buffer.asUint8List();

      final storageReference =
          FirebaseStorage.instance.ref().child('avatars/$fullName.png');
      if (kDebugMode) {
        debugPrint("Storage path: avatars/$fullName.png");
      }

      final uploadTask = await storageReference.putData(pngBytes);
      if (kDebugMode) {
        debugPrint("Upload complete: ${uploadTask.metadata?.fullPath}");
      }

      return await storageReference.getDownloadURL();
    } catch (e) {
      if (kDebugMode) debugPrint("Error uploading avatar: $e");
      return "";
    }
  }

  Future<void> initiatePhoneVerification() async {
    final password = _controllers[ControllerKeys.password]?.text.trim();
    final confirmPassword =
        _controllers[ControllerKeys.confirmPassword]?.text.trim();
    final userMail = _controllers[ControllerKeys.email]?.text.trim();
    final fullName = _controllers[ControllerKeys.fullName]?.text.trim();
    final lastName = _controllers[ControllerKeys.lastName]?.text.trim();
    final dob = _controllers[ControllerKeys.dob]?.text.trim();
    final phone = _controllers[ControllerKeys.phone]?.text.trim();

    if ((userMail?.isEmpty ?? true) ||
        (fullName?.isEmpty ?? true) ||
        (lastName?.isEmpty ?? true) ||
        (dob?.isEmpty ?? true) ||
        (phone?.isEmpty ?? true) ||
        (password?.isEmpty ?? true) ||
        (confirmPassword?.isEmpty ?? true)) {
      setState(() {
        _errorMessage = 'Please enter complete information!';
      });
      return;
    }

    if (!RegExp(r'^(?=.*[A-Z])(?=.*[!@#$%^&*(),.?":{}|<>]).{8,}$')
        .hasMatch(password!)) {
      setState(() {
        _errorMessage =
            'Password must be at least 8 characters, include 1 uppercase letter and 1 special character!';
      });
      return;
    }

    // Kiểm tra mật khẩu trùng khớp
    if (password != confirmPassword) {
      setState(() {
        _errorMessage = 'Passwords do not match!';
      });
      return;
    }

    // Kiểm tra định dạng số điện thoại
    if (!RegExp(r'^\+[1-9]\d{1,14}$').hasMatch(phone!)) {
      setState(() {
        _errorMessage =
            'Invalid phone number format! Use +[country code][number]';
      });
      return;
    }

    setState(() {
      _errorMessage = null;
    });

    try {
      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: phone,
        verificationCompleted: (PhoneAuthCredential credential) async {
          // Auto-verification for test numbers
          await FirebaseAuth.instance.signInWithCredential(credential);
          await _saveUserData(
              phone, userMail!, fullName!, lastName!, dob!, password);
          if (mounted) {
            Navigator.pop(context); // Quay lại màn hình trước hoặc trang chính
          }
        },
        verificationFailed: (FirebaseAuthException e) {
          setState(() {
            _errorMessage = 'Verification failed: ${e.message}';
          });
        },
        codeSent: (String verificationId, int? resendToken) {
          setState(() {});
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => OTPVerificationPage(
                phone: phone,
                verificationId: verificationId,
                userData: {
                  'email': userMail!,
                  'fullName': fullName!,
                  'lastName': lastName!,
                  'dob': dob!,
                  'phone': phone,
                  'password': password, // Lưu mật khẩu vào userData để liên kết
                },
                uploadAvatar: uploadAvatar,
              ),
            ),
          );
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          setState(() {});
        },
      );
    } catch (e) {
      setState(() {
        _errorMessage = 'Error: ${e.toString()}';
      });
    }
  }

  Future<void> _saveUserData(String phone, String email, String fullName,
      String lastName, String dob, String password) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final avatarUrl = await uploadAvatar(fullName);
        final userDoc =
            FirebaseFirestore.instance.collection('users').doc(user.uid);
        await userDoc.set({
          'fullName': fullName,
          'lastName': lastName,
          'dob': dob,
          'phone': phone,
          'email': email,
          'avatarUrl': avatarUrl,
          'isTwoFactorEnabled': false,
          'isNotificationEnabled': false,
        });
      }
    } catch (e) {
      if (kDebugMode) debugPrint("Error saving user data: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    InputDecoration fieldDecoration(String label, {Widget? suffixIcon}) {
      return InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.black),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.black, width: 1),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.black, width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.blueAccent, width: 2),
        ),
        suffixIcon: suffixIcon,
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 40),
                  const Center(
                    child: Column(
                      children: [
                        Icon(SimpleIcons.gmail, size: 50, color: Colors.black),
                        SizedBox(height: 20),
                        Text(
                          "Create your account",
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w400,
                            color: Colors.black,
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          "to continue",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 40),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _controllers[ControllerKeys.fullName]!,
                          decoration: fieldDecoration('Name'),
                          style: const TextStyle(color: Colors.black),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: _controllers[ControllerKeys.lastName]!,
                          decoration: fieldDecoration('Surname'),
                          style: const TextStyle(color: Colors.black),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _controllers[ControllerKeys.email]!,
                    decoration: fieldDecoration('Email'),
                    style: const TextStyle(color: Colors.black),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _controllers[ControllerKeys.password],
                    decoration: fieldDecoration(
                      'Password',
                      suffixIcon: IconButton(
                        icon: Icon(
                          _isPasswordVisible
                              ? Icons.visibility
                              : Icons.visibility_off,
                          color: Colors.black,
                        ),
                        onPressed: () {
                          setState(() {
                            _isPasswordVisible = !_isPasswordVisible;
                          });
                        },
                      ),
                    ),
                    obscureText: !_isPasswordVisible,
                    style: const TextStyle(color: Colors.black),
                  ),
                  const SizedBox(height: 5),
                  const Text(
                    'At least 8 characters, including 1 uppercase letter and 1 special character',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _controllers[ControllerKeys.confirmPassword],
                    decoration: fieldDecoration(
                      'Confirm password',
                      suffixIcon: IconButton(
                        icon: Icon(
                          _isConfirmPasswordVisible
                              ? Icons.visibility
                              : Icons.visibility_off,
                          color: Colors.black,
                        ),
                        onPressed: () {
                          setState(() {
                            _isConfirmPasswordVisible =
                                !_isConfirmPasswordVisible;
                          });
                        },
                      ),
                    ),
                    obscureText: !_isConfirmPasswordVisible,
                    style: const TextStyle(color: Colors.black),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _controllers[ControllerKeys.dob]!,
                    decoration: fieldDecoration('Date of Birth',
                        suffixIcon: const Icon(Icons.calendar_today,
                            color: Colors.black)),
                    style: const TextStyle(color: Colors.black),
                    readOnly: true,
                    onTap: () async {
                      DateTime? pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(1900),
                        lastDate: DateTime.now(),
                        builder: (context, child) {
                          return Theme(
                            data: Theme.of(context).copyWith(
                              colorScheme: const ColorScheme.light(
                                primary: Colors.blue,
                                onPrimary: Colors.white,
                                onSurface: Colors.black,
                              ),
                              textButtonTheme: TextButtonThemeData(
                                style: TextButton.styleFrom(
                                  foregroundColor: Colors.blue,
                                ),
                              ),
                            ),
                            child: child!,
                          );
                        },
                      );

                      if (pickedDate != null) {
                        String formattedDate =
                            DateFormat('dd/MM/yyyy').format(pickedDate);
                        setState(() {
                          _controllers[ControllerKeys.dob]!.text =
                              formattedDate;
                        });
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _controllers[ControllerKeys.phone]!,
                    decoration:
                        fieldDecoration('Phone number (e.g. +12025550123)'),
                    style: const TextStyle(color: Colors.black),
                    keyboardType: TextInputType.phone,
                  ),
                  const SizedBox(height: 5),
                  const SizedBox(height: 10),
                  if (_errorMessage != null)
                    Text(
                      _errorMessage!,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.red,
                      ),
                    ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(
                        onPressed: widget.onTap,
                        child: const Text(
                          'Sign in',
                          style: TextStyle(
                            color: Colors.blueAccent,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: initiatePhoneVerification,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blueAccent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 12,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text('Next'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class OTPVerificationPage extends StatefulWidget {
  final String phone;
  final String verificationId;
  final Map<String, String> userData;
  final Future<String> Function(String) uploadAvatar;

  const OTPVerificationPage({
    super.key,
    required this.phone,
    required this.verificationId,
    required this.userData,
    required this.uploadAvatar,
  });

  @override
  State<OTPVerificationPage> createState() => _OTPVerificationPageState();
}

class _OTPVerificationPageState extends State<OTPVerificationPage> {
  final List<TextEditingController> _otpControllers =
      List.generate(6, (index) => TextEditingController());
  final List<FocusNode> _focusNodes = List.generate(6, (index) => FocusNode());
  String? _errorMessage;

  @override
  void dispose() {
    for (var controller in _otpControllers) {
      controller.dispose();
    }
    for (var focusNode in _focusNodes) {
      focusNode.dispose();
    }
    super.dispose();
  }

  Future<void> _verifyOTP() async {
    final otp = _otpControllers.map((controller) => controller.text).join();
    if (otp.length != 6) {
      setState(() {
        _errorMessage = 'Please enter a valid 6-digit OTP!';
      });
      return;
    }

    showDialog(
      context: context,
      builder: (context) => const Center(child: CircularProgressIndicator()),
    );

    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: widget.verificationId,
        smsCode: otp,
      );
      await FirebaseAuth.instance.signInWithCredential(credential);
      await _saveUserData();
      if (mounted) {
        Navigator.pop(context); // Đóng dialog loading
        Navigator.pop(context); // Quay lại màn hình trước hoặc trang chính
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context); // Đóng dialog loading
      }
      setState(() {
        _errorMessage = 'Invalid OTP or error: ${e.toString()}';
      });
    }
  }

  Future<void> _saveUserData() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        // Kiểm tra xem email đã tồn tại chưa
        final email = widget.userData['email']!;
        final signInMethods =
            await FirebaseAuth.instance.fetchSignInMethodsForEmail(email);
        if (signInMethods.isNotEmpty) {
          if (mounted) {
            setState(() {
              _errorMessage = 'Email đã được sử dụng bởi tài khoản khác!';
            });
          }
          return;
        }

        // Liên kết email và mật khẩu
        final password = widget.userData['password']!;
        final credential = EmailAuthProvider.credential(
          email: email,
          password: password,
        );

        try {
          await user.linkWithCredential(credential);
          if (kDebugMode) {
            debugPrint("Email đã được liên kết thành công: $email");
          }
        } catch (e) {
          if (kDebugMode) {
            debugPrint("Lỗi khi liên kết email: $e");
          }
          if (mounted) {
            setState(() {
              _errorMessage = 'Lỗi khi liên kết email: ${e.toString()}';
            });
          }
          return;
        }

        // Tải lên avatar và lấy URL
        final avatarUrl =
            await widget.uploadAvatar(widget.userData['fullName']!);

        // Lưu thông tin người dùng vào Firestore
        final userDoc =
            FirebaseFirestore.instance.collection('users').doc(user.uid);
        await userDoc.set({
          'fullName': widget.userData['fullName'],
          'lastName': widget.userData['lastName'],
          'dob': widget.userData['dob'],
          'phone': widget.userData['phone'],
          'email': widget.userData['email'],
          'avatarUrl': avatarUrl,
          'isTwoFactorEnabled': false,
          'isNotificationEnabled': false,
        });

        if (kDebugMode) {
          debugPrint("Dữ liệu người dùng đã được lưu vào Firestore");
        }
      } else {
        if (mounted) {
          setState(() {
            _errorMessage = 'Không tìm thấy người dùng hiện tại!';
          });
        }
      }
    } catch (e) {
      if (kDebugMode) {
        debugPrint("Lỗi khi lưu dữ liệu người dùng: $e");
      }
      if (mounted) {
        setState(() {
          _errorMessage = 'Lỗi khi lưu dữ liệu: ${e.toString()}';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
        title: const Text(
          "Enter OTP",
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.w500),
        ),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Enter the OTP code sent to ${widget.phone}",
              style: const TextStyle(fontSize: 16, color: Colors.black),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(6, (index) {
                return SizedBox(
                  width: 50,
                  child: TextField(
                    controller: _otpControllers[index],
                    focusNode: _focusNodes[index],
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    maxLength: 1,
                    style: const TextStyle(fontSize: 24, color: Colors.black),
                    decoration: InputDecoration(
                      counterText: "",
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide:
                            const BorderSide(color: Colors.black, width: 1),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide:
                            const BorderSide(color: Colors.black, width: 1),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(
                            color: Colors.blueAccent, width: 2),
                      ),
                    ),
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    onChanged: (value) {
                      if (value.isNotEmpty && index < 5) {
                        _focusNodes[index + 1].requestFocus();
                      } else if (value.isEmpty && index > 0) {
                        _focusNodes[index - 1].requestFocus();
                      }
                    },
                  ),
                );
              }),
            ),
            const SizedBox(height: 20),
            if (_errorMessage != null)
              Text(
                _errorMessage!,
                style: const TextStyle(
                  fontSize: 14,
                  color: Colors.red,
                ),
              ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _verifyOTP,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text("Confirm OTP"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
