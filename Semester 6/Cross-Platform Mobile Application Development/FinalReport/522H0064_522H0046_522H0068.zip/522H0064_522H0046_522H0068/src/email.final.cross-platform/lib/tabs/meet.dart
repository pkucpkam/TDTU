// Flutter imports:
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' as carousel;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// Package imports:
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart' as carousel;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:share_plus/share_plus.dart';

// Project imports:
import 'package:final_project/components/bottom_nav.dart';
import 'package:final_project/tabs/join_meet.dart';
import 'package:final_project/tabs/privacy_policy.dart';
import 'package:final_project/tabs/profile.dart';
import 'package:final_project/tabs/terms_of_service.dart';
import 'drawer.dart';

typedef AvatarSize = double;

class UserAvatar extends StatelessWidget {
  final String? avatarUrl;
  final AvatarSize radius;
  final String? assetFallback;
  const UserAvatar({
    super.key,
    this.avatarUrl,
    this.radius = 20,
    this.assetFallback = 'assets/user.png',
  });

  @override
  Widget build(BuildContext context) {
    if (avatarUrl != null &&
        avatarUrl!.isNotEmpty &&
        avatarUrl!.startsWith('http')) {
      return CircleAvatar(
        backgroundImage: CachedNetworkImageProvider(avatarUrl!),
        radius: radius,
      );
    } else {
      return CircleAvatar(
        backgroundImage: AssetImage(assetFallback!),
        radius: radius,
      );
    }
  }
}

class AccountSwitcher extends StatelessWidget {
  final String mainName;
  final String mainEmail;
  final String? mainAvatarUrl;
  final List<Map<String, String>> otherAccounts;
  final VoidCallback? onManageAccount;
  final VoidCallback? onAddAccount;
  final VoidCallback? onManageDevice;
  final double storagePercent;
  final String storageText;
  const AccountSwitcher({
    super.key,
    required this.mainName,
    required this.mainEmail,
    this.mainAvatarUrl,
    this.otherAccounts = const [],
    this.onManageAccount,
    this.onAddAccount,
    this.onManageDevice,
    this.storagePercent = 0.0,
    this.storageText = '',
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Image.asset('assets/google.png', height: 32),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: UserAvatar(avatarUrl: mainAvatarUrl, radius: 22),
              title: Text(mainName,
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(mainEmail),
              trailing: const Icon(Icons.check, color: Colors.blueAccent),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
              child: OutlinedButton(
                onPressed: onManageAccount,
                style: OutlinedButton.styleFrom(
                  shape: const StadiumBorder(),
                  side: const BorderSide(color: Colors.grey),
                  padding:
                      const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                ),
                child: const Text('Manage your account'),
              ),
            ),
            if (storageText.isNotEmpty)
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
                child: Row(
                  children: [
                    const Icon(Icons.cloud_outlined,
                        size: 20, color: Colors.grey),
                    const SizedBox(width: 8),
                    Expanded(
                      child: LinearProgressIndicator(
                        value: storagePercent,
                        minHeight: 6,
                        backgroundColor: Colors.grey[200],
                        color: Colors.blueAccent,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(storageText, style: const TextStyle(fontSize: 12)),
                  ],
                ),
              ),
            const Divider(),
            ...otherAccounts.map((acc) => ListTile(
                  leading: UserAvatar(avatarUrl: acc['avatarUrl'], radius: 22),
                  title: Text(acc['name'] ?? '',
                      style: const TextStyle(fontWeight: FontWeight.w500)),
                  subtitle: Text(acc['email'] ?? ''),
                  onTap: () {},
                )),
            ListTile(
              leading: const Icon(Icons.person_add_alt, color: Colors.black54),
              title: const Text('Add another account'),
              onTap: onAddAccount,
            ),
            ListTile(
              leading: const Icon(Icons.settings, color: Colors.black54),
              title: const Text('Manage accounts on this device'),
              onTap: onManageDevice,
            ),
            const Divider(),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const PrivacyPolicyScreen(),
                        ),
                      );
                    },
                    child: const Text('Privacy Policy',
                        style: TextStyle(fontSize: 12)),
                  ),
                  const SizedBox(width: 8),
                  const Text('•', style: TextStyle(fontSize: 12)),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const TermsOfServiceScreen(),
                        ),
                      );
                    },
                    child: const Text('Terms of Service',
                        style: TextStyle(fontSize: 12)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Meet extends StatefulWidget {
  const Meet({super.key});

  @override
  MeetState createState() => MeetState();
}

class MeetState extends State<Meet> {
  final carousel.CarouselController buttonCarouselController =
      carousel.CarouselController();
  int currentIndex = 0;
  final List<String> imgs = [
    'assets/meeting.png',
    'assets/conversation.png',
  ];
  String? _avatarUrl;

  @override
  void initState() {
    super.initState();
    _loadUserAvatarUrl();
  }

  Future<void> _loadUserAvatarUrl() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      setState(() {
        _avatarUrl = doc.data()?['avatarUrl'] ?? 'assets/user.png';
      });
    } else {
      setState(() {
        _avatarUrl = 'assets/user.png';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: const Drawers(),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.white,
          iconTheme: const IconThemeData(color: Colors.black),
          title: const Text(
            'Meet',
            style: TextStyle(color: Colors.black),
          ),
          centerTitle: true,
          actions: <Widget>[
            GestureDetector(
              onTap: () {
                showDialog(
                  context: context,
                  builder: (context) => AccountSwitcher(
                    mainName: 'John Doe',
                    mainEmail: 'john.doe@gmail.com',
                    mainAvatarUrl: _avatarUrl,
                    onManageAccount: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ProfileScreen(),
                        ),
                      );
                    },
                    onAddAccount: () {},
                    onManageDevice: () {},
                    storagePercent: 0.75,
                    storageText: '75% used',
                  ),
                );
              },
              child: Container(
                padding: const EdgeInsets.all(2),
                margin: const EdgeInsets.only(right: 16),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.grey.shade300, width: 2),
                ),
                child: UserAvatar(avatarUrl: _avatarUrl),
              ),
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            color: Colors.white,
            child: Column(
              children: [
                const SizedBox(height: 15),
                Row(
                  children: [
                    const SizedBox(width: 15),
                    Expanded(
                      child: TextButton(
                        style: TextButton.styleFrom(
                          padding: const EdgeInsets.all(4),
                          backgroundColor: Colors.blue,
                          foregroundColor: Colors.white,
                          elevation: 40,
                          shape: RoundedRectangleBorder(
                            side: const BorderSide(
                              color: Colors.grey,
                              width: 1,
                              style: BorderStyle.solid,
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        onPressed: () {
                          _showModalBottomSheet(context);
                        },
                        child: const Text(
                          'New Meeting',
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 14,
                              letterSpacing: 2),
                        ),
                      ),
                    ),
                    const SizedBox(width: 15),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Join()),
                          );
                          if (kDebugMode) {}
                        },
                        style: OutlinedButton.styleFrom(
                          backgroundColor: Colors.white,
                          minimumSize: const Size(0, 40),
                          side: const BorderSide(
                            color: Colors.grey,
                            width: 1,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: Text(
                          'Join with a code',
                          style: TextStyle(
                            color: Colors.blue[700],
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 15),
                  ],
                ),
                carousel.CarouselSlider(
                  items: [
                    Column(
                      children: [
                        Container(
                          margin: const EdgeInsets.only(top: 100.0),
                          alignment: Alignment.center,
                          height: 200,
                          width: 200,
                          decoration: const BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage('assets/getALink.png'),
                              fit: BoxFit.fill,
                            ),
                            shape: BoxShape.circle,
                          ),
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(
                                width: 200,
                                child: Text(
                                  "Get a link you can share",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 25.0),
                                  textAlign: TextAlign.center,
                                )),
                            const SizedBox(height: 8),
                            SizedBox(
                              width: 250,
                              child: Text(
                                "Tap New meeting to get a link you can send to people you want to meet with",
                                style: TextStyle(
                                    color: Colors.grey[700], fontSize: 15.0),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Column(
                      children: [
                        Container(
                          margin: const EdgeInsets.only(top: 100.0),
                          alignment: Alignment.center,
                          height: 200,
                          width: 200,
                          decoration: const BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage('assets/meetingSafe.png'),
                              fit: BoxFit.fill,
                            ),
                            shape: BoxShape.circle,
                          ),
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(
                                width: 200,
                                child: Text(
                                  "Your meeting is safe",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 25.0),
                                  textAlign: TextAlign.center,
                                )),
                            const SizedBox(
                              height: 8,
                            ),
                            SizedBox(
                                width: 250,
                                child: Text(
                                  "No one can join the meeting unless invited or admitted by the host",
                                  style: TextStyle(
                                      color: Colors.grey[700], fontSize: 15.0),
                                  textAlign: TextAlign.center,
                                ))
                          ],
                        ),
                      ],
                    ),
                  ],
                  options: carousel.CarouselOptions(
                    height: 500,
                    enableInfiniteScroll: true,
                    autoPlay: true,
                    autoPlayInterval: const Duration(seconds: 3),
                    autoPlayAnimationDuration:
                        const Duration(milliseconds: 800),
                    autoPlayCurve: Curves.fastOutSlowIn,
                    enlargeCenterPage: true,
                    enlargeFactor: 0.2,
                    viewportFraction: 0.8,
                    onPageChanged: (index, reason) {
                      setState(() {
                        currentIndex = index;
                      });
                    },
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                      imgs.length,
                      (index) => Container(
                            width: 10.0,
                            height: 10.0,
                            margin: const EdgeInsets.symmetric(
                                vertical: 0.0, horizontal: 4.0),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: currentIndex == index
                                  ? Colors.black
                                  : Colors.blueAccent,
                            ),
                          )),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
        bottomNavigationBar: const BottomNavigation(
          currentIndex: 1, // 1 represents the Meet tab
        ));
  }

  void _showModalBottomSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      builder: (context) {
        return const BottomSheetContent();
      },
    );
  }
}

class BottomSheetContent extends StatelessWidget {
  const BottomSheetContent({super.key});

  static const String link = 'https://meet.google.com/zpu-dyqi-wkn';

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 250,
      color: Colors.transparent,
      child: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.link, color: Colors.black),
            title: const Text('Get a meeting link to share'),
            onTap: () => showAlertDialog(context),
          ),
          const ListTile(
            leading: Icon(Icons.video_call, color: Colors.black),
            title: Text('Start an instant meeting'),
          ),
          const ListTile(
            leading: Icon(Icons.calendar_today_rounded, color: Colors.black),
            title: Text('Schedule in Google Calendar'),
          ),
          ListTile(
            leading: const Icon(Icons.close_rounded, color: Colors.black),
            title: const Text('Close'),
            onTap: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }

  void showAlertDialog(BuildContext context) {
    final Widget shareButton = TextButton.icon(
      onPressed: () async {
        await _onShareData(context);
      },
      icon: const Icon(Icons.share),
      label: const Text('Share'),
      style: TextButton.styleFrom(
        padding: const EdgeInsets.all(10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: const BorderSide(color: Colors.blue),
        ),
      ),
    );

    showDialog(
      context: context,
      builder: (BuildContext context) {
        var width = MediaQuery.of(context).size.width;
        return AlertDialog(
          contentPadding: const EdgeInsets.fromLTRB(24, 20, 24, 2),
          title: const Text(
            'Here is the link to your meeting',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),
          content: SizedBox(
            height: 200,
            width: width,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    link,
                    maxLines: 3,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 14, color: Colors.black),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.copy, color: Colors.blue),
                      onPressed: () async {
                        await Clipboard.setData(
                            const ClipboardData(text: link));
                        if (context.mounted) {
                          final snackBar = SnackBar(
                            content: const Text('Copied to Clipboard'),
                            action: SnackBarAction(
                              label: 'Undo',
                              onPressed: () {},
                            ),
                          );
                          ScaffoldMessenger.of(context).showSnackBar(snackBar);
                        }
                      },
                    ),
                    const SizedBox(width: 10),
                    shareButton,
                  ],
                ),
              ],
            ),
          ),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(15)),
          ),
        );
      },
    );
  }

  Future<void> _onShareData(BuildContext context) async {
    await Share.share(link);
  }
}
