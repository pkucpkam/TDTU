// Flutter imports:
import 'package:flutter/material.dart';

class Label {
  String? id;
  String? name;
  Label({this.id, this.name});
}

class LabelManager extends StatefulWidget {
  const LabelManager({super.key});

  @override
  State<LabelManager> createState() => _LabelManagerState();
}

class _LabelManagerState extends State<LabelManager> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //  body: _children[current_Index],
      bottomNavigationBar: BottomNavigationBar(
        fixedColor: Colors.black,
        // onTap: () {},
        // currentIndex: current_Index,
        items: [
          BottomNavigationBarItem(
            icon: Padding(
              padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0),
              child: Stack(
                children: <Widget>[
                  const Icon(
                    Icons.mail,
                    size: 35,
                  ),
                  Positioned(
                    right: 0,
                    top: 0.0,
                    child: Container(
                      padding: const EdgeInsets.all(1),
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      constraints: const BoxConstraints(
                        minWidth: 15,
                        minHeight: 15,
                      ),
                      child: const Text(
                        '9+',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                ],
              ),
            ),
            label: 'Mail',
          ),
          const BottomNavigationBarItem(
            icon: Icon(Icons.video_call, size: 35.0),
            label: 'Meet',
          )
        ],
      ),
    );
  }
}
