// Dart imports:
import 'dart:convert';
import 'dart:io';
import 'dart:math';

// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;
import 'package:get/get.dart';

// Project imports:
import 'package:final_project/components/custom_chip_input.dart';
import 'package:final_project/services/email_service.dart';
import 'package:final_project/tabs/front_page.dart';

class ReplyAllScreen extends StatefulWidget {
  final String mailId; // Original mail ID
  final String initialTo; // Original sender
  final String initialSubject;
  final dynamic initialBody; // Supports both plain text and Delta JSON
  final String userMail; // Current user's email
  final String userMailRe; // Original To recipients
  final String? initialCc; // Original CC recipients
  final String? initialBcc; // Original BCC recipients

  const ReplyAllScreen({
    super.key,
    required this.mailId,
    required this.initialTo,
    required this.initialSubject,
    required this.initialBody,
    required this.userMail,
    required this.userMailRe,
    this.initialCc,
    this.initialBcc,
  });

  @override
  ReplyAllScreenState createState() => ReplyAllScreenState();
}

class ReplyAllScreenState extends State<ReplyAllScreen> {
  bool isSent = false;
  bool isSuccessfullySent = false;
  bool isCcBccExpanded = false;
  bool isSubjectFocused = false;
  bool isBodyFocused = false;
  bool isDraftSaved = false;
  String? fromValue;
  List<PlatformFile> files = [];
  final FocusNode subjectFocusNode = FocusNode();
  final FocusNode quillFocusNode = FocusNode();
  final String? currentUser = FirebaseAuth.instance.currentUser?.uid;
  final String? currentUserEmail = FirebaseAuth.instance.currentUser?.email;
  List<String> toEmails = [];
  List<String> ccEmails = [];
  List<String> bccEmails = [];
  final TextEditingController subjectController = TextEditingController();
  late quill.QuillController bodyController;

  @override
  void initState() {
    super.initState();
    _loadUserEmail();
    _initializeRecipients();
    subjectController.text = widget.initialSubject.startsWith('Re: ')
        ? widget.initialSubject
        : 'Re: ${widget.initialSubject}';

    // Initialize QuillController
    if (widget.initialBody != null) {
      if (widget.initialBody is List<dynamic>) {
        bodyController = quill.QuillController(
          document:
              quill.Document.fromJson(widget.initialBody as List<dynamic>),
          selection: const TextSelection.collapsed(offset: 0),
        );
      } else {
        bodyController = quill.QuillController(
          document: quill.Document()..insert(0, ''),
          selection: const TextSelection.collapsed(offset: 0),
        );
      }
    } else {
      bodyController = quill.QuillController.basic();
    }

    subjectFocusNode.addListener(() {
      setState(() {
        isSubjectFocused = subjectFocusNode.hasFocus;
      });
    });
    quillFocusNode.addListener(() {
      setState(() {
        isBodyFocused = quillFocusNode.hasFocus;
      });
    });
  }

  void _initializeRecipients() {
    // Check if current user was in BCC
    bool isBccUser = widget.initialBcc != null &&
        widget.initialBcc!.split(', ').contains(currentUserEmail);

    if (isBccUser) {
      // If user was in BCC, only reply to the original sender
      toEmails = [widget.initialTo];
    } else {
      // Include original sender and To recipients
      toEmails = [widget.initialTo, ...widget.userMailRe.split(', ')];
      // Include CC recipients if any
      if (widget.initialCc != null && widget.initialCc!.isNotEmpty) {
        ccEmails = widget.initialCc!.split(', ');
      }
      // Remove current user's email from recipients
      toEmails.removeWhere((email) => email == currentUserEmail);
      ccEmails.removeWhere((email) => email == currentUserEmail);
      // Remove duplicates and empty strings
      toEmails = toEmails.toSet().toList()..removeWhere((e) => e.isEmpty);
      ccEmails = ccEmails.toSet().toList()..removeWhere((e) => e.isEmpty);
    }
  }

  Future<String?> _getCurrentUserAvatarUrl() async {
    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .get();
      if (userDoc.exists) {
        return userDoc.data()?['avatarUrl'] ?? 'assets/user.png';
      }
    } catch (e) {
      debugPrint('Error getting avatar URL: $e');
    }
    return 'assets/user.png'; // Giá trị mặc định
  }

  Future<String?> _getAvatarUrlByEmail(String email) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email)
          .limit(1)
          .get();
      if (snapshot.docs.isNotEmpty) {
        return snapshot.docs.first.data()['avatarUrl'] ?? 'assets/user.png';
      }
    } catch (e) {
      debugPrint('Error getting avatar URL for $email: $e');
    }
    return 'assets/user.png'; // Giá trị mặc định
  }

  Future<void> _loadUserEmail() async {
    setState(() {
      fromValue = currentUserEmail;
    });
  }

  Future<String?> getUserName(String email) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email)
          .get();
      if (snapshot.docs.isNotEmpty) {
        final userData = snapshot.docs.first.data();
        final fullName = userData['fullName'] as String?;
        final lastName = userData['lastName'] as String?;
        String userName = '';
        if (fullName != null) userName += fullName;
        if (lastName != null) {
          userName += (userName.isNotEmpty ? ' ' : '') + lastName;
        }
        return userName.isNotEmpty ? userName : null;
      }
    } catch (e) {
      debugPrint('Error getting user name: $e');
    }
    return null;
  }

  Future<String?> _getReceiver(String email) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email)
          .get();
      if (snapshot.docs.isNotEmpty) {
        return snapshot.docs.first.id;
      }
    } catch (e) {
      debugPrint('Error getting receiver info: $e');
    }
    return null;
  }

  Future<List<String>> _fetchEmailSuggestions(String query) async {
    if (query.isEmpty) return [];
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isGreaterThanOrEqualTo: query)
          .where('email', isLessThanOrEqualTo: '$query\uf8ff')
          .limit(10)
          .get();
      return snapshot.docs
          .map((doc) => doc['email'] as String)
          .where((email) => email != currentUserEmail)
          .toList();
    } catch (e) {
      debugPrint('Error fetching email suggestions: $e');
      return [];
    }
  }

  Future<Map<String, String>?> _uploadAttachment(
      String mailId, PlatformFile file) async {
    try {
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('attachments/$mailId/${file.name}');
      final uploadTask = storageRef.putFile(File(file.path!));
      final snapshot = await uploadTask;
      final downloadUrl = await snapshot.ref.getDownloadURL();
      return {'name': file.name, 'url': downloadUrl};
    } catch (e) {
      debugPrint('Error uploading file: $e');
      return null;
    }
  }

  Future<void> pickFile() async {
    try {
      FilePickerResult? result =
          await FilePicker.platform.pickFiles(allowMultiple: true);
      if (result != null && mounted) {
        setState(() {
          files.addAll(result.files);
        });
      }
    } catch (e) {
      debugPrint('Error picking file: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Unable to pick file'),
            backgroundColor: Colors.red[600],
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            elevation: 8,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  void removeFile(PlatformFile file) {
    setState(() {
      files.remove(file);
    });
  }

  Future<void> sendMail() async {
    if (toEmails.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
            'Please enter at least one valid recipient in the To field',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.red[600],
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          elevation: 8,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          duration: const Duration(seconds: 3),
        ),
      );
      return;
    }

    final scaffoldMessenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    try {
      isSent = true;
      final replyMailId =
          FirebaseFirestore.instance.collection('mails').doc().id;
      final currentTime = DateTime.now();
      final subject = subjectController.text
          .replaceFirst(RegExp(r'^(Re:|Fwd:)'), '')
          .trim();
      final senderName = await getUserName(fromValue!);
      debugPrint('Sender Name: $senderName');
      final senderAvatarUrl = await _getCurrentUserAvatarUrl();
      final allRecipients = {...toEmails, ...ccEmails, ...bccEmails}.toList();

      final receiverNames = <String, String?>{};
      for (var email in allRecipients) {
        receiverNames[email] = await getUserName(email);
      }

      // Lấy avatar của người gửi ban đầu
      String? originalSenderAvatarUrl;
      String? originalName;
      final mailDoc1 = await FirebaseFirestore.instance
          .collection('mails')
          .doc(widget.mailId)
          .get();
      String? originalSenderMail;
      if (mailDoc1.exists) {
        final mailData = mailDoc1.data()!;
        originalSenderMail = mailData['sender'] as String?;
        if (originalSenderMail != null) {
          originalSenderAvatarUrl =
              await _getAvatarUrlByEmail(originalSenderMail);
          originalName = await getUserName(originalSenderMail);
        }
      }

      originalSenderAvatarUrl ??= 'assets/user.png';

      // Tải lên tệp đính kèm
      List<Map<String, String>> attachments = [];
      for (var file in files) {
        if (file.path != null) {
          final result = await _uploadAttachment(replyMailId, file);
          if (result != null) {
            attachments.add(result);
          }
        }
      }

      // Lưu nội dung dưới dạng Delta JSON
      final bodyDelta = bodyController.document.toDelta().toJson();

      final sentMailData = {
        'mailId': replyMailId,
        'receiver': toEmails.join(', '),
        'receiverNames':
            toEmails.map((e) => receiverNames[e] ?? 'Unknown').join(', '),
        'subject': subject,
        'text': jsonEncode(bodyDelta),
        'attachments': attachments,
        'time': currentTime.toIso8601String(),
        'isStarred': false,
        'unread': false,
        'color': getRandomColor().value,
        'isTrash': false,
        'labels': [],
        'senderAvatarUrl': senderAvatarUrl ?? 'assets/user.png',
      };

      final receiveMailData = {
        'mailId': replyMailId,
        'sender': fromValue,
        'senderName': originalName,
        'subject': subject,
        'text': jsonEncode(bodyDelta),
        'attachments': attachments,
        'time': currentTime.toIso8601String(),
        'isStarred': false,
        'unread': true,
        'color': getRandomColor().value,
        'isTrash': false,
        'labels': [],
        'senderAvatarUrl': senderAvatarUrl ?? 'assets/user.png',
      };

      final receiveReplyMailData = {
        'mailId': replyMailId,
        'sender': fromValue,
        'senderName': senderName ?? 'Unknown',
        'subject': subject,
        'text': jsonEncode(bodyDelta),
        'attachments': attachments,
        'time': currentTime.toIso8601String(),
        'isStarred': false,
        'unread': true,
        'color': getRandomColor().value,
        'isTrash': false,
        'labels': [],
        'senderAvatarUrl': senderAvatarUrl ?? 'assets/user.png',
      };

      final replyEmailData = {
        'mailId': replyMailId,
        'parentMailId': widget.mailId,
        'from': fromValue,
        'fromName': senderName ?? 'Unknown',
        'to': toEmails.join(', '),
        'toNames':
            toEmails.map((e) => receiverNames[e] ?? 'Unknown').join(', '),
        'subject': subject,
        'body': jsonEncode(bodyDelta),
        'attachments': attachments,
        'time': currentTime.toIso8601String(),
        'avatarUrl': originalSenderAvatarUrl,
        'isReplyAll': true,
      };

      // Lưu vào sentMails
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('sentMails')
          .doc(replyMailId)
          .set(sentMailData);

      // Lưu vào repliesEmail
      await FirebaseFirestore.instance
          .collection('repliesEmail')
          .doc(replyMailId)
          .set(replyEmailData);

      // Update receiveMails cho tất cả người nhận
      for (var recipient in allRecipients) {
        final recipientId = await _getReceiver(recipient);
        if (recipientId != null) {
          final recipientName = await getUserName(recipient);
          await FirebaseFirestore.instance
              .collection('users')
              .doc(recipientId)
              .collection('receiveMails')
              .doc(widget.mailId)
              .set({
            ...receiveReplyMailData,
            'receiver': recipient,
            'receiverName': recipientName ?? 'Unknown',
            'unread': true,
          });
        }
      }

      // Update receiveMails cho người gửi
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('receiveMails')
          .doc(widget.mailId)
          .set({
        ...receiveMailData,
        'receiver': fromValue,
        'receiverName': senderName ?? 'Unknown',
        'unread': true,
      });

      // Lưu reply vào replies của mail gốc
      await FirebaseFirestore.instance
          .collection('mails')
          .doc(widget.mailId)
          .update({
        'replies': FieldValue.arrayUnion([replyMailId]),
      });

      isSuccessfullySent = true;
      setState(() {
        toEmails.clear();
        ccEmails.clear();
        bccEmails.clear();
        subjectController.clear();
        bodyController.document = quill.Document();
        files.clear();
        isSent = false;
      });

      scaffoldMessenger.showSnackBar(
        SnackBar(
          content: const Text(
            'Reply All sent successfully',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.green[600],
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          elevation: 8,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          duration: const Duration(seconds: 2),
        ),
      );

      await Future.delayed(const Duration(seconds: 2));
      if (mounted) {
        navigator.pushReplacement(
          MaterialPageRoute(builder: (context) => const FrontPage()),
        );
      }
    } catch (e) {
      debugPrint('Error sending reply all: $e');
      scaffoldMessenger.showSnackBar(
        SnackBar(
          content: const Text(
            'Unable to send reply all',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.red[600],
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          elevation: 8,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          duration: const Duration(seconds: 3),
        ),
      );
      if (mounted) {
        setState(() {
          isSent = false;
        });
      }
    }
  }

  Color getRandomColor() {
    final random = Random();
    return Color.fromARGB(
        255, random.nextInt(256), random.nextInt(256), random.nextInt(256));
  }

  @override
  void dispose() {
    subjectFocusNode.dispose();
    quillFocusNode.dispose();
    subjectController.dispose();
    bodyController.dispose();

    super.dispose();
  }

  Future<void> _composeEmailAI() async {
    final emailService = Get.find<EmailService>();
    final keyPoints = bodyController.document.toPlainText().trim();
    final result = await emailService.composeEmail(
      subjectController.text,
      keyPoints.isEmpty ? "No key points provided" : keyPoints,
      'professional',
      'This is a reply all to the email',
    );
    debugPrint('Compose email result: $result');
    try {
      final deltaJson = jsonDecode(result);
      bodyController.document = quill.Document.fromJson(deltaJson);
    } catch (e) {
      bodyController.document = quill.Document()..insert(0, result);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !isSent,
      onPopInvoked: (bool didPop) async {
        if (didPop || isSent || isSuccessfullySent) return;
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.surface,
          iconTheme:
              IconThemeData(color: Theme.of(context).colorScheme.onSurface),
          title: Text(
            'Reply All',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface,
              fontSize: 18,
              fontFamily: "Roboto",
            ),
          ),
          actions: [
            IconButton(
              icon: Icon(Icons.lightbulb_outline,
                  color: Theme.of(context).colorScheme.onSurface),
              onPressed: () {
                _composeEmailAI();
              },
            ),
            IconButton(
              icon: Icon(Icons.attach_file_outlined,
                  color: Theme.of(context).colorScheme.onSurface),
              onPressed: pickFile,
            ),
            IconButton(
              icon: Icon(Icons.send_outlined,
                  color: Theme.of(context).colorScheme.onSurface),
              onPressed: sendMail,
            ),
            PopupMenuButton<String>(
              offset: const Offset(0, 50),
              icon: Icon(Icons.more_vert,
                  color: Theme.of(context).colorScheme.onSurface),
              itemBuilder: (BuildContext context) {
                return [
                  const PopupMenuItem(value: '1', child: Text('Schedule send')),
                  const PopupMenuItem(
                      value: '2', child: Text('Add from contacts')),
                  const PopupMenuItem(value: '4', child: Text('Save draft')),
                ];
              },
            ),
          ],
          elevation: 0,
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.only(bottom: 48),
          child: _buildQuillToolbar(),
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 16,
            left: 16,
            right: 16,
            top: 16,
          ),
          child: Column(
            children: [
              _buildFromField(),
              _buildDivider(),
              _buildToField(),
              _buildDivider(),
              if (isCcBccExpanded) _buildCcBccFields(),
              _buildSubjectField(),
              _buildDivider(),
              _buildBodyField(),
              _buildAttachmentSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFromField() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          child: Text(
            'From:',
            style: TextStyle(
                fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
          ),
        ),
        Expanded(
          child: Text(
            fromValue ?? 'Loading...',
            style: TextStyle(
                fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
          ),
        ),
      ],
    );
  }

  Widget _buildToField() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          child: Text(
            'To:',
            style: TextStyle(
                fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
          ),
        ),
        Expanded(
          child: CustomChipInput(
            emails: toEmails,
            onChanged: (newEmails) {
              setState(() {
                toEmails = newEmails;
              });
            },
            fetchSuggestions: _fetchEmailSuggestions,
            suffixIcon: IconButton(
              icon: Icon(
                isCcBccExpanded ? Icons.arrow_drop_up : Icons.arrow_drop_down,
                color: Colors.grey[600],
              ),
              onPressed: () {
                setState(() {
                  isCcBccExpanded = !isCcBccExpanded;
                });
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCcBccFields() {
    return Column(
      children: [
        _buildFieldRow(
          label: 'Cc:',
          emails: ccEmails,
          onChanged: (newEmails) {
            setState(() {
              ccEmails = newEmails;
            });
          },
        ),
        _buildDivider(),
        _buildFieldRow(
          label: 'Bcc:',
          emails: bccEmails,
          onChanged: (newEmails) {
            setState(() {
              bccEmails = newEmails;
            });
          },
        ),
        _buildDivider(),
      ],
    );
  }

  Widget _buildSubjectField() {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: subjectController,
            focusNode: subjectFocusNode,
            cursorHeight: 22,
            style: TextStyle(
                fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
            decoration: InputDecoration(
              border: InputBorder.none,
              hintText: isSubjectFocused ? null : 'Subject',
              contentPadding: const EdgeInsets.all(20),
              hintStyle: TextStyle(fontSize: 18, color: Colors.grey[600]),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildQuillToolbar() {
    return quill.QuillSimpleToolbar(
      controller: bodyController,
      config: const quill.QuillSimpleToolbarConfig(
        showBoldButton: true,
        showItalicButton: true,
        showUnderLineButton: true,
        showStrikeThrough: true,
        showFontFamily: false,
        showFontSize: false,
        showHeaderStyle: false,
        showListNumbers: true,
        showListBullets: true,
        showListCheck: false,
        showCodeBlock: false,
        showQuote: false,
        showIndent: false,
        showLink: false,
        showInlineCode: false,
        showClearFormat: true,
        showColorButton: true,
        showBackgroundColorButton: false,
        showAlignmentButtons: true,
        showDirection: false,
        showSearchButton: false,
        showSubscript: false,
        showSuperscript: false,
      ),
    );
  }

  Widget _buildBodyField() {
    return Container(
      constraints: const BoxConstraints(minHeight: 200),
      padding: const EdgeInsets.all(20),
      child: quill.QuillEditor.basic(
        controller: bodyController,
        focusNode: quillFocusNode,
        config: const quill.QuillEditorConfig(
          placeholder: 'Write your message here...',
          autoFocus: false,
        ),
      ),
    );
  }

  Widget _buildAttachmentSection() {
    if (files.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: files.map((file) {
          final extension = file.extension?.toLowerCase();
          bool isImage =
              extension == 'jpg' || extension == 'jpeg' || extension == 'png';
          bool isPdf = extension == 'pdf';
          bool isDoc = extension == 'doc' || extension == 'docx';
          bool isExcel = extension == 'xls' || extension == 'xlsx';
          bool isZip = extension == 'zip' || extension == 'rar';

          IconData fileIcon;
          if (isImage) {
            fileIcon = Icons.image;
          } else if (isPdf) {
            fileIcon = Icons.picture_as_pdf;
          } else if (isDoc) {
            fileIcon = Icons.description;
          } else if (isExcel) {
            fileIcon = Icons.table_chart;
          } else if (isZip) {
            fileIcon = Icons.archive;
          } else {
            fileIcon = Icons.insert_drive_file;
          }

          return isImage && file.path != null
              ? SizedBox(
                  width: 100,
                  height: 100,
                  child: Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.file(
                          File(file.path!),
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => Icon(
                            fileIcon,
                            size: 50,
                            color: Colors.grey[600],
                          ),
                        ),
                      ),
                      Positioned(
                        right: 0,
                        top: 0,
                        child: GestureDetector(
                          onTap: () => removeFile(file),
                          child: Container(
                            color: Colors.black54,
                            child: const Icon(Icons.close,
                                size: 16, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              : Chip(
                  avatar: Icon(fileIcon, size: 18, color: Colors.grey[600]),
                  label: Text(
                    file.name,
                    style: const TextStyle(fontSize: 14),
                    overflow: TextOverflow.ellipsis,
                  ),
                  deleteIcon: const Icon(Icons.close, size: 18),
                  onDeleted: () => removeFile(file),
                  backgroundColor: Colors.grey[100],
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                );
        }).toList(),
      ),
    );
  }

  Widget _buildFieldRow({
    required String label,
    required List<String> emails,
    required ValueChanged<List<String>> onChanged,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          child: Text(
            label,
            style: TextStyle(
                fontSize: 18, color: Theme.of(context).colorScheme.onSurface),
          ),
        ),
        Expanded(
          child: CustomChipInput(
            emails: emails,
            onChanged: onChanged,
            fetchSuggestions: _fetchEmailSuggestions,
          ),
        ),
      ],
    );
  }

  Widget _buildDivider() {
    return Divider(
      color: Colors.grey[300],
      height: 1,
      thickness: 0.3,
    );
  }
}
