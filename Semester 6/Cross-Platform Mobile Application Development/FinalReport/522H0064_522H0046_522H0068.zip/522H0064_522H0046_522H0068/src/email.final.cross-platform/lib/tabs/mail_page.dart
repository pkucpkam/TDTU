// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:firebase_auth/firebase_auth.dart';

// Project imports:
import 'package:final_project/models/reply_mode.dart';
import 'package:final_project/models/user_mode.dart';
import 'package:final_project/tabs/compose.dart';

class Gmail extends StatefulWidget {
  final int index;
  final AppUser user;
  final Color image;
  final String time;
  final String text;
  final String subject;
  final bool isstarred;
  final List<Reply> replies;
  final String account;

  const Gmail({
    super.key,
    required this.index,
    required this.user,
    required this.image,
    required this.time,
    required this.text,
    required this.subject,
    required this.isstarred,
    required this.replies,
    required this.account,
  });

  @override
  GmailState createState() => GmailState();
}

class GmailState extends State<Gmail> {
  late bool isStarred;
  final userName = FirebaseAuth.instance.currentUser?.uid;

  @override
  void initState() {
    super.initState();
    isStarred = widget.isstarred;
  }

  bool _isMailSentMail() {
    return userName == widget.user.name;
  }

  Reply _getLatestReply() {
    if (widget.replies.isNotEmpty) {
      return widget.replies.last; // Mail phản hồi gần nhất
    } else {
      return Reply(
        from: widget.user.name,
        to: widget.account,
        subject: widget.subject,
        body: widget.text,
        time: widget.time,
      ); // Mail gốc
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Mail Details"),
        actions: [
          IconButton(
            icon: Icon(
              isStarred ? Icons.star : Icons.star_border,
              color: isStarred ? Colors.yellow : null,
            ),
            onPressed: () {
              setState(() {
                isStarred = !isStarred;
              });
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.subject,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Divider(),
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: widget.image,
                  child: Text(
                    widget.user.name[0],
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
                const SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          _isMailSentMail() ? "me" : widget.user.name,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Text(widget.time),
                      ],
                    ),
                    Row(
                      children: [
                        Text(
                          _isMailSentMail() ? "to ${widget.account}" : "to me",
                          style: TextStyle(
                              color: Colors.grey[800], fontSize: 14.0),
                        ),
                        const Icon(Icons.expand_more),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Hiển thị nội dung mail gốc
                    Text(
                      widget.text,
                      style: const TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 20),
                    // Kiểm tra và hiển thị các mail phản hồi nếu có
                    if (widget.replies.isNotEmpty)
                      ...widget.replies.map((reply) {
                        return Padding(
                          padding: const EdgeInsets.only(top: 16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Divider(),
                              Text(
                                'Replied by: ${reply.from}',
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                              Text(
                                'Subject: ${reply.subject}',
                                style: const TextStyle(
                                    fontSize: 14, fontStyle: FontStyle.italic),
                              ),
                              Text(
                                'To: ${reply.to}',
                                style: const TextStyle(
                                    fontSize: 14, fontStyle: FontStyle.italic),
                              ),
                              Text(
                                'Time: ${reply.time}',
                                style: const TextStyle(
                                    fontSize: 14, color: Colors.grey),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                reply.body,
                                style: const TextStyle(fontSize: 16),
                              ),
                              const SizedBox(height: 20),
                            ],
                          ),
                        );
                      }),
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Compose(
                          initialTo: widget.user.name,
                          initialSubject: widget.subject,
                          userMail: widget.user.name,
                          userMailRe: widget.account,
                          isReply: true,
                          isDraft: false,
                        ),
                      ),
                    );
                  },
                  child: const Text('Reply'),
                ),
                ElevatedButton(
                  onPressed: () {
                    final latestData = _getLatestReply();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Compose(
                          initialTo: '', // Người dùng nhập địa chỉ mới
                          initialSubject: "Fwd: ${latestData.subject}",
                          userMail: widget.user.name,
                          isReply: false,
                          isDraft: false,
                          forwardedBody:
                              latestData.body, // Nội dung mail để forward
                        ),
                      ),
                    );
                  },
                  child: const Text('Forward'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
