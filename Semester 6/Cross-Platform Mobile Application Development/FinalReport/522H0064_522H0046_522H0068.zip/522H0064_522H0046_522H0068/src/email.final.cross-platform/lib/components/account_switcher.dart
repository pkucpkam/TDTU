// ignore_for_file: use_build_context_synchronously

// Dart imports:
import 'dart:math';

// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cached_network_image/cached_network_image.dart';

// Project imports:
import 'package:final_project/tabs/privacy_policy.dart';
import 'package:final_project/tabs/terms_of_service.dart';

typedef AvatarSize = double;

class UserAvatar extends StatelessWidget {
  final String? avatarUrl;
  final AvatarSize radius;
  final String? assetFallback;
  const UserAvatar({
    super.key,
    this.avatarUrl,
    this.radius = 20,
    this.assetFallback = 'assets/user.png',
  });

  @override
  Widget build(BuildContext context) {
    if (avatarUrl != null &&
        avatarUrl!.isNotEmpty &&
        avatarUrl!.startsWith('http')) {
      return CircleAvatar(
        backgroundImage: CachedNetworkImageProvider(avatarUrl!),
        radius: radius,
      );
    } else {
      return CircleAvatar(
        backgroundImage: AssetImage(assetFallback!),
        radius: radius,
      );
    }
  }
}

Color getRandomColor() {
  final random = Random();
  return Color.fromARGB(
    255,
    random.nextInt(256),
    random.nextInt(256),
    random.nextInt(256),
  );
}

class AccountSwitcher extends StatelessWidget {
  final String mainName;
  final String mainEmail;
  final String? mainAvatarUrl;
  final List<Map<String, String>> otherAccounts; // [{name, email, avatarUrl}]
  final VoidCallback? onManageAccount;
  final VoidCallback? onAddAccount;
  final VoidCallback? onManageDevice;
  final double storagePercent;
  final String storageText;
  const AccountSwitcher({
    super.key,
    required this.mainName,
    required this.mainEmail,
    this.mainAvatarUrl,
    this.otherAccounts = const [],
    this.onManageAccount,
    this.onAddAccount,
    this.onManageDevice,
    this.storagePercent = 0.0,
    this.storageText = '',
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.only(top: 8.0),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: UserAvatar(avatarUrl: mainAvatarUrl, radius: 22),
              title: Text(mainName,
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(
                mainEmail,
                overflow: TextOverflow.ellipsis,
              ),
              trailing: const Icon(Icons.check, color: Colors.blueAccent),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
              child: OutlinedButton(
                onPressed: onManageAccount,
                style: OutlinedButton.styleFrom(
                  shape: const StadiumBorder(),
                  side: const BorderSide(color: Colors.grey),
                  padding:
                      const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                ),
                child: Text(
                  'Manage your account',
                  style: TextStyle(
                    color: Theme.of(context).textTheme.bodyLarge?.color,
                  ),
                ),
              ),
            ),
            if (storageText.isNotEmpty)
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
                child: Row(
                  children: [
                    const Icon(Icons.cloud_outlined,
                        size: 20, color: Colors.grey),
                    const SizedBox(width: 8),
                    Expanded(
                      child: LinearProgressIndicator(
                        value: storagePercent,
                        minHeight: 6,
                        backgroundColor: Colors.grey[200],
                        color: Colors.blueAccent,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(storageText, style: const TextStyle(fontSize: 12)),
                  ],
                ),
              ),
            const Divider(),
            ...otherAccounts.map((acc) => ListTile(
                  leading: UserAvatar(avatarUrl: acc['avatarUrl'], radius: 22),
                  title: Text(acc['name'] ?? '',
                      style: const TextStyle(fontWeight: FontWeight.w500)),
                  subtitle: Text(acc['email'] ?? ''),
                  onTap: () {},
                )),
            ListTile(
              leading: Icon(
                Icons.person_add_alt,
                color: Theme.of(context).iconTheme.color?.withOpacity(0.6),
              ),
              title: const Text('Add another account'),
              onTap: onAddAccount,
            ),
            ListTile(
              leading: Icon(Icons.settings,
                  color: Theme.of(context).iconTheme.color?.withOpacity(0.6),
                  size: 24),
              title: const Text('Manage accounts on this device'),
              onTap: onManageDevice,
            ),
            const Divider(),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const PrivacyPolicyScreen(),
                        ),
                      );
                    },
                    child: const Text('Privacy Policy',
                        style: TextStyle(fontSize: 12)),
                  ),
                  const SizedBox(width: 8),
                  const Text('•', style: TextStyle(fontSize: 12)),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const TermsOfServiceScreen(),
                        ),
                      );
                    },
                    child: const Text('Terms of Service',
                        style: TextStyle(fontSize: 12)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
