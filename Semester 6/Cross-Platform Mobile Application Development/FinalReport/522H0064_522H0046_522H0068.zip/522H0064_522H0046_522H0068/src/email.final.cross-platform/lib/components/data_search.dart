// ignore_for_file: use_build_context_synchronously

// Flutter imports:
import 'dart:convert';

import 'package:flutter/material.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

// Project imports:
import '../models/message_mode.dart';
import '../models/user_mode.dart';
import '../tabs/mail_detail.dart';

class Datasearch extends SearchDelegate<String> {
  final String currentUser;
  String? selectedLabel; // Lưu nhãn được chọn
  String? selectedDateWithin; // Lưu khoảng thời gian được chọn

  Datasearch({required this.currentUser});

  // Tải label của người dùng từ Firestore
  Future<List<String>> _loadUserLabels() async {
    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .get();

      if (userDoc.exists) {
        final userLabels = List<String>.from(userDoc.data()?['labels'] ?? []);
        return ['Starred', 'Sent', ...userLabels];
      }
      return ['Starred', 'Sent'];
    } catch (e) {
      debugPrint('Error loading user labels: $e');
      return ['Starred', 'Sent'];
    }
  }

  Future<List<Message>> searchEmails(String query) async {
    if (query.isEmpty && selectedLabel == null && selectedDateWithin == null) {
      return [];
    }

    QuerySnapshot inboxQuerySnapshot;
    QuerySnapshot sentQuerySnapshot;

    if (selectedLabel == 'Starred') {
      inboxQuerySnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('receiveMails')
          .where('isStarred', isEqualTo: true)
          .get();

      sentQuerySnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('sentMails')
          .where('isStarred', isEqualTo: true)
          .get();
    } else if (selectedLabel == 'Sent') {
      inboxQuerySnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('sentMails')
          .get();
      sentQuerySnapshot = inboxQuerySnapshot;
    } else {
      inboxQuerySnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('receiveMails')
          .get();

      sentQuerySnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('sentMails')
          .get();
    }

    final combinedDocs = [
      ...inboxQuerySnapshot.docs,
      if (selectedLabel != 'Sent') ...sentQuerySnapshot.docs,
    ];

    final results = combinedDocs.where((doc) {
      final data = doc.data() as Map<String, dynamic>;
      final subject = data['subject']?.toString() ?? '';
      final text = data['text']?.toString() ?? '';
      final receiver = data['reciever']?.toString() ?? '';
      final senderName = data['senderName']?.toString() ?? '';
      final labels = data['labels'] as List<dynamic>? ?? [];
      final time = data['time']?.toString() ?? '';

      bool matchesQuery = query.isEmpty ||
          subject.toLowerCase().contains(query.toLowerCase()) ||
          text.toLowerCase().contains(query.toLowerCase()) ||
          receiver.toLowerCase().contains(query.toLowerCase()) ||
          senderName.toLowerCase().contains(query.toLowerCase());

      bool matchesLabel = selectedLabel == null ||
          selectedLabel == 'Starred' ||
          selectedLabel == 'Sent' ||
          labels.contains(selectedLabel);

      bool matchesDate = true;
      if (selectedDateWithin != null && time.isNotEmpty) {
        final emailDate = DateTime.parse(time);
        final now = DateTime.now();
        DateTime cutoffDate;
        switch (selectedDateWithin) {
          case '1 day':
            cutoffDate = now.subtract(const Duration(days: 1));
            break;
          case '1 week':
            cutoffDate = now.subtract(const Duration(days: 7));
            break;
          case '1 month':
            cutoffDate = now.subtract(const Duration(days: 30));
            break;
          default:
            cutoffDate = now;
        }
        matchesDate = emailDate.isAfter(cutoffDate);
      }

      return matchesQuery && matchesLabel && matchesDate;
    }).map((doc) {
      final data = doc.data() as Map<String, dynamic>;

      return Message(
        sender: AppUser(
          id: doc.id.hashCode,
          name: data['senderName'] ?? 'Unknown',
          imageUrl: Color(data['color'] ?? 0xFF000000),
          avatarUrl: data['senderAvatarUrl']?.toString() ?? 'assets/user.png',
        ),
        reciever: data['reciever'] ?? 'No Receiver',
        subject: data['subject'] ?? 'No Subject',
        text: data['text'] ?? 'No Content',
        time: DateFormat('hh:mm a').format(DateTime.parse(data['time'])),
        unread: data['unread'] ?? true,
        isStarred: data['isStarred'] ?? false,
        threadID: doc.id,
      );
    }).toList();

    return results;
  }

  String parseQuillJsonToPlainText(String quillJson) {
    try {
      final List<dynamic> quillData = jsonDecode(quillJson);
      String plainText = quillData
          .where((element) => element['insert'] != null)
          .map((element) => element['insert'].toString())
          .join();
      return plainText.trim();
    } catch (e) {
      debugPrint('Error parsing Quill JSON: $e');
      return quillJson;
    }
  }


  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        onPressed: () {
          query = '';
          selectedLabel = null;
          selectedDateWithin = null;
          showSuggestions(context);
        },
        icon: const Icon(Icons.clear),
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      onPressed: () {
        close(context, '');
      },
      icon: AnimatedIcon(
        icon: AnimatedIcons.menu_arrow,
        progress: transitionAnimation,
      ),
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return FutureBuilder<List<Message>>(
      future: searchEmails(query),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        final searchResults = snapshot.data ?? [];
        if (searchResults.isEmpty) {
          return const Center(child: Text('No results found.'));
        }

        return ListView.builder(
          itemCount: searchResults.length,
          itemBuilder: (context, index) {
            final mail = searchResults[index];
            return Container(
              color: mail.unread ? Colors.grey.withAlpha(20) : Colors.transparent,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.grey[300],
                  backgroundImage: mail.sender.avatarUrl != null &&
                          mail.sender.avatarUrl!.isNotEmpty &&
                          mail.sender.avatarUrl != 'assets/user.png'
                      ? NetworkImage(mail.sender.avatarUrl!)
                      : const AssetImage('assets/user.png') as ImageProvider,
                  child: mail.sender.avatarUrl == null ||
                          mail.sender.avatarUrl!.isEmpty ||
                          mail.sender.avatarUrl == 'assets/user.png'
                      ? Text(
                          mail.sender.name.isNotEmpty
                              ? mail.sender.name[0].toUpperCase()
                              : '?',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: mail.unread ? FontWeight.bold : FontWeight.normal,
                          ),
                        )
                      : null,
                ),
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        mail.sender.name,
                        style: TextStyle(
                          fontWeight: mail.unread ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ),
                    Text(
                      mail.time,
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ],
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      mail.subject,
                      style: TextStyle(
                        fontWeight: mail.unread ? FontWeight.bold : FontWeight.normal,
                        color: Theme.of(context).textTheme.bodyLarge?.color,
                      ),
                    ),
                    Text(
                      parseQuillJsonToPlainText(mail.text),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
                onTap: () async {
                  final navigator = Navigator.of(context);
                  navigator.push(
                    MaterialPageRoute(
                      builder: (_) => MailDetail(
                        mailId: mail.threadID!,
                      ),
                    ),
                  );
                },
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: FutureBuilder<List<String>>(
            future: _loadUserLabels(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return const Center(child: Text('Error loading labels'));
              }

              final labels = snapshot.data ?? ['Starred', 'Sent'];
              return DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  labelText: 'Label',
                  border: OutlineInputBorder(),
                ),
                items: ['None', ...labels]
                    .map((label) => DropdownMenuItem<String>(
                          value: label == 'None' ? null : label,
                          child: Text(label),
                        ))
                    .toList(),
                value: selectedLabel,
                onChanged: (value) {
                  selectedLabel = value;
                  showResults(context);
                },
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: DropdownButtonFormField<String>(
            decoration: const InputDecoration(
              labelText: 'Date within',
              border: OutlineInputBorder(),
            ),
            items: ['None', '1 day', '1 week', '1 month']
                .map((value) => DropdownMenuItem<String>(
                      value: value == 'None' ? null : value,
                      child: Text(value),
                    ))
                .toList(),
            value: selectedDateWithin,
            onChanged: (value) {
              selectedDateWithin = value;
              showResults(context);
            },
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Message>>(
            future: searchEmails(query),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              }

              final searchResults = snapshot.data ?? [];
              if (searchResults.isEmpty) {
                return const Center(child: Text('No suggestions found.'));
              }

              return ListView.builder(
                itemCount: searchResults.length,
                itemBuilder: (context, index) {
                  final mail = searchResults[index];
                  return Container(
                    color: mail.unread ? Colors.grey.withAlpha(20) : Colors.transparent,
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.grey[300],
                        backgroundImage: mail.sender.avatarUrl != null &&
                                mail.sender.avatarUrl!.isNotEmpty &&
                                mail.sender.avatarUrl != 'assets/user.png'
                            ? NetworkImage(mail.sender.avatarUrl!)
                            : const AssetImage('assets/user.png') as ImageProvider,
                        child: mail.sender.avatarUrl == null ||
                                mail.sender.avatarUrl!.isEmpty ||
                                mail.sender.avatarUrl == 'assets/user.png'
                            ? Text(
                                mail.sender.name.isNotEmpty
                                    ? mail.sender.name[0].toUpperCase()
                                    : '?',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: mail.unread ? FontWeight.bold : FontWeight.normal,
                                ),
                              )
                            : null,
                      ),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              mail.sender.name,
                              style: TextStyle(
                                fontWeight: mail.unread ? FontWeight.bold : FontWeight.normal,
                              ),
                            ),
                          ),
                          Text(
                            mail.time,
                            style: const TextStyle(fontSize: 12, color: Colors.grey),
                          ),
                        ],
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            mail.subject,
                            style: TextStyle(
                              fontWeight: mail.unread ? FontWeight.bold : FontWeight.normal,
                              color: Theme.of(context).textTheme.bodyLarge?.color,
                            ),
                          ),
                          Text(
                            parseQuillJsonToPlainText(mail.text),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                      onTap: () async {
                        final navigator = Navigator.of(context);
                        navigator.push(
                          MaterialPageRoute(
                            builder: (_) => MailDetail(
                              mailId: mail.threadID!,
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}