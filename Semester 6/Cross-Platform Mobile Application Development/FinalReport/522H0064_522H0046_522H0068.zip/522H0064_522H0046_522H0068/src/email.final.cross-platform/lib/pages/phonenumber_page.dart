// Flutter imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:final_project/pages/login_page.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// Package imports:
import 'package:firebase_auth/firebase_auth.dart';

// Project imports:
import 'package:final_project/tabs/mails.dart';

class PhoneNumberPage extends StatefulWidget {
  final String phoneNumber;
  const PhoneNumberPage({super.key, required this.phoneNumber});

  @override
  PhoneNumberPageState createState() => PhoneNumberPageState();
}

class PhoneNumberPageState extends State<PhoneNumberPage> {
  final List<TextEditingController> _otpControllers =
      List.generate(6, (index) => TextEditingController());
  final List<FocusNode> _focusNodes = List.generate(6, (index) => FocusNode());
  bool _isOtpSent = false;
  String? _verificationId;
  String? _errorMessage;
  bool _isSendingOtp = false;

  @override
  void dispose() {
    for (var controller in _otpControllers) {
      controller.dispose();
    }
    for (var focusNode in _focusNodes) {
      focusNode.dispose();
    }
    super.dispose();
  }

  Future<bool> _checkTwoFactorEnabled() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();
        return doc.data()?['isTwoFactorEnabled'] ?? false;
      }
      return false;
    } catch (e) {
      debugPrint('[DEBUG] Error checking 2FA status: $e');
      return false;
    }
  }

  void _sendOTP() async {
    if (_isSendingOtp) return;
    setState(() {
      _isSendingOtp = true;
      _errorMessage = null;
    });

    final phoneNumber = widget.phoneNumber;
    debugPrint('[DEBUG] Sending OTP to: $phoneNumber');

    if (phoneNumber.isEmpty) {
      setState(() {
        _errorMessage = 'Invalid phone number provided';
        _isSendingOtp = false;
      });
      return;
    }

    try {
      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        verificationCompleted: (credential) async {
          debugPrint(
              '[DEBUG] Auto-verification triggered, ignoring to force OTP input');
        },
        verificationFailed: (e) {
          debugPrint(
              '[DEBUG] verificationFailed: ${e.message ?? e.toString()}');
          setState(() {
            _errorMessage =
                'Verification failed: ${e.message ?? 'Unknown error'}';
            _isSendingOtp = false;
          });
        },
        codeSent: (verificationId, resendToken) {
          debugPrint('[DEBUG] OTP sent, verificationId: $verificationId');
          setState(() {
            _verificationId = verificationId;
            _isOtpSent = true;
            _errorMessage = null;
            _isSendingOtp = false;
          });
        },
        codeAutoRetrievalTimeout: (verificationId) {
          debugPrint(
              '[DEBUG] codeAutoRetrievalTimeout: verificationId=$verificationId');
          _verificationId = verificationId;
          setState(() {
            _isSendingOtp = false;
          });
        },
      );
    } catch (e) {
      debugPrint('[DEBUG] Error sending OTP: $e');
      setState(() {
        _errorMessage = 'Error sending OTP: ${e.toString()}';
        _isSendingOtp = false;
      });
    }
  }

  void _verifyOTP() async {
    final otp = _otpControllers.map((controller) => controller.text).join();
    if (kDebugMode) {
      print(
          '[DEBUG] Verifying OTP: $otp, verificationId=${_verificationId ?? 'null'}');
    }
    if (_verificationId == null) {
      setState(() {
        _errorMessage = 'Verification ID is missing. Please request OTP again.';
      });
      return;
    }
    if (otp.length != 6) {
      setState(() {
        _errorMessage = 'Please enter a valid 6-digit OTP!';
      });
      return;
    }

    showDialog(
      context: context,
      builder: (context) => const Center(child: CircularProgressIndicator()),
    );

    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: _verificationId!,
        smsCode: otp,
      );
      if (kDebugMode) print('[DEBUG] Created credential, signing in...');
      await FirebaseAuth.instance.signInWithCredential(credential);
      Navigator.pop(context);
      _navigateToMails();
    } catch (e) {
      Navigator.pop(context);
      if (kDebugMode) print('[DEBUG] Invalid OTP: $e');
      setState(() {
        _errorMessage = 'Invalid OTP';
      });
    }
  }

  void _navigateToMails() {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const Mails()),
      (route) => false,
    );
  }

  InputDecoration fieldDecoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.black),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Colors.black, width: 1),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Colors.black, width: 1),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Colors.blueAccent, width: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: _checkTwoFactorEnabled(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (snapshot.hasError || !snapshot.hasData || !snapshot.data!) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const Mails()),
              (route) => false,
            );
          });
          return const SizedBox.shrink();
        }

        // Send OTP when 2FA is enabled
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!_isOtpSent && !_isSendingOtp) {
            _sendOTP();
          }
        });

        return WillPopScope(
          onWillPop: () async {
            await FirebaseAuth.instance.signOut();
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const LoginPage(onTap: null)),
              (route) => false,
            );
            return false;
          },
          child: Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.white,
              elevation: 0,
              iconTheme: const IconThemeData(color: Colors.black),
              title: const Text(
                "Phone Verification",
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.w500),
              ),
              centerTitle: true,
              automaticallyImplyLeading: false,
            ),
            backgroundColor: Colors.white,
            body: Padding(
              padding: const EdgeInsets.all(32.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: Text(
                      _isOtpSent
                          ? "Enter the OTP code sent to ${widget.phoneNumber}"
                          : "Sending OTP to ${widget.phoneNumber}...",
                      style: const TextStyle(fontSize: 16, color: Colors.black),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(height: 20),
                  if (_isOtpSent) ...[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: List.generate(6, (index) {
                        return SizedBox(
                          width: 50,
                          child: TextField(
                            controller: _otpControllers[index],
                            focusNode: _focusNodes[index],
                            keyboardType: TextInputType.number,
                            textAlign: TextAlign.center,
                            maxLength: 1,
                            style:
                                const TextStyle(fontSize: 24, color: Colors.black),
                            decoration: InputDecoration(
                              counterText: "",
                              filled: true,
                              fillColor: Colors.white,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide:
                                    const BorderSide(color: Colors.black, width: 1),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide:
                                    const BorderSide(color: Colors.black, width: 1),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: const BorderSide(
                                    color: Colors.blueAccent, width: 2),
                              ),
                            ),
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            onChanged: (value) {
                              if (value.isNotEmpty && index < 5) {
                                _focusNodes[index + 1].requestFocus();
                              } else if (value.isEmpty && index > 0) {
                                _focusNodes[index - 1].requestFocus();
                              }
                            },
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _verifyOTP,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blueAccent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text("Confirm OTP"),
                      ),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: TextButton(
                        onPressed: _isSendingOtp ? null : _sendOTP,
                        child: Text(
                          "Resend OTP",
                          style: TextStyle(
                            color: _isSendingOtp ? Colors.grey : Colors.blueAccent,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                  ],
                  if (_errorMessage != null) ...[
                    const SizedBox(height: 20),
                    Text(
                      _errorMessage!,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}