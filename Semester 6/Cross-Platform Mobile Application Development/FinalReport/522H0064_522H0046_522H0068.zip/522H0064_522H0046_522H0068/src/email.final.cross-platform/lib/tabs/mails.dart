// ignore_for_file: use_build_context_synchronously

// Dart imports:
import 'dart:convert';
import 'dart:math';

// Flutter imports:
import 'package:final_project/components/bottom_nav.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

// Project imports:
import 'package:final_project/components/account_switcher.dart';
import 'package:final_project/components/data_search.dart';
import 'package:final_project/models/message_mode.dart';
import 'package:final_project/models/user_mode.dart' as my_models;
import 'package:final_project/services/email_service.dart';
import 'package:final_project/tabs/compose.dart';
import 'package:final_project/tabs/drawer.dart';
import 'package:final_project/tabs/mail_detail.dart';
import 'package:final_project/tabs/profile.dart';

class Mails extends StatefulWidget {
  const Mails({super.key});

  @override
  State<Mails> createState() => _MailsState();
}

class _MailsState extends State<Mails> {
  List<String> selectedMessageIDs = [];
  bool? isStarred = false;
  List<Message> mails = [];
  final currentUser = FirebaseAuth.instance.currentUser?.uid;
  final EmailService _emailService = Get.find<EmailService>();
  final int _currentIndex = 0;

  String? _avatarUrl;
  String? _name;
  String? _fullName;
  String? _lastName;
  String? _email;

  @override
  void initState() {
    super.initState();
    handleScroll();
    loadMailsFromFirebase();
    _loadUserInfo();
    if (currentUser != null) {
      _emailService.init(currentUser!); // Khởi tạo EmailService với userId
    } else {
      debugPrint('No user logged in, cannot initialize EmailService');
    }
  }

  Stream<List<Message>> getMailsStream() {
    if (currentUser == null) {
      debugPrint('No user logged in');
      return Stream.value([]);
    }

    return FirebaseFirestore.instance
        .collection('users')
        .doc(currentUser)
        .collection('receiveMails')
        .where('isTrash', isNotEqualTo: true)
        .orderBy('time', descending: true)
        .snapshots()
        .map((snapshot) {
      List<Message> mails = [];
      for (var doc in snapshot.docs) {
        final data = doc.data();

        final colorValue = data['color'];
        Color senderColor;
        if (colorValue is int) {
          senderColor = Color(colorValue);
        } else if (colorValue is String && int.tryParse(colorValue) != null) {
          senderColor = Color(int.parse(colorValue));
        } else {
          senderColor = Colors.blueGrey;
        }

        final loadedMail = Message(
          sender: my_models.AppUser(
            id: mails.length,
            name: data['senderName'] ?? 'Unknown',
            imageUrl: senderColor,
            avatarUrl:
                data['senderAvatarUrl'] ?? 'assets/user.png', // Thêm avatarUrl
          ),
          reciever: data['receiver'] ?? 'No Receiver',
          subject: data['subject'] ?? 'No Subject',
          text: data['text'] ?? 'No Content',
          time: DateFormat('hh:mm a').format(DateTime.parse(data['time'])),
          unread: data['unread'] ?? true,
          isStarred: data['isStarred'] ?? false,
          threadID: doc.id,
        );
        mails.add(loadedMail);
      }
      return mails;
    });
  }

  Future<void> _loadUserInfo() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      setState(() {
        _avatarUrl = doc.data()?['avatarUrl'] ?? 'assets/user.png';
        _fullName = doc.data()?['fullName'] ?? 'User';
        _lastName = doc.data()?['lastName'] ?? 'User';
        _name = '${_fullName ?? ' '} ${_lastName ?? ' '}'.trim();
        _email = doc.data()?['email'] ?? "";
      });
    } else {
      setState(() {
        _avatarUrl = 'assets/user.png';
      });
    }
  }

  Future<void> loadMailsFromFirebase() async {
    if (currentUser != null) {
      debugPrint('Starting to load emails for user: $currentUser');
      try {
        final queryMessageID = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('receiveMails')
            .where('isTrash', isNotEqualTo: true)
            .orderBy('time', descending: true)
            .get();

        debugPrint(
            'Retrieved ${queryMessageID.docs.length} emails from Firebase');

        setState(() {
          mails.clear();
        });

        for (var doc in queryMessageID.docs) {
          final data = doc.data();

          final colorValue = data['color'];
          Color senderColor;
          if (colorValue is int) {
            senderColor = Color(colorValue);
          } else if (colorValue is String && int.tryParse(colorValue) != null) {
            senderColor = Color(int.parse(colorValue));
          } else {
            senderColor = Colors.blueGrey;
          }

          final loadedMail = Message(
            sender: my_models.AppUser(
              id: mails.length,
              name: data['senderName'] ?? 'Unknown',
              imageUrl: senderColor,
              avatarUrl: data['senderAvatarUrl'] ??
                  'assets/user.png', // Thêm avatarUrl
            ),
            reciever: data['receiver'] ?? 'No Reciever',
            subject: data['subject'] ?? 'No Subject',
            text: data['text'] ?? 'No Content',
            time: DateFormat('hh:mm a').format(DateTime.parse(data['time'])),
            unread: data['unread'] ?? true,
            isStarred: data['isStarred'] ?? false,
            threadID: doc.id,
          );

          setState(() {
            mails.add(loadedMail);
          });
        }
        debugPrint('Successfully loaded ${mails.length} emails');
      } catch (e, stackTrace) {
        debugPrint('Error loading mails from Firebase: $e');
        debugPrint('Stack trace: $stackTrace');
      }
    } else {
      debugPrint('No user mail found - userMail is null');
    }
  }

  Future<bool> checkIfUserExists(String email) async {
    final userDoc =
        await FirebaseFirestore.instance.collection('users').doc(email).get();

    return userDoc.exists;
  }

  Future<void> navigateToCompose() async {
    if (!mounted) return;

    final result = await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => const Compose(
                isReply: false,
                isDraft: false,
              )),
    );

    if (!mounted) return;

    if (result != null && result is Map<String, String>) {
      final userName = FirebaseAuth.instance.currentUser?.email ?? 'Anonymous';
      final currentTime = DateTime.now();

      final newMessage = Message(
        sender: my_models.AppUser(
          id: mails.length,
          name: userName,
          imageUrl: getRandomColor(),
        ),
        reciever: result['to'] ?? '',
        subject: result['subject'] ?? '',
        text: result['body'] ?? '',
        time: DateFormat('hh:mm a').format(currentTime),
        unread: true,
        isStarred: false,
      );

      setState(() {
        mails.add(newMessage);
      });

      final messageID = FirebaseFirestore.instance.collection('mails').doc().id;

      final senderMail = FirebaseAuth.instance.currentUser?.email ?? '';
      final receiverMail = newMessage.reciever.trim();

      await FirebaseFirestore.instance
          .collection('users')
          .doc(senderMail)
          .collection('mails')
          .doc(messageID)
          .set({
        'messageID': messageID,
        'sender': newMessage.sender.name,
        'receiver': newMessage.reciever,
        'subject': newMessage.subject,
        'text': newMessage.text,
        'time': currentTime.toIso8601String(),
        'isStarred': newMessage.isStarred,
        'unread': newMessage.unread,
        'color': getRandomColor().toARGB32(),
        'replies': [],
        'labels': [],
      });

      final userExists = await checkIfUserExists(receiverMail);

      if (userExists) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(receiverMail)
            .collection('mails')
            .doc(messageID)
            .set({
          'messageID': messageID,
          'sender': newMessage.sender.name,
          'receiver': newMessage.reciever,
          'subject': newMessage.subject,
          'text': newMessage.text,
          'time': currentTime.toIso8601String(),
          'isStarred': newMessage.isStarred,
          'unread': newMessage.unread,
          'color': getRandomColor().toARGB32(),
          'replies': [],
          'labels': []
        });
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Mail account does not exist!')),
        );
      }
    }
  }

  bool isShow = true;
  final ScrollController _scrollController = ScrollController();
  final GlobalKey<ScaffoldState> _globalKey = GlobalKey<ScaffoldState>();

  void handleScroll() async {
    _scrollController.addListener(() {
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        setState(() {
          isShow = false;
        });
      } else if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        setState(() {
          isShow = true;
        });
      }
    });
  }

  void _showEmailAction(BuildContext parentContext, Message mail, int index) {
    showModalBottomSheet(
      context: parentContext,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (BuildContext bottomSheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(
                  mail.unread ? Icons.mark_email_read : Icons.mark_email_unread,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
                title: Text(mail.unread ? 'Mark as read' : 'Mark as unread'),
                onTap: () async {
                  await markAsReadOrUnread(mail.threadID!, mail.unread);
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(
                  mail.isStarred ? Icons.star : Icons.star_border,
                  color: mail.isStarred
                      ? Colors.yellow
                      : Theme.of(context).colorScheme.onSurface,
                ),
                title:
                    Text(mail.isStarred ? 'Mark as unstar' : 'Mark as starred'),
                onTap: () async {
                  await toggleisStarred(mail, index);
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(Icons.label_outline,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Label email'),
                onTap: () async {
                  Navigator.pop(bottomSheetContext);
                  await choseLabel(parentContext, mail.threadID);
                },
              ),
              ListTile(
                leading: Icon(Icons.delete_outline,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Move to Trash'),
                onTap: () async {
                  await moveMailToTrash(mail.threadID);
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(Icons.close,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Cancel'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> markAsReadOrUnread(
      String messageId, bool currentUnreadStatus) async {
    final index = mails.indexWhere((mail) => mail.threadID == messageId);
    if (index == -1) return;

    try {
      if (currentUnreadStatus) {
        // If the mail is currently read, mark it as unread
        setState(() {
          mails[index].unread = false;
        });

        // Update database in background
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('receiveMails')
            .doc(messageId)
            .update({'unread': false});
      } else {
        // If the mail is currently unread, mark it as read
        setState(() {
          mails[index].unread = true;
        });

        // Update database in background
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('receiveMails')
            .doc(messageId)
            .update({'unread': true});
      }
    } catch (e) {
      // Revert UI if database update fails
      setState(() {
        mails[index].unread = true;
      });
      debugPrint('Error marking as read: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to mark as read')),
        );
      }
    }
  }

  Future<void> toggleReadStatus(
      String messageId, bool currentUnreadStatus) async {
    // Find the mail index first
    final index = mails.indexWhere((mail) => mail.threadID == messageId);
    if (index == -1) return;

    // Optimistically update UI
    setState(() {
      mails[index].unread = false;
    });

    try {
      // Update database in background
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .collection('receiveMails')
          .doc(messageId)
          .update({'unread': false});
    } catch (e) {
      // Revert UI if database update fails
      setState(() {
        mails[index].unread = true;
      });
      debugPrint('Error updating read status: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to update read status')),
        );
      }
    }
  }

  Future<void> moveMailToTrash(String? threadID) async {
    if (threadID != null) {
      // Find the mail index first
      final index = mails.indexWhere((mail) => mail.threadID == threadID);
      if (index == -1) return;

      // Store the mail temporarily in case we need to revert
      final mailToDelete = mails[index];

      // Optimistically update UI
      setState(() {
        mails.removeAt(index);
      });

      final trashDataEmail = {
        'sender': mailToDelete.sender.name,
        'avatarUrl': mailToDelete.sender.avatarUrl,
        'receiver': mailToDelete.reciever,
        'subject': mailToDelete.subject,
        'text': mailToDelete.text,
        'time': mailToDelete.time,
        'color': mailToDelete.sender.imageUrl.toARGB32(),
        'type': 'receiveMails',
      };

      try {
        // Update database in background
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('receiveMails')
            .doc(threadID)
            .update({'isTrash': true});

        // add to trash collection
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('trashMails')
            .doc(threadID)
            .set(trashDataEmail);

        // Show Snackbar
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('Moved to trash successfully'),
              backgroundColor: Colors.green[600],
              behavior: SnackBarBehavior.floating,
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              elevation: 8,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              duration: const Duration(seconds: 2),
            ),
          );
        }
      } catch (e) {
        // Revert UI if database update fails
        setState(() {
          mails.insert(index, mailToDelete);
        });
        debugPrint('Error moving mail to trash: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Failed to move mail to trash')),
          );
        }
      }
    }
  }

  Future<void> loadisStarredStatus(String? threadID) async {
    if (threadID != null) {
      try {
        DocumentSnapshot mailDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('mails')
            .doc(threadID)
            .get();

        if (mailDoc.exists && mounted) {
          setState(() {
            isStarred = mailDoc['isStarred'] ?? false;
          });
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Failed to load isStarred status: $e")),
          );
        }
      }
    }
  }

  String parseQuillJsonToPlainText(String quillJson) {
    try {
      // Giải mã chuỗi JSON thành List<dynamic>
      final List<dynamic> quillData = jsonDecode(quillJson);

      // Trích xuất nội dung từ các đoạn "insert"
      String plainText = quillData
          .where((element) =>
              element['insert'] != null) // Lọc các phần tử có "insert"
          .map((element) => element['insert'].toString()) // Lấy giá trị insert
          .join(); // Nối thành chuỗi

      // Xóa các ký tự xuống dòng hoặc khoảng trắng thừa nếu cần
      return plainText.trim();
    } catch (e) {
      debugPrint('Error parsing Quill JSON: $e');
      return quillJson; // Trả về chuỗi gốc nếu lỗi
    }
  }

  Future<void> toggleisStarred(Message mail, int index) async {
    if (mail.threadID != null) {
      // Optimistically update UI
      setState(() {
        mail.isStarred = !mail.isStarred;
        mails[index] = mail;
      });

      try {
        // Update database in background
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('receiveMails')
            .doc(mail.threadID)
            .update({'isStarred': mail.isStarred});
      } catch (e) {
        // Revert UI if database update fails
        setState(() {
          mail.isStarred = !mail.isStarred;
          mails[index] = mail;
        });
        debugPrint('Error updating star status: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Failed to update star status')),
          );
        }
      }
    }
  }

  Future<void> choseLabel(BuildContext context, String? threadID) async {
    if (!mounted || threadID == null || currentUser == null) return;

    List<String> allLabels = [];
    List<String> selectedLabels = [];
    TextEditingController labelController = TextEditingController();

    try {
      // Lấy danh sách tất cả nhãn từ tài liệu người dùng
      var userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .get();

      if (userDoc.exists) {
        allLabels = List<String>.from(userDoc.data()?['labels'] ?? []);
      }
      debugPrint('Đã tải tất cả nhãn: $allLabels');

      // Kiểm tra email trong các collection
      var collections = ['receiveMails', 'sentMails', 'drafts'];
      String? foundCollection;
      DocumentSnapshot? mailDoc;

      for (var collection in collections) {
        var doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection(collection)
            .doc(threadID)
            .get();

        if (doc.exists) {
          mailDoc = doc;
          foundCollection = collection;
          break;
        }
      }

      if (mailDoc != null && mailDoc.exists) {
        List<dynamic> labelsFromFirestore = mailDoc['labels'] ?? [];
        selectedLabels = List<String>.from(labelsFromFirestore);
      } else {
        debugPrint(
            'Không tìm thấy email với threadID $threadID trong bất kỳ collection nào');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Không tìm thấy email')),
          );
        }
        return;
      }

      if (!mounted) return;

      // Hiển thị dialog để chọn nhãn
      showDialog(
        context: context,
        builder: (ctx) {
          return StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return AlertDialog(
                title: const Text(
                  'Chose Labels',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                content: SingleChildScrollView(
                  child: Column(
                    children: [
                      // Ô nhập để thêm nhãn mới
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        child: Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: labelController,
                                decoration: const InputDecoration(
                                  labelText: 'New Label',
                                  border: OutlineInputBorder(),
                                ),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.add,
                                  color: Colors.blueAccent),
                              onPressed: () async {
                                final newLabel = labelController.text.trim();
                                if (newLabel.isNotEmpty &&
                                    !allLabels.contains(newLabel)) {
                                  try {
                                    // Thêm nhãn mới vào tài liệu người dùng
                                    await FirebaseFirestore.instance
                                        .collection('users')
                                        .doc(currentUser)
                                        .update({
                                      'labels':
                                          FieldValue.arrayUnion([newLabel])
                                    });

                                    // Cập nhật danh sách nhãn trong UI
                                    setState(() {
                                      allLabels.add(newLabel);
                                      selectedLabels.add(newLabel);
                                      labelController.clear();
                                    });

                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                            'New label added successfully'),
                                        backgroundColor: Colors.green,
                                      ),
                                    );
                                  } catch (e) {
                                    debugPrint('Lỗi khi thêm nhãn mới: $e');
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                          content:
                                              Text('Lỗi khi thêm nhãn: $e')),
                                    );
                                  }
                                }
                              },
                            ),
                          ],
                        ),
                      ),
                      // Danh sách nhãn hiện có
                      ListBody(
                        children: allLabels.map((label) {
                          return CheckboxListTile(
                            activeColor: Colors.blueAccent,
                            title: Text(label),
                            value: selectedLabels.contains(label),
                            onChanged: (bool? selected) {
                              setState(() {
                                if (selected == true) {
                                  selectedLabels.add(label);
                                } else {
                                  selectedLabels.remove(label);
                                }
                              });
                            },
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(ctx).pop();
                    },
                    child: Text(
                      'Cancel',
                      style: TextStyle(
                          color: Theme.of(context).colorScheme.onSurface),
                    ),
                  ),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blueAccent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    onPressed: () async {
                      try {
                        // Cập nhật nhãn trong collection tương ứng
                        await FirebaseFirestore.instance
                            .collection('users')
                            .doc(currentUser)
                            .collection(foundCollection!)
                            .doc(threadID)
                            .update({
                          'labels': selectedLabels,
                        });

                        // Cập nhật UI
                        final index = mails
                            .indexWhere((mail) => mail.threadID == threadID);
                        if (index != -1) {
                          setState(() {
                            // mails[index] = mails[index].copyWith(labels: selectedLabels);
                          });
                        }

                        if (!mounted) return;
                        Navigator.of(ctx).pop();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            backgroundColor: Colors.green,
                            content: Text(
                              'Label updated successfully',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        );
                      } catch (e) {
                        debugPrint('Lỗi khi cập nhật nhãn: $e');
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                                content: Text('Lỗi khi cập nhật nhãn: $e')),
                          );
                        }
                      }
                    },
                    label: const Text(
                      'Save',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              );
            },
          );
        },
      );
    } catch (e) {
      debugPrint('Lỗi khi tải nhãn: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Lỗi khi tải nhãn: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const Drawers(),
      key: _globalKey,
      body: SafeArea(
        child: Column(
          children: [
            // Custom AppBar with rounded search bar and avatar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  Builder(
                    builder: (context) => IconButton(
                      icon: const Icon(Icons.menu, size: 28),
                      onPressed: () => Scaffold.of(context).openDrawer(),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      height: 40,
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 225, 224, 224),
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(24),
                        onTap: () {
                          if (currentUser != null) {
                            showSearch(
                              context: context,
                              delegate: Datasearch(currentUser: currentUser!),
                            );
                          }
                        },
                        child: const Row(
                          children: [
                            SizedBox(width: 12),
                            Icon(Icons.search,
                                color: Color.fromARGB(255, 55, 55, 55)),
                            SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Search in mail',
                                style: TextStyle(
                                    color: Color.fromARGB(255, 55, 55, 55),
                                    fontSize: 16),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (context) => AccountSwitcher(
                          mainName: _name ?? 'User',
                          mainEmail: _email ?? "",
                          mainAvatarUrl: _avatarUrl,
                          onManageAccount: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const ProfileScreen(),
                              ),
                            );
                          },
                          onAddAccount: () {},
                          onManageDevice: () {},
                          storagePercent: 0.75,
                          storageText: '75% used',
                        ),
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border:
                            Border.all(color: Colors.grey.shade300, width: 2),
                      ),
                      child: UserAvatar(avatarUrl: _avatarUrl),
                    ),
                  ),
                ],
              ),
            ),
            // Inbox label
            const Padding(
              padding: EdgeInsets.only(left: 18, top: 8, bottom: 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Inbox',
                  style: TextStyle(color: Colors.grey, fontSize: 13),
                ),
              ),
            ),
            // Email list with StreamBuilder
            Expanded(
              child: StreamBuilder<List<Message>>(
                stream: getMailsStream(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (snapshot.hasError) {
                    debugPrint('Error in StreamBuilder: ${snapshot.error}');
                    return const Center(child: Text('Error loading emails'));
                  }
                  if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const Center(child: Text('No emails found'));
                  }

                  final mails = snapshot.data!;
                  return ListView.builder(
                    controller: _scrollController,
                    itemCount: mails.length,
                    itemBuilder: (context, index) {
                      final mail = mails[index];
                      return GestureDetector(
                        onLongPress: () {
                          _showEmailAction(context, mail, index);
                        },
                        child: Container(
                          color: mail.unread
                              ? Colors.grey.withAlpha(20)
                              : Colors.transparent,
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor:
                                  Colors.grey[300], // Màu nền mặc định
                              backgroundImage: mail.sender.avatarUrl != null &&
                                      mail.sender.avatarUrl!.isNotEmpty &&
                                      mail.sender.avatarUrl != 'assets/user.png'
                                  ? NetworkImage(mail.sender
                                      .avatarUrl!) // Sử dụng URL từ avatarUrl
                                  : const AssetImage('assets/user.png')
                                      as ImageProvider, // Hình mặc định
                              child: mail.sender.avatarUrl == null ||
                                      mail.sender.avatarUrl!.isEmpty ||
                                      mail.sender.avatarUrl == 'assets/user.png'
                                  ? Text(
                                      mail.sender.name.isNotEmpty
                                          ? mail.sender.name[0].toUpperCase()
                                          : '?',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: mail.unread
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                      ),
                                    )
                                  : null,
                            ),
                            title: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(
                                    mail.sender.name,
                                    style: TextStyle(
                                      fontWeight: mail.unread
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                    ),
                                  ),
                                ),
                                Text(
                                  mail.time,
                                  style: const TextStyle(
                                      fontSize: 12, color: Colors.grey),
                                ),
                              ],
                            ),
                            subtitle: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        mail.subject,
                                        style: TextStyle(
                                          fontWeight: mail.unread
                                              ? FontWeight.bold
                                              : FontWeight.normal,
                                          color: Theme.of(context)
                                              .textTheme
                                              .bodyLarge
                                              ?.color, // Sử dụng màu từ theme
                                        ),
                                      ),
                                      Text(
                                        parseQuillJsonToPlainText(mail.text),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  icon: Icon(
                                    mail.isStarred
                                        ? Icons.star
                                        : Icons.star_border,
                                    color: mail.isStarred
                                        ? Colors.yellow
                                        : Colors.grey,
                                  ),
                                  onPressed: () {
                                    toggleisStarred(mail, index);
                                  },
                                ),
                              ],
                            ),
                            onTap: () async {
                              debugPrint(
                                  'Tapped email with threadID: ${mail.threadID}');
                              // Lưu trữ NavigatorState trước khi thực hiện thao tác bất đồng bộ
                              final navigator = Navigator.of(context);
                              // Kiểm tra mounted trước khi gọi toggleReadStatus
                              if (!mounted) {
                                debugPrint(
                                    'Widget not mounted before toggleReadStatus');
                                return;
                              }

                              // Gọi toggleReadStatus
                              await toggleReadStatus(
                                  mail.threadID!, mail.unread);

                              // Kiểm tra lại mounted sau await
                              if (!mounted) {
                                debugPrint(
                                    'Widget not mounted after toggleReadStatus');
                                return;
                              }
                              navigator.push(
                                MaterialPageRoute(
                                  builder: (_) => MailDetail(
                                    mailId: mail.threadID!,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: isShow
          ? Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                FloatingActionButton.extended(
                  onPressed: navigateToCompose,
                  label: const Text('Compose'),
                  icon: const Icon(Icons.edit_outlined),
                  foregroundColor: Colors.black,
                  backgroundColor: const Color.fromARGB(255, 203, 236, 252),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(24)),
                ),
              ],
            )
          : null,
      bottomNavigationBar: BottomNavigation(
        currentIndex: _currentIndex,
      ),
    );
  }

  Color generateRandomColor() {
    Random rd = Random();
    return Color.fromARGB(
        255, rd.nextInt(256), rd.nextInt(256), rd.nextInt(256));
  }
}
