// Dart imports:
import 'dart:convert';
import 'dart:math';

// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

// Project imports:
import 'package:final_project/components/account_switcher.dart';
import 'package:final_project/components/bottom_nav.dart';
import 'package:final_project/components/data_search.dart';
import 'package:final_project/models/message_mode.dart';
import 'package:final_project/models/reply_mode.dart';
import 'package:final_project/models/user_mode.dart' as my_models;
import 'package:final_project/tabs/compose.dart';
import 'package:final_project/tabs/mail_detail.dart';
import 'package:final_project/tabs/profile.dart';
import 'drawer.dart';

class LabeledMails extends StatefulWidget {
  final String labelName;

  const LabeledMails({super.key, required this.labelName});

  @override
  State<LabeledMails> createState() => _LabeledMailsState();
}

class _LabeledMailsState extends State<LabeledMails> {
  List<Message> mails = [];
  final currentUser = FirebaseAuth.instance.currentUser?.uid;
  String? _avatarUrl;
  String? _name;
  String? _fullName;
  String? _lastName;
  String? _email;
  final int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    loadMailsByLabel();
    _loadUserInfo();
  }

  Future<void> _loadUserInfo() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      setState(() {
        _avatarUrl = doc.data()?['avatarUrl'] ?? 'assets/user.png';
        _fullName = doc.data()?['fullName'] ?? 'Người dùng';
        _lastName = doc.data()?['lastName'] ?? 'Người dùng';
        _name = '${_fullName ?? ' '} ${_lastName ?? ' '}'.trim();
        _email = doc.data()?['email'] ?? "";
      });
    } else {
      setState(() {
        _avatarUrl = 'assets/user.png';
      });
    }
  }

  Future<void> loadMailsByLabel() async {
    if (currentUser == null) {
      debugPrint('Không có người dùng đăng nhập');
      return;
    }

    debugPrint('Đang tải email cho nhãn: ${widget.labelName}');
    try {
      // Thực hiện truy vấn đồng thời cho các collection
      final results = await Future.wait([
        FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('receiveMails')
            .where('labels', arrayContains: widget.labelName)
            .where('isTrash', isNotEqualTo: true)
            .orderBy('time', descending: true)
            .get(),
        FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('sentMails')
            .where('labels', arrayContains: widget.labelName)
            .where('isTrash', isNotEqualTo: true)
            .orderBy('time', descending: true)
            .get(),
        FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('drafts')
            .where('labels', arrayContains: widget.labelName)
            .orderBy('time', descending: true)
            .get(),
      ]);

      // Gộp tất cả tài liệu từ các collection
      final allDocs = [
        ...results[0].docs, // receiveMails
        ...results[1].docs, // sentMails
        ...results[2].docs, // drafts
      ];

      // Xóa danh sách mails hiện tại
      setState(() {
        mails.clear();
      });

      // Xử lý từng tài liệu
      for (var doc in allDocs) {
        final data = doc.data();
        final colorValue = data['color'];
        Color senderColor;
        if (colorValue is int) {
          senderColor = Color(colorValue);
        } else if (colorValue is String && int.tryParse(colorValue) != null) {
          senderColor = Color(int.parse(colorValue));
        } else {
          senderColor = Colors.blueGrey;
        }

        // Xử lý replies
        List<Reply> replyList = [];
        if (data['replies'] != null) {
          for (var reply in data['replies']) {
            replyList.add(
              Reply(
                body: reply['body'] ?? 'Không có nội dung',
                from: reply['from'] ?? 'Người gửi không xác định',
                subject: reply['subject'] ?? 'Không có chủ đề',
                time: reply['time'] ?? '',
                to: reply['to'] ?? 'Người nhận không xác định',
              ),
            );
          }
        }

        final loadedMail = Message(
          sender: my_models.AppUser(
            id: mails.length,
            name: data['senderName'] ?? 'Không xác định',
            imageUrl: senderColor,
            avatarUrl:
                data['senderAvatarUrl'] ?? 'assets/user.png', // Add avatarUrl
          ),
          reciever: data['receiver'] ?? 'Không có người nhận',
          subject: data['subject'] ?? 'Không có chủ đề',
          text: data['text'] ?? 'Không có nội dung',
          time: DateFormat('hh:mm a').format(DateTime.parse(data['time'])),
          unread: data['unread'] ?? true,
          isStarred: data['isStarred'] ?? false,
          replies: replyList,
          threadID: doc.id,
        );

        setState(() {
          mails.add(loadedMail);
        });
      }

      debugPrint('Đã tải ${mails.length} email cho nhãn ${widget.labelName}');
    } catch (e, stackTrace) {
      debugPrint('Lỗi khi tải email có nhãn: $e');
      debugPrint('Stack trace: $stackTrace');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Lỗi khi tải email: $e')),
        );
      }
    }
  }

  Future<void> toggleReadStatus(
      String messageId, bool currentUnreadStatus) async {
    final index = mails.indexWhere((mail) => mail.threadID == messageId);
    if (index == -1) return;

    // Cập nhật UI lạc quan
    setState(() {
      mails[index].unread = !mails[index].unread;
    });

    try {
      // Kiểm tra email trong các collection
      var collections = ['receiveMails', 'sentMails', 'drafts'];
      String? foundCollection;

      for (var collection in collections) {
        var doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection(collection)
            .doc(messageId)
            .get();

        if (doc.exists) {
          foundCollection = collection;
          break;
        }
      }

      if (foundCollection != null) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection(foundCollection)
            .doc(messageId)
            .update({'unread': mails[index].unread});
      } else {
        throw Exception('Không tìm thấy email trong bất kỳ collection nào');
      }
    } catch (e) {
      // Hoàn tác UI nếu cập nhật cơ sở dữ liệu thất bại
      setState(() {
        mails[index].unread = currentUnreadStatus;
      });
      debugPrint('Lỗi khi cập nhật trạng thái đọc: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Không thể cập nhật trạng thái đọc')),
        );
      }
    }
  }

  Future<void> toggleisStarred(Message mail, int index) async {
    if (mail.threadID == null) return;

    // Cập nhật UI lạc quan
    setState(() {
      mail.isStarred = !mail.isStarred;
      mails[index] = mail;
    });

    try {
      // Kiểm tra email trong các collection
      var collections = ['receiveMails', 'sentMails', 'drafts'];
      String? foundCollection;

      for (var collection in collections) {
        var doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection(collection)
            .doc(mail.threadID)
            .get();

        if (doc.exists) {
          foundCollection = collection;
          break;
        }
      }

      if (foundCollection != null) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection(foundCollection)
            .doc(mail.threadID)
            .update({'isStarred': mail.isStarred});
      } else {
        throw Exception('Không tìm thấy email trong bất kỳ collection nào');
      }
    } catch (e) {
      // Hoàn tác UI nếu cập nhật cơ sở dữ liệu thất bại
      setState(() {
        mail.isStarred = !mail.isStarred;
        mails[index] = mail;
      });
      debugPrint('Lỗi khi cập nhật trạng thái gắn sao: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Không thể cập nhật trạng thái gắn sao')),
        );
      }
    }
  }

  Future<void> moveMailToTrash(String? threadID) async {
    if (threadID == null) return;

    // Tìm chỉ số email
    final index = mails.indexWhere((mail) => mail.threadID == threadID);
    if (index == -1) return;

    // Lưu email tạm thời
    final mailToDelete = mails[index];

    // Cập nhật UI lạc quan
    setState(() {
      mails.removeAt(index);
    });

    try {
      // Kiểm tra email trong các collection
      var collections = ['receiveMails', 'sentMails', 'drafts'];
      String? foundCollection;

      for (var collection in collections) {
        var doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection(collection)
            .doc(threadID)
            .get();

        if (doc.exists) {
          foundCollection = collection;
          break;
        }
      }

      if (foundCollection != null) {
        // Di chuyển vào collection trashMails
        final trashDataEmail = {
          'sender': mailToDelete.sender.name,
          'receiver': mailToDelete.reciever,
          'subject': mailToDelete.subject,
          'text': mailToDelete.text,
          'time': mailToDelete.time,
          'color': mailToDelete.sender.imageUrl.value,
          'type': foundCollection,
          'isStarred': mailToDelete.isStarred,
          'unread': mailToDelete.unread,
        };

        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection('trashMails')
            .doc(threadID)
            .set(trashDataEmail);

        // Đánh dấu là thùng rác trong collection gốc
        await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection(foundCollection)
            .doc(threadID)
            .update({'isTrash': true});

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Move email to trash successfully')),
          );
        }
      } else {
        throw Exception('Cannot find email in any collection');
      }
    } catch (e) {
      // Hoàn tác UI nếu cập nhật cơ sở dữ liệu thất bại
      setState(() {
        mails.insert(index, mailToDelete);
      });
      debugPrint('Error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Cannot move email to trash, please try again')),
        );
      }
    }
  }

  Future<void> choseLabel(BuildContext context, String? threadID) async {
    if (!mounted || threadID == null || currentUser == null) return;

    List<String> allLabels = [];
    List<String> selectedLabels = [];
    TextEditingController labelController = TextEditingController();

    try {
      // Lấy danh sách tất cả nhãn từ tài liệu người dùng
      var userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser)
          .get();

      if (userDoc.exists) {
        allLabels = List<String>.from(userDoc.data()?['labels'] ?? []);
      }

      // Kiểm tra email trong các collection
      var collections = ['receiveMails', 'sentMails', 'drafts'];
      String? foundCollection;
      DocumentSnapshot? mailDoc;

      for (var collection in collections) {
        var doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentUser)
            .collection(collection)
            .doc(threadID)
            .get();

        if (doc.exists) {
          mailDoc = doc;
          foundCollection = collection;
          break;
        }
      }

      if (mailDoc != null && mailDoc.exists) {
        List<dynamic> labelsFromFirestore = mailDoc['labels'] ?? [];
        selectedLabels = List<String>.from(labelsFromFirestore);
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('Cannot find email in any collection')),
          );
        }
        return;
      }

      if (!mounted) return;

      // Hiển thị dialog để chọn nhãn
      showDialog(
        context: context,
        builder: (ctx) {
          return StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return AlertDialog(
                title: const Text(
                  'Chose Labels',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                content: SingleChildScrollView(
                  child: Column(
                    children: [
                      // Ô nhập để thêm nhãn mới
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        child: Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: labelController,
                                decoration: const InputDecoration(
                                  labelText: 'New Label',
                                  border: OutlineInputBorder(),
                                ),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.add,
                                  color: Colors.blueAccent),
                              onPressed: () async {
                                final newLabel = labelController.text.trim();
                                if (newLabel.isNotEmpty &&
                                    !allLabels.contains(newLabel)) {
                                  try {
                                    // Thêm nhãn mới vào tài liệu người dùng
                                    await FirebaseFirestore.instance
                                        .collection('users')
                                        .doc(currentUser)
                                        .update({
                                      'labels':
                                          FieldValue.arrayUnion([newLabel])
                                    });

                                    // Cập nhật danh sách nhãn trong UI
                                    setState(() {
                                      allLabels.add(newLabel);
                                      selectedLabels.add(newLabel);
                                      labelController.clear();
                                    });

                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                            'New label added successfully'),
                                        backgroundColor: Colors.green,
                                      ),
                                    );
                                  } catch (e) {
                                    debugPrint('Error: $e');
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(content: Text('Error: $e')),
                                    );
                                  }
                                }
                              },
                            ),
                          ],
                        ),
                      ),
                      // Danh sách nhãn hiện có
                      ListBody(
                        children: allLabels.map((label) {
                          return CheckboxListTile(
                            activeColor: Colors.blueAccent,
                            title: Text(label),
                            value: selectedLabels.contains(label),
                            onChanged: (bool? selected) {
                              setState(() {
                                if (selected == true) {
                                  selectedLabels.add(label);
                                } else {
                                  selectedLabels.remove(label);
                                }
                              });
                            },
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(ctx).pop();
                    },
                    child: const Text(
                      'Cancel',
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blueAccent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    onPressed: () async {
                      try {
                        // Cập nhật nhãn trong collection tương ứng
                        await FirebaseFirestore.instance
                            .collection('users')
                            .doc(currentUser)
                            .collection(foundCollection!)
                            .doc(threadID)
                            .update({
                          'labels': selectedLabels,
                        });

                        // Cập nhật UI
                        final index = mails
                            .indexWhere((mail) => mail.threadID == threadID);
                        if (index != -1) {
                          setState(() {
                            // mails[index] = mails[index].copyWith(labels: selectedLabels);
                          });
                        }

                        if (!mounted) return;
                        Navigator.of(ctx).pop();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            backgroundColor: Colors.green,
                            content: Text(
                              'Label updated successfully',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        );
                      } catch (e) {
                        debugPrint('Lỗi khi cập nhật nhãn: $e');
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                                content: Text('Lỗi khi cập nhật nhãn: $e')),
                          );
                        }
                      }
                    },
                    label: const Text(
                      'Save',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              );
            },
          );
        },
      );
    } catch (e) {
      debugPrint('Lỗi khi tải nhãn: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Lỗi khi tải nhãn: $e')),
        );
      }
    }
  }

  String parseQuillJsonToPlainText(String quillJson) {
    try {
      // Giải mã chuỗi JSON thành List<dynamic>
      final List<dynamic> quillData = jsonDecode(quillJson);

      // Trích xuất nội dung từ các đoạn "insert"
      String plainText = quillData
          .where((element) =>
              element['insert'] != null) // Lọc các phần tử có "insert"
          .map((element) => element['insert'].toString()) // Lấy giá trị insert
          .join(); // Nối thành chuỗi

      // Xóa các ký tự xuống dòng hoặc khoảng trắng thừa nếu cần
      return plainText.trim();
    } catch (e) {
      debugPrint('Error parsing Quill JSON: $e');
      return quillJson; // Trả về chuỗi gốc nếu lỗi
    }
  }

  void _showEmailAction(BuildContext parentContext, Message mail, int index) {
    showModalBottomSheet(
      context: parentContext,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (BuildContext bottomSheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(
                  mail.unread ? Icons.mark_email_read : Icons.mark_email_unread,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
                title: Text(mail.unread ? 'Mark as read' : 'Mark as unread'),
                onTap: () async {
                  await toggleReadStatus(mail.threadID!, mail.unread);
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(
                  mail.isStarred ? Icons.star : Icons.star_border,
                  color: mail.isStarred ? Colors.yellow : Colors.black54,
                ),
                title: Text(mail.isStarred ? 'Mark as Unstar' : 'Mark as Star'),
                onTap: () async {
                  await toggleisStarred(mail, index);
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(Icons.label_outline,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Label email'),
                onTap: () async {
                  Navigator.pop(bottomSheetContext);
                  await choseLabel(parentContext, mail.threadID);
                },
              ),
              ListTile(
                leading: Icon(Icons.delete_outline,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Move to Trash'),
                onTap: () async {
                  Navigator.pop(context);
                  await moveMailToTrash(mail.threadID);
                },
              ),
              ListTile(
                leading: Icon(Icons.close,
                    color: Theme.of(context).colorScheme.onSurface),
                title: const Text('Cancel'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> navigateToCompose() async {
    if (!mounted) return;

    final result = await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => const Compose(
                isReply: false,
                isDraft: false,
              )),
    );

    if (!mounted || result == null || result is! Map<String, String>) return;

    final userName = FirebaseAuth.instance.currentUser?.email ?? 'Không có';
    final currentTime = DateTime.now();

    final newMessage = Message(
      sender: my_models.AppUser(
        id: mails.length,
        name: userName,
        imageUrl: Color((Random().nextDouble() * 0xFFFFFF).toInt() << 0)
            .withOpacity(1.0),
      ),
      reciever: result['to'] ?? '',
      subject: result['subject'] ?? '',
      text: result['body'] ?? '',
      time: DateFormat('hh:mm a').format(currentTime),
      unread: true,
      isStarred: false,
    );

    setState(() {
      mails.add(newMessage);
    });

    final messageID = FirebaseFirestore.instance.collection('mails').doc().id;
    final senderMail = FirebaseAuth.instance.currentUser?.email ?? '';
    final receiverMail = newMessage.reciever.trim();

    // Lưu vào sentMails của người gửi
    await FirebaseFirestore.instance
        .collection('users')
        .doc(senderMail)
        .collection('sentMails')
        .doc(messageID)
        .set({
      'messageID': messageID,
      'sender': newMessage.sender.name,
      'email': senderMail,
      'receiver': newMessage.reciever,
      'subject': newMessage.subject,
      'body': newMessage.text,
      'time': currentTime.toIso8601String(),
      'isStarred': newMessage.isStarred,
      'from': false,
      'color': newMessage.sender.imageUrl.value,
      'replies': [],
    });

    // Kiểm tra xem người nhận có tồn tại và lưu vào receiveMails
    final userExists = await FirebaseFirestore.instance
        .collection('users')
        .doc(receiverMail)
        .get()
        .then((doc) => doc.exists);

    if (userExists) {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(receiverMail)
          .collection('receiveMails')
          .doc(messageID)
          .set({
        'messageID': messageID,
        'sender': newMessage.sender.name,
        'senderMail': senderMail,
        'receiver': newMessage.reciever,
        'subject': newMessage.subject,
        'text': newMessage.text,
        'time': currentTime.toIso8601String(),
        'isStarred': newMessage.isStarred,
        'unread': true,
        'color': newMessage.sender.imageUrl.value,
        'replies': [],
      });
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tài khoản email không tồn tại!')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const Drawers(),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  Builder(
                    builder: (context) => IconButton(
                      icon: const Icon(Icons.menu, size: 28),
                      onPressed: () => Scaffold.of(context).openDrawer(),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      height: 40,
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 225, 224, 224),
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(24),
                        onTap: () {
                          if (currentUser != null) {
                            showSearch(
                              context: context,
                              delegate: Datasearch(currentUser: currentUser!),
                            );
                          }
                        },
                        child: const Row(
                          children: [
                            SizedBox(width: 12),
                            Icon(Icons.search,
                                color: Color.fromARGB(255, 55, 55, 55)),
                            SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Search in mail',
                                style: TextStyle(
                                    color: Color.fromARGB(255, 55, 55, 55),
                                    fontSize: 16),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (context) => AccountSwitcher(
                          mainName: _name ?? 'Người dùng',
                          mainEmail: _email ?? "",
                          mainAvatarUrl: _avatarUrl,
                          onManageAccount: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const ProfileScreen(),
                              ),
                            );
                          },
                          onAddAccount: () {},
                          onManageDevice: () {},
                          storagePercent: 0.75,
                        ),
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border:
                            Border.all(color: Colors.grey.shade300, width: 2),
                      ),
                      child: UserAvatar(avatarUrl: _avatarUrl),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 18, top: 8, bottom: 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  widget.labelName,
                  style: const TextStyle(color: Colors.grey, fontSize: 13),
                ),
              ),
            ),
            Expanded(
              child: mails.isEmpty
                  ? const Center(child: Text('No email found for this label'))
                  : ListView.builder(
                      itemCount: mails.length,
                      itemBuilder: (context, index) {
                        final mail = mails[index];
                        return GestureDetector(
                          onLongPress: () {
                            _showEmailAction(context, mail, index);
                          },
                          child: Container(
                            color: mail.unread
                                ? Colors.grey.withAlpha(20)
                                : Colors.transparent,
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: Colors
                                    .grey[300], // Default background color
                                backgroundImage: mail.sender.avatarUrl !=
                                            null &&
                                        mail.sender.avatarUrl!.isNotEmpty &&
                                        mail.sender.avatarUrl !=
                                            'assets/user.png'
                                    ? NetworkImage(mail.sender
                                        .avatarUrl!) // Use avatarUrl if available
                                    : const AssetImage('assets/user.png')
                                        as ImageProvider, // Fallback image
                                child: mail.sender.avatarUrl == null ||
                                        mail.sender.avatarUrl!.isEmpty ||
                                        mail.sender.avatarUrl ==
                                            'assets/user.png'
                                    ? Text(
                                        mail.sender.name.isNotEmpty
                                            ? mail.sender.name[0].toUpperCase()
                                            : '?',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: mail.unread
                                              ? FontWeight.bold
                                              : FontWeight.normal,
                                        ),
                                      )
                                    : null,
                              ),
                              title: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Text(
                                      mail.sender.name,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  Text(
                                    mail.time,
                                    style: const TextStyle(
                                        fontSize: 12, color: Colors.grey),
                                  ),
                                ],
                              ),
                              subtitle: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          mail.subject,
                                          style: TextStyle(
                                            fontWeight: mail.unread
                                                ? FontWeight.bold
                                                : FontWeight.normal,
                                            color: Theme.of(context)
                                                .textTheme
                                                .bodyLarge
                                                ?.color, // Sử dụng màu từ theme
                                          ),
                                        ),
                                        Text(
                                          parseQuillJsonToPlainText(mail.text),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    icon: Icon(
                                      mail.isStarred
                                          ? Icons.star
                                          : Icons.star_border,
                                      color: mail.isStarred
                                          ? Colors.yellow
                                          : Colors.grey,
                                    ),
                                    onPressed: () {
                                      toggleisStarred(mail, index);
                                    },
                                  ),
                                ],
                              ),
                              onTap: () async {
                                await toggleReadStatus(
                                    mail.threadID!, mail.unread);
                                if (!mounted) return;
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => MailDetail(
                                      mailId: mail.threadID!,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: navigateToCompose,
        label: const Text('Compose'),
        icon: const Icon(Icons.edit_outlined),
        foregroundColor: Colors.black,
        backgroundColor: const Color.fromARGB(255, 203, 236, 252),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      ),
      bottomNavigationBar: BottomNavigation(
        currentIndex: _currentIndex,
      ),
    );
  }
}
