const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");
const { user } = require("firebase-functions/v1/auth");

admin.initializeApp({
    ignoreUndefinedProperties: true,
});
console.log("Firebase Admin initialized successfully");

const db = admin.firestore();

exports.autoReplyNoReplies = onDocumentCreated(
    {
        document: "users/{userId}/receiveMails/{mailId}",
        region: "asia-southeast1",
    },
    async (event) => {
        const mailId = event.params.mailId;
        const userId = event.params.userId;
        console.log(`Function triggered for email ${mailId} for user ${userId}`);

        // Log event params
        console.log("Event params:", JSON.stringify(event.params, null, 2));
        console.log("Event data exists:", !!event.data);

        // Kiểm tra dữ liệu đầu vào
        const newEmail = event.data.data();
        if (!newEmail) {
            console.error(`No email data found for mailId ${mailId}`);
            return null;
        }
        console.log("New email data:", JSON.stringify(newEmail, null, 2));

        // Define các biến cần thiết
        sender = newEmail.sender;
        relpier = userId;
        console.log("Sender:", sender, "Relpier:", relpier);

        // Kiểm tra xem người nhận có bật auto reply không 
        try {
            console.log("Checking if auto reply is enabled for user:", userId);
            const settingDocs = await db
                .collection("users")
                .doc(userId)
                .collection("settings")
                .doc("autoReply")
                .get();
            if (!settingDocs.exists) {
                console.log(`No auto reply settings found for user ${userId}`);
                return null;
            }

            const settingsData = settingDocs.data();
            console.log("Auto reply settings data:", JSON.stringify(settingsData, null, 2));
            if (!settingsData.isAutoReply) {
                console.log(`Auto reply is not enabled for user ${userId}`);
                return null;
            }
            console.log(`Auto reply is enabled for user ${userId}`);

        } catch (error) {
            console.error(`Error checking auto reply settings for user ${userId}:`, error);
            return null;
        }

        // Kiểm tra xem email đã có replies chưa
        console.log("Checking if email has replies for mailId:", mailId);
        try {
            const mailDoc = await db.collection("mails").doc(mailId).get();
            if (!mailDoc.exists) {
                console.log(`Mail document does not exist for mailId ${mailId}`);
                return null;
            }
            const mailData = mailDoc.data();
            console.log("Mail data:", JSON.stringify(mailData, null, 2));

            if (mailData.replies && mailData.replies.length > 0) {
                console.log(`Email ${mailId} already has replies, skipping auto reply`);
                return null;
            }
            console.log(`Email ${mailId} has no replies, proceeding with auto reply`);

        } catch (error) {
            console.error(`Error checking replies for email ${mailId}:`, error);
            return null;
        }

        // Ghi dữ liệu auto reply
        try {
            console.log("Entering try block for mailId:", mailId);
            // Get auto reply settings
            console.log("Fetching settings doc for user:", userId);
            const settingsDoc = await db
                .collection("users")
                .doc(userId)
                .collection("settings")
                .doc("autoReply")
                .get();
            console.log("Settings doc exists:", settingsDoc.exists);
            if (!settingsDoc.exists) {
                console.log(`Settings doc does not exist for user ${userId}`);
                return null;
            }
            const settingsData = settingsDoc.data();
            console.log("Settings data:", JSON.stringify(settingsData, null, 2));
            if (!settingsData.isAutoReply) {
                console.log(`Auto reply not enabled for user ${userId}`);
                return null;
            }

            // Chuyển đổi autoReplyContent thành định dạng Quill Delta JSON
            const autoReplyContent = settingsData.autoReplyContent
                ? `${settingsData.autoReplyContent}\n\nThis is an auto reply message. Please do not reply to this email.`
                : "This is an auto reply message. Please do not reply to this email.";
            const quillDeltaContent = [{ insert: `${autoReplyContent}\n` }]; // Định dạng Quill Delta
            const quillDeltaString = JSON.stringify(quillDeltaContent); // Chuyển thành chuỗi JSON

            console.log("Quill Delta content:", quillDeltaString);


            // Get sender info (userId is the reply sender)
            console.log("Fetching sender doc for user:", userId);
            const senderDoc = await db.collection("users").doc(userId).get();
            console.log("Sender doc exists:", senderDoc.exists);
            if (!senderDoc.exists) {
                console.log(`Sender doc does not exist for user ${userId}`);
                return null;
            }
            const senderData = senderDoc.data();
            const senderName = senderData.fullName + " " + senderData.lastName;
            const senderEmail = senderData.email; // Lấy email từ user doc
            const senderAvatarUrl = senderData.avatarUrl || 'assets/user.png'; // Lấy avatarUrl

            console.log("Sender (reply sender):", senderName, senderEmail);


            // Get receiver info (original sender)


            const receiverDoc = await db
                .collection("users")
                .where("email", "==", sender)
                .limit(1)
                .get()
            const receiverData = receiverDoc.docs[0];
            const receiverName = receiverData.data().fullName + " " + receiverData.data().lastName;
            const receiverEmail = receiverData.data().email;
            const receiverId = receiverData.id; // Lấy ID của người nhận
            console.log("Receiver (original sender):", receiverName, receiverEmail);


            // Create auto reply email
            const replyMailId = db.collection("repliesEmail").doc().id;
            const replyTime = new Date().toISOString();
            const subject = `Re: ${newEmail.subject || "No Subject"}`;
            console.log("Generated replyMailId:", replyMailId, "Subject:", subject);

            // Hàm lọc null và undefined
            const cleanObject = (obj) => {
                const cleaned = {};
                for (const [key, value] of Object.entries(obj)) {
                    if (value !== undefined && value !== null) {
                        cleaned[key] = value;
                    }
                }
                return cleaned;
            };

            // Dữ liệu cho repliesEmail
            const replyEmailData = cleanObject({
                body: quillDeltaString,
                from: senderEmail,
                fromName: senderName,
                mailId: replyMailId,
                parentMailId: mailId,
                subject: subject,
                time: replyTime,
                to: sender,
                toNames: receiverName,
                senderAvatarUrl: senderAvatarUrl,
            });

            // Dữ liệu cho người được reply
            const replyEmailDataForReceiver = cleanObject({
                color: "4286009749",
                isStarred: false,
                isTrash: false,
                mailId: replyMailId,
                receiverName: receiverName,
                sender: senderEmail,
                senderName: senderName,
                senderAvatarUrl: senderAvatarUrl,
                subject: subject,
                text: quillDeltaString,
                time: replyTime,
                unread: true,
                labels: [],
            });

            console.log("replyEmailData:", JSON.stringify(replyEmailData, null, 2));

            // Batch write
            console.log("Starting batch write for replyMailId:", replyMailId);
            const batch = db.batch();


            // Ghi vào repliesEmail
            batch.set(db.collection("repliesEmail").doc(replyMailId), replyEmailData);

            // Cập nhật mảng replies của email gốc
            batch.update(db.collection("mails").doc(mailId), {
                replies: admin.firestore.FieldValue.arrayUnion(replyMailId),
            });

            // Ghi vào users/{userId}/receiveMails
            batch.set(
                db.collection("users").doc(receiverId).collection("receiveMails").doc(mailId),
                replyEmailDataForReceiver
            );

            console.log("Committing batch");
            await batch.commit();
            console.log(`Auto reply sent for email ${mailId} to ${receiverId} with replyMailId ${replyMailId}`);
            return null;
        } catch (error) {
            console.error(`Error in autoReplyNoReplies for email ${mailId}:`, error);
            return null;
        }
    }

);