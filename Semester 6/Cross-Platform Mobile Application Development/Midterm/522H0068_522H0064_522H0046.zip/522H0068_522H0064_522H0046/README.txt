
## Midterm Demo - Flutter With Firebase
- 522H0068 - Phạm Văn Phúc - Class 22H50202
- 522H0064 - Nguyễn Huỳnh Anh Khoa - Class 22H50202
- 522H0046 - Phạm Duy Khánh - Class 22H50202
---

## System Requirements

- **Operating System**: Windows 10/11, macOS 12.0 or later
- **Flutter Version**: Flutter 3.7.0 or higher
- **Dart Version**: Dart 2.19.0 or higher
- **IDE**: Visual Studio Code, Android Studio
- **Additional Tools**:
  - Android SDK (for Android emulation)

---

## Setup Instructions

1. **Install Flutter**:
   - If Flutter is not installed, follow the official guide: https://flutter.dev/docs/get-started/install
   - Verify installation by running:
     ```
     flutter doctor
     ```
     Ensure no critical issues are reported.

2. **Install Dependencies**:
   - Navigate to the project directory and run:
     ```
     flutter pub get
     ```
     This installs all dependencies listed in `pubspec.yaml`.

4. **Set Up Emulators/Devices**:
   - **Android**:
     - Ensure Android SDK is installed and emulators are configured in Android Studio.
     - List available emulators by running:
       ```
       flutter emulators
       ```
     - Open two separate terminals to run two emulators:
       - In the first terminal, launch the first emulator:
         ```
         flutter emulators --launch [emulator-id-1]
         ```
       - In the second terminal, launch the second emulator:
         ```
         flutter emulators --launch [emulator-id-2]
         ```
       - Replace `[emulator-id-1]` and `[emulator-id-2]` with the IDs listed from `flutter emulators` (e.g., `Pixel_4_API_30`).
     - Verify both emulators are running by checking:
       ```
       flutter devices
       ```
5. **Run the Project**:
   - Ensure both emulators are running (check with `flutter devices`).
   - Run the project on each emulator from separate terminals:
     - In the first terminal, run the project on the first emulator:
       ```
       flutter run -d [device-id-1]
       ```
     - In the second terminal, run the project on the second emulator:
       ```
       flutter run -d [device-id-2]
       ```
     - Replace `[device-id-1]` and `[device-id-2]` with the device IDs listed from `flutter devices` (e.g., `emulator-5554`).

     

## Link Presentation Video:  https://youtu.be/o4AvKmKXr4g 